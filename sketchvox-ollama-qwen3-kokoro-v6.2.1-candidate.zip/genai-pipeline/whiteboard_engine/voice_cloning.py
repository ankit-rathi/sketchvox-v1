"""Optional personal-voice synthesis adapter.

The core release stays fully local and reproducible with Kokoro. If the user
supplies an authorized reference recording, this adapter gives the pipeline a
stable interface for a separately installed cloning engine. No voice model or
reference audio is shipped in the repository.
"""
from __future__ import annotations
import os
import subprocess
from pathlib import Path
from typing import Any


def validate_reference(path: str | Path, min_seconds: float = 5.0) -> dict[str, Any]:
    p=Path(path)
    if not p.exists(): return {"ok":False,"error":"reference file not found"}
    try:
        dur=float(subprocess.check_output(["ffprobe","-v","error","-show_entries","format=duration","-of","default=nw=1:nk=1",str(p)],text=True).strip())
    except Exception as exc:
        return {"ok":False,"error":f"ffprobe failed: {exc}"}
    return {"ok":dur>=min_seconds,"duration":dur,"path":str(p),"error":None if dur>=min_seconds else f"reference should be at least {min_seconds}s"}


def synthesize_reference(text: str, out_path: str | Path, reference_audio: str | Path, provider: str | None = None, **kwargs) -> str:
    """Call an externally installed local clone engine via its configured command.

    Configure SKETCHVOX_CLONER_CMD as a command template containing {text},
    {reference}, and {output}. This keeps model licensing and installation out
    of the core package and makes the adapter engine-agnostic.
    """
    cmd_tpl= os.getenv("SKETCHVOX_CLONER_CMD", "").strip()
    if not cmd_tpl:
        raise RuntimeError("No local voice-cloner configured. Set SKETCHVOX_CLONER_CMD to an authorized local engine command.")
    ref=validate_reference(reference_audio)
    if not ref.get("ok"):
        raise RuntimeError(str(ref.get("error")))
    Path(out_path).parent.mkdir(parents=True, exist_ok=True)
    cmd=cmd_tpl.format(text=text, reference=str(reference_audio), output=str(out_path))
    result=subprocess.run(cmd, shell=True, capture_output=True, text=True)
    if result.returncode:
        raise RuntimeError(result.stderr[-4000:] or result.stdout[-4000:])
    if not Path(out_path).exists():
        raise RuntimeError("Voice cloner completed but did not create the configured output file.")
    return str(out_path)

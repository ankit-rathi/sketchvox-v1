"""Isolated rendered-frame QA worker.

OpenCV can keep codec resources alive when a VideoWriter and VideoCapture are
used in the same Python process. SketchVox therefore runs raster QA in a short
child process by default. This also isolates Tesseract subprocesses on Windows.
"""
from __future__ import annotations
import json, sys
from pathlib import Path
from .visual_qa import inspect_rendered_video

def main(argv=None):
    argv=list(sys.argv[1:] if argv is None else argv)
    if len(argv)<2:
        raise SystemExit("usage: python -m whiteboard_engine.qa_worker VIDEO PROJECT_JSON [REPORT_JSON]")
    video=argv[0]; project_path=argv[1]
    report_path=argv[2] if len(argv)>2 else None
    project=json.loads(Path(project_path).read_text(encoding='utf-8'))
    report=inspect_rendered_video(video,project,1280,720,30,True,4)
    payload=json.dumps(report,ensure_ascii=False)
    if report_path:
        Path(report_path).write_text(payload,encoding='utf-8')
    else:
        print(payload)

if __name__=='__main__':
    main()

"""Optional provider adapters. Core rendering remains provider-independent."""

"""Render a SketchVox world-class demo from a prompt or built-in storyboard."""
from __future__ import annotations
import argparse, json
from pathlib import Path
from whiteboard_engine.deterministic_director import build_plan
from whiteboard_engine.renderer_worldclass import render_worldclass

ROOT=Path(__file__).resolve().parent

def main():
    ap=argparse.ArgumentParser(description="SketchVox deterministic visual storyteller demo")
    ap.add_argument("--prompt",default="compound interest",help="Concept to explain")
    ap.add_argument("--storyboard",help="Optional storyboard JSON")
    ap.add_argument("--out",default="output/sketchvox_demo.mp4")
    ap.add_argument("--no-hand",action="store_true")
    args=ap.parse_args()
    if args.storyboard:
        project=json.loads(Path(args.storyboard).read_text(encoding="utf-8"))
    else:
        project=build_plan(args.prompt)
    out=ROOT/args.out if not Path(args.out).is_absolute() else Path(args.out)
    out.parent.mkdir(parents=True,exist_ok=True)
    print(render_worldclass(project,out,{"hand":not args.no_hand}))

if __name__=="__main__": main()

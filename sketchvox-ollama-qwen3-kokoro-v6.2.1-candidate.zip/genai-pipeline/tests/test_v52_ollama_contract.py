import json
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer


def test_ollama_two_stage_bmr_contract_path(monkeypatch, tmp_path):
    """Exercise the exact Ollama HTTP path with deterministic Qwen-shaped JSON.

    This is a provider-contract integration test, not a substitute for running
    a real Qwen model. It verifies that AnswerIR is generated first, locked,
    then consumed by the visual director without allowing generic summary data
    to redefine the lesson.
    """
    answer={
        "canonical_question":"What is BMR?",
        "one_sentence_answer":"BMR is the amount of energy your body needs at rest to keep essential functions running.",
        "must_explain":["baseline energy at rest","essential body functions","BMR is not total daily energy expenditure"],
        "useful_example":"Think of BMR as the baseline energy budget before everyday activity adds energy use.",
        "must_not_confuse_with":["total daily energy expenditure"],
        "final_mental_model":"BMR is your body's baseline energy budget at rest.",
        "concepts":[
            {"id":"c1","name":"Baseline energy at rest","explanation":"The baseline energy the body needs while resting."},
            {"id":"c2","name":"Essential body functions","explanation":"That baseline supports essential processes such as breathing and circulation."},
            {"id":"c3","name":"BMR is not total daily energy expenditure","explanation":"Activity and digestion add energy needs beyond BMR."}
        ]
    }
    scene={"meta":{"title":"BMR"},"scenes":[
        {"id":"s1","purpose":"definition","duration":5,"narration":answer["one_sentence_answer"],"teaching_claim":answer["one_sentence_answer"],"objects":[{"type":"icon","icon":"body"}]},
        {"id":"s2","purpose":"explain","duration":5,"narration":"The baseline supports essential processes such as breathing and circulation.","teaching_claim":"The baseline supports essential body functions.","objects":[{"type":"icon","icon":"heart"}]},
        {"id":"s3","purpose":"compare","duration":5,"narration":"BMR is a baseline, not total daily energy expenditure.","teaching_claim":"Activity and digestion add energy needs beyond BMR.","objects":[]}
    ]}
    responses=[answer,scene]
    calls=[]
    class H(BaseHTTPRequestHandler):
        def do_POST(self):
            n=int(self.headers.get("Content-Length","0")); payload=json.loads(self.rfile.read(n)); calls.append(payload)
            body={"message":{"content":json.dumps(responses.pop(0),ensure_ascii=False)}}
            raw=json.dumps(body).encode()
            self.send_response(200); self.send_header("Content-Type","application/json"); self.send_header("Content-Length",str(len(raw))); self.end_headers(); self.wfile.write(raw)
        def log_message(self,*a): pass
    server=ThreadingHTTPServer(("127.0.0.1",0),H); th=threading.Thread(target=server.serve_forever,daemon=True); th.start()
    monkeypatch.setenv("SKETCHVOX_OLLAMA_URL", f"http://127.0.0.1:{server.server_port}")
    monkeypatch.setenv("SKETCHVOX_CACHE", "0")
    monkeypatch.setenv("SKETCHVOX_CACHE_DIR", str(tmp_path/"cache"))
    try:
        from whiteboard_engine.storyboard import generate
        out=generate("What is BMR (Basal Metabolic Rate)?", provider="ollama", model="qwen3:test", strict=True)
    finally:
        server.shutdown(); server.server_close()
    assert len(calls)==2
    assert "LOCKED ANSWER IR" in calls[1]["messages"][1]["content"]
    assert out["meta"]["answer_ir"]["one_sentence_answer"].startswith("BMR is the amount")
    assert out["meta"]["coverage_gate"]["ok"]
    assert out["meta"]["coverage_gate"]["generic_summary_cards"] == 0

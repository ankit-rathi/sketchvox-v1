"""SketchVox v5 Teaching IR: narration, display copy, claim and visual are separate."""
from __future__ import annotations
from copy import deepcopy
from typing import Any

def build_teaching_contract(topic: str, project: dict[str, Any]) -> dict[str, Any]:
    scenes=[]
    for idx, scene in enumerate(project.get('scenes', []), 1):
        display=[]
        for obj in scene.get('objects', []):
            typ=obj.get('type')
            if typ in {'text','equation','number'}:
                value=str(obj.get('text', obj.get('value', ''))).strip()
                if value: display.append({'object_id':obj.get('id'),'copy':value,'role':obj.get('semantic_role','annotation')})
            elif typ=='summary_board':
                for ci, card in enumerate(obj.get('cards', []),1):
                    display.append({'object_id':obj.get('id'),'card':ci,'title':str(card.get('title','')),'phrase':str(card.get('phrase','')),'support':str(card.get('support', card.get('takeaway','')))})
        scenes.append({'scene':idx,'id':scene.get('id',f'scene_{idx}'),'narration':str(scene.get('narration','')),'teaching_claim':str(scene.get('teaching_claim',scene.get('design_intent',''))),'display_copy':display,'visual_archetype':scene.get('visual_archetype')})
    return {'version':'5.0','topic':topic,'separation':'narration != display_copy != visual != semantic_claim','scenes':scenes}

def validate_contract(contract: dict[str, Any]) -> list[str]:
    errors=[]
    if contract.get('separation') != 'narration != display_copy != visual != semantic_claim': errors.append('teaching contract separation invariant missing')
    for s in contract.get('scenes',[]):
        if not isinstance(s.get('display_copy'),list): errors.append(f"scene {s.get('scene')}: display_copy must be a list")
    return errors

def attach_contract(project: dict[str, Any], topic: str='') -> dict[str, Any]:
    out=deepcopy(project); out.setdefault('meta',{})['teaching_ir']=build_teaching_contract(topic or out.get('meta',{}).get('title',''),out); return out

def compound_interest_demo():
    values=[10000*(1.10**i) for i in range(11)]
    return {
      "global_plan":{"title":"Why compounding accelerates wealth","target_audience":"beginner investors","tone":"educational","total_scenes":3},
      "scenes":[
        {"scene_number":1,"purpose":"hook","narration":"Imagine investing ten thousand rupees and earning ten percent a year.","duration":5,
         "objects":[{"type":"person","x":180,"y":250,"scale":0.8},{"type":"money","x":400,"y":300,"label":"₹10,000"},{"type":"arrow","x":600,"y":350,"x2":800,"y2":350},{"type":"text","x":390,"y":450,"text":"10% return","size":44}]},
        {"scene_number":2,"purpose":"mechanism","narration":"The important part is that next year's return is earned on the larger amount.","duration":7,
         "objects":[{"type":"text","x":110,"y":90,"text":"Year 1","size":42,"bold":True},{"type":"money","x":110,"y":180,"label":"₹11,000"},{"type":"arrow","x":350,"y":250,"x2":580,"y2":250},{"type":"text","x":600,"y":90,"text":"Year 2","size":42,"bold":True},{"type":"money","x":600,"y":180,"label":"₹12,100"},{"type":"equation","x":220,"y":430,"text":"Future Value = Principal × (1 + r)^n","size":42}]},
        {"scene_number":3,"purpose":"insight","narration":"Over many years, that repeated reinvestment creates a curve rather than a straight line.","duration":8,
         "objects":[{"type":"chart","x":120,"y":120,"values":values,"label":"₹10,000 at 10% annually","width":850,"height":420},{"type":"text","x":900,"y":150,"text":"Compounding","size":40,"bold":True}]}
      ]
    }

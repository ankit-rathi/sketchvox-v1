"""Rendered-frame visual QA and deterministic auto-repair.

This module is intentionally renderer-agnostic at the contract level: it opens the
actual MP4 frames produced by SketchVox and measures what survived rasterization.
It complements schema/preflight QA rather than replacing it.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any
import json
import math
import re
import difflib
import cv2
import numpy as np

from .scene_graph import object_bbox


@dataclass
class FrameIssue:
    severity: str
    code: str
    message: str
    frame: int | None = None
    scene: int | None = None
    object_id: str | None = None
    metric: float | None = None


def _foreground_mask(frame: np.ndarray) -> np.ndarray:
    """Approximate ink/illustration pixels while rejecting paper texture."""
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
    # Dark ink/hand plus saturated accent strokes.
    dark = gray < 205
    accent = (hsv[:, :, 1] > 55) & (gray < 245)
    mask = ((dark | accent).astype(np.uint8)) * 255
    kernel = np.ones((2, 2), np.uint8)
    return cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)


def _ink_density(mask: np.ndarray, box: tuple[int, int, int, int]) -> float:
    x1, y1, x2, y2 = box
    h, w = mask.shape[:2]
    x1, y1 = max(0, x1), max(0, y1)
    x2, y2 = min(w, x2), min(h, y2)
    if x2 <= x1 or y2 <= y1:
        return 0.0
    return float(np.count_nonzero(mask[y1:y2, x1:x2])) / float((x2 - x1) * (y2 - y1))


def _box(obj: dict[str, Any]) -> tuple[int, int, int, int] | None:
    b = object_bbox(obj)
    if not b:
        return None
    return (int(round(b.x)), int(round(b.y)), int(round(b.x2)), int(round(b.y2)))


def _endpoint(obj: dict[str, Any], elapsed: float | None = None) -> tuple[float, float]:
    t = obj.get("type")
    x, y, s = float(obj.get("x", 0)), float(obj.get("y", 0)), float(obj.get("scale", 1))
    if t in {"text", "equation", "number"}:
        size = float(obj.get("size", 46)) * s
        raw=str(obj.get("text", obj.get("value", "")))
        visible=raw
        if elapsed is not None:
            st=float(obj.get("start",0)); od=max(0.001,float(obj.get("duration",1)))
            p=max(0.0,min(1.0,(elapsed-st)/od))
            visible=raw[:max(1,int(math.ceil(len(raw)*p)))] if p>0 else ""
        return x + max(18, len(visible) * size * 0.48), y + size * 0.52
    if t in {"arrow", "line"}:
        return float(obj.get("x2", x)), float(obj.get("y2", y))
    if t == "money":
        return x + 180 * s, y + 52 * s
    if t == "person":
        return x + 42 * s, y + 170 * s
    if t in {"circle", "ellipse"}:
        return x + float(obj.get("rx", obj.get("r", 50))) * s, y
    if t in {"rect", "round_rect"}:
        return float(obj.get("x2", x + 100)), float(obj.get("y2", y + 60))
    if t in {"chart", "line_chart", "bar_chart", "pie_chart"}:
        return x + float(obj.get("width", 700)), y + float(obj.get("height", 350))
    if t == "summary_board":
        return x + float(obj.get("width", 1280)) - 70, y + 110
    return x + 55 * s, y + 35 * s


def _active(scene: dict[str, Any], elapsed: float) -> list[dict[str, Any]]:
    out = []
    for obj in scene.get("objects", []):
        st = float(obj.get("start", 0)); dur = float(obj.get("duration", scene.get("duration", 5)))
        if st <= elapsed <= st + dur + 0.08:
            out.append(obj)
    return out


def _scene_for_time(project: dict[str, Any], t: float) -> tuple[int, dict[str, Any], float] | None:
    cursor = 0.0
    for i, scene in enumerate(project.get("scenes", []), 1):
        dur = float(scene.get("duration", 0))
        if cursor <= t <= cursor + dur + 1e-6:
            return i, scene, max(0.0, min(dur, t - cursor))
        cursor += dur
    return None


def _sample_times(project: dict[str, Any], per_scene: int = 3) -> list[tuple[int, float, float]]:
    """Return (scene_number, absolute_time, local_time) samples."""
    out = []
    absolute = 0.0
    for si, scene in enumerate(project.get("scenes", []), 1):
        dur = float(scene.get("duration", 0))
        fractions = [0.28, 0.58, 0.82, 0.985] if per_scene >= 4 else ([0.30, 0.68, 0.90] if per_scene >= 3 else [0.82])
        if any(o.get('type') == 'summary_board' for o in scene.get('objects', [])):
            fractions.append(0.995)
        for f in fractions:
            local = min(dur - 0.03, max(0.03, dur * f))
            out.append((si, absolute + local, local))
        absolute += dur
    return out



def _summary_expected_composite(project: dict[str, Any], scene: dict[str, Any], width: int, height: int) -> np.ndarray | None:
    """Render the deterministic summary layer as the expected final raster.

    This is used only for QA. It catches bugs where a correct summary exists in
    the scene graph but the renderer clips part of its header/card copy.
    """
    boards=[o for o in scene.get('objects',[]) if o.get('type')=='summary_board']
    if len(boards)!=1:
        return None
    try:
        from .renderer_worldclass import _render_summary_full
        cfg={'ink':'#20242B','accent':'#4F46E5','accent2':'#F59E0B','positive':'#10B981','danger':'#EF4444','muted':'#64748B'}
        layer=_render_summary_full(boards[0],cfg)
        bg=np.zeros((height,width,4),dtype=np.uint8); bg[:,:,:3]=np.array([252,251,247],dtype=np.uint8); bg[:,:,3]=255
        alpha=np.asarray(layer.getchannel('A'),dtype=np.float32)/255.0
        rgb=np.asarray(layer.convert('RGB'),dtype=np.float32)
        bg_rgb=bg[:,:,:3].astype(np.float32)
        comp=(rgb*alpha[:,:,None]+bg_rgb*(1-alpha[:,:,None])).astype(np.uint8)
        return comp
    except Exception:
        return None


def _region_difference(actual: np.ndarray, expected: np.ndarray, box: tuple[int,int,int,int]) -> float:
    x1,y1,x2,y2=box
    x1=max(0,min(actual.shape[1],x1)); x2=max(x1,min(actual.shape[1],x2))
    y1=max(0,min(actual.shape[0],y1)); y2=max(y1,min(actual.shape[0],y2))
    if x2<=x1 or y2<=y1: return 0.0
    a=actual[y1:y2,x1:x2].astype(np.int16); e=expected[y1:y2,x1:x2].astype(np.int16)
    return float(np.mean(np.abs(a-e)))/255.0


def _expected_text_presence(actual_bgr: np.ndarray, text: str, box: tuple[int,int,int,int], font_size: int, bold: bool=False) -> tuple[float,float]:
    """Compare actual raster ink to a deterministic text template.

    Returns (coverage, template_pixels). It is intentionally font/renderer-aware,
    not OCR-dependent, so Windows deployments don't need an external Tesseract.
    """
    if not text: return 1.0, 0.0
    from .renderer_worldclass import draw_handwritten_text
    from PIL import Image
    x1,y1,x2,y2=box
    w=max(1,x2-x1); h=max(1,y2-y1)
    layer=Image.new('RGBA',(w,h),(0,0,0,0))
    # Use the same handwriting renderer and glyph fallback as production. Comparing
    # Comic Neue output against the UI font created false OCR/template failures.
    draw_handwritten_text(layer,{"text":str(text),"x":2,"y":2,"size":int(font_size),"color":"#20242B","bold":bold},1.0,{"ink":"#20242B","accent":"#4F46E5"})
    exp=np.asarray(layer.getchannel('A'))>20
    if not np.any(exp): return 1.0,0.0
    frame=actual_bgr[y1:y2,x1:x2]
    if frame.size==0: return 0.0,float(exp.sum())
    mask=_foreground_mask(frame)>0
    # Dilate actual ink slightly to tolerate mp4 rasterization/anti-aliasing.
    mask=cv2.dilate(mask.astype(np.uint8),np.ones((3,3),np.uint8),iterations=1)>0
    # Recall-like coverage: most expected text pixels must have nearby actual ink.
    coverage=float(np.count_nonzero(mask & exp))/max(1,int(exp.sum()))
    return coverage,float(exp.sum())


def _region_text_health(frame: np.ndarray, box: tuple[int,int,int,int], min_density: float=0.0008, check_bottom: bool=True, check_right: bool=True) -> tuple[bool,float,float]:
    """Inspect actual raster ink inside a text region.

    We don't require OCR. A text block is healthy when ink exists and its raster
    bbox has breathing room from the region's right/bottom clipping boundaries.
    This catches exactly the failure mode where the last words are cut off.
    """
    x1,y1,x2,y2=box
    x1=max(0,min(frame.shape[1],x1)); x2=max(x1,min(frame.shape[1],x2))
    y1=max(0,min(frame.shape[0],y1)); y2=max(y1,min(frame.shape[0],y2))
    if x2<=x1 or y2<=y1: return False,0.0,1.0
    crop=frame[y1:y2,x1:x2]
    mask=_foreground_mask(crop)>0
    density=float(np.count_nonzero(mask))/max(1,mask.size)
    if density < min_density: return False,density,1.0
    ys,xs=np.where(mask)
    margin_right=float((mask.shape[1]-1-xs.max())) if xs.size else 0.0
    margin_bottom=float((mask.shape[0]-1-ys.max())) if ys.size else 0.0
    # A small tolerance handles anti-aliasing. If text reaches either boundary,
    # it is very likely being cropped by the composition box.
    clipped = (check_right and margin_right < 1.0) or (check_bottom and margin_bottom < 1.0)
    return not clipped,density,min(margin_right,margin_bottom)


def _summary_icon_uniqueness(cards: list[dict[str, Any]]) -> list[FrameIssue]:
    """Summary cards should not reuse a decorative glyph for different concepts."""
    issues=[]; seen={}
    for i,card in enumerate(cards,1):
        icon=str(card.get('icon') or '').strip().lower()
        if not icon: continue
        if icon in seen:
            issues.append(FrameIssue('error','SUMMARY_ICON_DUPLICATE',
                f'Summary cards {seen[icon]} and {i} use the same semantic icon {icon!r}',object_id='summary_board'))
        else: seen[icon]=i
    return issues


def _summary_render_zone_checks(frame: np.ndarray, scene: dict[str, Any], width: int, height: int,
                                frame_idx: int, scene_no: int) -> list[FrameIssue]:
    """Inspect the actual recap raster for icon/copy zone collisions and text fit."""
    issues=[]
    boards=[o for o in scene.get('objects',[]) if o.get('type')=='summary_board']
    if len(boards)!=1: return issues
    board=boards[0]; cards=board.get('cards',[])[:8]
    try:
        from .renderer_worldclass import _summary_layout
        positions,cw,ch=_summary_layout(len(cards),width,height)
        # The card layout defines three protected bands:
        # title [14..78], icon [82..140], copy [150..end].
        for i,(cx,cy) in enumerate(positions):
            # The renderer now uses a hard icon band ending at y=140 and a copy
            # band beginning at y=154.  Do not inspect the 140..154 separator itself:
            # anti-aliased badge strokes can legitimately touch that boundary.  The
            # actual copy-zone check below is the authoritative collision test.
            # Check that the expected takeaway area actually contains copy and has
            # a comfortable bottom margin. This catches partial/blank final cards.
            tx1,ty1,tx2,ty2=int(cx+20),int(cy+150),int(cx+cw-20),int(cy+ch-35)
            healthy,density2,margin=_region_text_health(frame,(tx1,ty1,tx2,ty2),0.00045)
            if not healthy:
                issues.append(FrameIssue('error','SUMMARY_COPY_INCOMPLETE',
                    f'Summary card {i+1} takeaway is missing, clipped, or outside its safe text zone',
                    frame_idx,scene_no,'summary_board',min(density2,margin/20.0)))
        issues.extend(_summary_icon_uniqueness(cards))
    except Exception as exc:
        issues.append(FrameIssue('error','SUMMARY_LAYOUT_QA_INTERNAL','Summary layout QA failed: '+str(exc),frame_idx,scene_no,'summary_board'))
    return issues


def _summary_ocr_checks(frame: np.ndarray, scene: dict[str, Any], width: int, height: int,
                        frame_idx: int, scene_no: int) -> list[FrameIssue]:
    """OCR-check final summary titles/takeaways against the actual raster."""
    issues=[]
    if _ocr_engine() is None: return issues
    boards=[o for o in scene.get('objects',[]) if o.get('type')=='summary_board']
    if len(boards)!=1: return issues
    board=boards[0]; cards=board.get('cards',[])[:8]
    try:
        from .renderer_worldclass import _summary_layout
        positions,cw,ch=_summary_layout(len(cards),width,height)
        for i,(cx,cy) in enumerate(positions):
            card=cards[i]
            # OCR the title and takeaway separately; this avoids the icon diagram
            # polluting semantic matching.
            # OCR validates display copy only. Narration may be longer than the
            # visual phrase and must never be the summary OCR oracle.
            expected_phrase=str(card.get('phrase','')).strip()
            # The small support line is intentionally validated by the text-health
            # zone check, not OCR: short anti-aliased secondary text is too brittle
            # for a blocking semantic oracle. The large phrase is the memory-board
            # ground truth and is safe for OCR.
            for label,text,box in [
                ('title',str(card.get('title','')).strip(),(int(cx+62),int(cy+10),int(cx+cw-78),int(cy+72))),
                ('phrase',expected_phrase,(int(cx+20),int(cy+150),int(cx+cw-20),int(cy+ch-75)))
            ]:
                if len(text)<3: continue
                got=_ocr_crop(frame,box)
                exp=_semantic_tokens(text); actual=_semantic_tokens(got)
                if not exp: continue
                matched=0
                for tok in exp:
                    if tok in actual:
                        matched+=1; continue
                    best=max((difflib.SequenceMatcher(None,tok,g).ratio() for g in actual),default=0)
                    if best >= (0.70 if len(tok)<=5 else 0.76): matched+=1
                ratio=matched/max(1,len(exp))
                threshold = 0.25 if len(exp) <= 3 else 0.35
                if ratio < threshold:
                    issues.append(FrameIssue('error','SUMMARY_OCR_MISMATCH',
                        f'Summary card {i+1} {label} does not match expected copy; expected={text!r}, OCR={got!r}',
                        frame_idx,scene_no,'summary_board',ratio))
    except Exception as exc:
        issues.append(FrameIssue('error','SUMMARY_OCR_INTERNAL','Summary OCR QA failed: '+str(exc),frame_idx,scene_no,'summary_board'))
    return issues


def _summary_text_checks(frame: np.ndarray, scene: dict[str, Any], width: int, height: int, frame_idx: int, scene_no: int) -> list[FrameIssue]:
    issues=[]
    boards=[o for o in scene.get('objects',[]) if o.get('type')=='summary_board']
    if len(boards)!=1: return issues
    board=boards[0]
    try:
        from .renderer_worldclass import _summary_layout
        cards=board.get('cards',[])[:8]; positions,cw,ch=_summary_layout(len(cards),width,height)
        # Header: generous boxes around the actual rendered headline/subtitle.
        healthy,density,margin=_region_text_health(frame,(58,54,min(width-50,1215),112),0.001)
        if not healthy:
            issues.append(FrameIssue('error','SUMMARY_TEXT_CLIPPED','Summary title is missing or clipped at the rendered-frame boundary',frame_idx,scene_no,'summary_board',min(density,margin/20.0)))
        healthy,density,margin=_region_text_health(frame,(58,112,min(width-120,1160),151),0.0005)
        if not healthy:
            issues.append(FrameIssue('error','SUMMARY_TEXT_CLIPPED','Summary subtitle is missing or clipped',frame_idx,scene_no,'summary_board',min(density,margin/20.0)))
        for i,(cx,cy) in enumerate(positions):
            # Title region ends before the divider. Takeaway region owns the lower
            # half of the card and must never touch its right/bottom edge.
            # Card-title completeness is verified by the OCR pass below.  The
            # title can legitimately wrap to two lines and the semantic icon sits
            # in the same horizontal header band, so a simple rectangular ink
            # boundary test is too easy to fool with a valid two-line title.
            healthy,density,margin=_region_text_health(frame,(cx+18,cy+158,cx+cw-18,cy+ch-28),0.0005)
            if not healthy:
                issues.append(FrameIssue('error','SUMMARY_TEXT_CLIPPED',f'Summary card {i+1} takeaway is incomplete',frame_idx,scene_no,'summary_board',min(density,margin/20.0)))
    except Exception as exc:
        issues.append(FrameIssue('warning','SUMMARY_QA_INTERNAL','Summary text QA could not be evaluated: '+str(exc),frame_idx,scene_no,'summary_board'))
    return issues


_OCR_AVAILABLE = None

def _ocr_engine():
    """Return a verified pytesseract engine, including Windows PATH discovery."""
    global _OCR_AVAILABLE
    if _OCR_AVAILABLE is False:
        return None
    try:
        import os, shutil
        import pytesseract
        configured = os.getenv("SKETCHVOX_TESSERACT_CMD", "").strip()
        candidates = [configured, shutil.which("tesseract")]
        if os.name == "nt":
            candidates += [
                r"C:\Program Files\Tesseract-OCR\tesseract.exe",
                r"C:\Program Files (x86)\Tesseract-OCR\tesseract.exe",
            ]
        for candidate in candidates:
            if candidate and os.path.exists(candidate):
                pytesseract.pytesseract.tesseract_cmd = candidate
                break
        # Importing pytesseract is not enough: verify the native executable is
        # callable. This prevents the old 'ocr_available=True' / runtime-error
        # contradiction seen on Windows.
        pytesseract.get_tesseract_version()
        _OCR_AVAILABLE = True
        return pytesseract
    except Exception:
        _OCR_AVAILABLE = False
        return None


def _semantic_normalize(text: str) -> str:
    s = str(text or '').lower()
    # OCR frequently drops currency symbols and punctuation. Preserve letters and
    # digits so "₹11,000" and "11 000" become comparable semantic tokens.
    s = s.replace('₹', ' ').replace('$', ' ').replace('€', ' ').replace('£', ' ')
    s = s.replace('—', ' ').replace('–', ' ').replace('→', ' ')
    s = re.sub(r'[^a-z0-9]+', ' ', s)
    return re.sub(r'\s+', ' ', s).strip()


def _semantic_tokens(text: str) -> list[str]:
    return [t for t in _semantic_normalize(text).split() if len(t) >= 2 or t.isdigit()]


def _ocr_crop(frame: np.ndarray, box: tuple[int, int, int, int]) -> str:
    pyt = _ocr_engine()
    if pyt is None:
        return ''
    x1,y1,x2,y2=box
    x1=max(0,min(frame.shape[1]-1,x1)); x2=max(x1+1,min(frame.shape[1],x2))
    y1=max(0,min(frame.shape[0]-1,y1)); y2=max(y1+1,min(frame.shape[0],y2))
    crop=frame[y1:y2,x1:x2]
    if crop.size == 0:
        return ''
    gray=cv2.cvtColor(crop,cv2.COLOR_BGR2GRAY)
    # Upscale small text and use two thresholding variants; Tesseract gets the
    # best result from the same clean raster the viewer sees, not the scene graph.
    scale=2 if max(gray.shape[:2]) < 700 else 1
    if scale > 1:
        gray=cv2.resize(gray,None,fx=scale,fy=scale,interpolation=cv2.INTER_CUBIC)
    gray=cv2.GaussianBlur(gray,(3,3),0)
    variants=[gray,cv2.threshold(gray,0,255,cv2.THRESH_BINARY+cv2.THRESH_OTSU)[1]]
    outputs=[]
    for img in variants:
        try:
            outputs.append(pyt.image_to_string(img,config='--psm 6',lang='eng').strip())
        except Exception:
            pass
    return max(outputs,key=len,default='')


def _text_box_exact(obj: dict[str, Any], width: int, height: int) -> tuple[int,int,int,int]:
    x=float(obj.get('x',0)); y=float(obj.get('y',0)); size=float(obj.get('size',46))*float(obj.get('scale',1))
    text=str(obj.get('text',obj.get('value','')))
    try:
        from .renderer_worldclass import _text_metrics
        tw,th=_text_metrics(text,int(size),bool(obj.get('bold',False)))
        w=float(tw)+18; h=max(float(th)*1.35,size*1.35)
    except Exception:
        w=max(40,len(text)*size*.52)+18; h=size*1.35
    x1=max(0,int(round(x-8))); y1=max(0,int(round(y-8)))
    x2=min(width,int(round(x+w))); y2=min(height,int(round(y+h)))
    return x1,y1,x2,y2


def _ocr_semantic_checks(frame: np.ndarray, scene: dict[str, Any], scene_no: int,
                         width: int, height: int, frame_idx: int) -> list[FrameIssue]:
    """Verify important numeric/equation display copy using object-local OCR.

    Scene-wide OCR is useful as a broad corroborator but is a poor oracle when a
    scene contains several equations. v5 therefore crops each authoritative text
    object, OCRs that crop, and falls back to deterministic raster coverage.
    """
    issues=[]
    if _ocr_engine() is None: return issues
    for obj in scene.get('objects',[]):
        if obj.get('type') not in {'text','equation','number'}: continue
        text=str(obj.get('text',obj.get('value',''))).strip()
        if len(text)<2 or not (re.search(r'[0-9₹$€£%]',text) or obj.get('type') in {'equation','number'}):
            continue
        box=_text_box_exact(obj,width,height)
        pad=10
        box=(max(0,box[0]-pad),max(0,box[1]-pad),min(width,box[2]+pad),min(height,box[3]+pad))
        got=_ocr_crop(frame,box)
        exp_tokens=_semantic_tokens(text); actual=_semantic_tokens(got)
        if not exp_tokens: continue
        matched=0
        for tok in exp_tokens:
            if tok in actual:
                matched+=1; continue
            best=max((difflib.SequenceMatcher(None,tok,g).ratio() for g in actual),default=0)
            if best >= (0.70 if len(tok)<=5 else 0.76): matched+=1
        ratio=matched/max(1,len(exp_tokens))
        threshold=0.45 if len(exp_tokens)>=2 else 1.0
        if ratio < threshold:
            cov,_=_expected_text_presence(frame,text,box,int(float(obj.get('size',46))),bool(obj.get('bold',False)))
            raster_ok=cov >= (0.62 if not re.search(r'[0-9₹$€£%]',text) else 0.72)
            if not raster_ok:
                issues.append(FrameIssue('error','OCR_TEXT_MISMATCH',
                    f'Final rendered text is not semantically recoverable: expected={text!r}; object OCR={got!r}',
                    frame_idx,scene_no,obj.get('id'),ratio))
    return issues


def _semantic_scene_checks(scene: dict[str, Any], scene_no: int) -> list[FrameIssue]:
    """Check whether a scene is a visual explanation rather than a text slide."""
    issues=[]
    if any(o.get('type')=='summary_board' for o in scene.get('objects',[])):
        return issues
    objs=[o for o in scene.get('objects',[]) if o.get('type') not in {'space'}]
    visual=[o for o in objs if o.get('type') not in {'text','equation','number'}]
    narration=str(scene.get('narration',''))
    if objs and not visual:
        issues.append(FrameIssue('error','SEMANTIC_TEXT_SLIDE',
            'Scene contains only text/equations; an explainer scene needs at least one visual object.',scene=scene_no))
    causal=bool(re.search(r'\b(becomes|become|grows|growing|increases|increase|because|therefore|retrieve|augment|generate|converts|convert|produces|produce|releases|release|splits|split|causes|leads)\b|from .+ into',narration.lower()))
    flow_types={'arrow','chart','line','trend','round_rect','rect','database','document','money','coin','wallet','robot','magnifier'}
    if causal and visual and not any(o.get('type') in flow_types for o in visual):
        issues.append(FrameIssue('warning','SEMANTIC_FLOW_WEAK',
            'Narration describes a transformation/causal relationship but the scene has no strong flow or transformation visual.',scene=scene_no))
    return issues


def _static_visual_check(scene: dict[str, Any], scene_no: int) -> list[FrameIssue]:
    """Flag scenes that look like static slides rather than drawn explanations."""
    issues=[]
    if any(o.get('type')=='summary_board' for o in scene.get('objects',[])):
        return issues
    dur=float(scene.get('duration',0)); objs=[o for o in scene.get('objects',[]) if o.get('type')!='space']
    if dur < 3.2 or len(objs)<2: return issues
    intervals=[]
    for o in objs:
        st=float(o.get('start',0)); en=st+float(o.get('duration',0)); intervals.append((st,en,o))
    intervals.sort(key=lambda item: (item[0], item[1]))
    # Find long periods with no active animation after the scene starts.
    cursor=0.35
    max_gap=0.0
    for st,en,o in intervals:
        if st>cursor: max_gap=max(max_gap,st-cursor)
        cursor=max(cursor,en)
    if dur-cursor>0.22: max_gap=max(max_gap,dur-cursor)
    if max_gap>2.6 and len(objs)<=4:
        issues.append(FrameIssue('warning','STATIC_HOLD','Scene contains a long static hold with little drawing motion',scene=scene_no,metric=max_gap))
    return issues




TEXT_TYPES = {"text", "equation", "number"}
CONTAINER_TYPES = {"round_rect", "rect"}

def _is_intentional_parent_child(parent: dict[str, Any], child: dict[str, Any], parent_box: tuple[int,int,int,int] | None = None,
                                  child_box: tuple[int,int,int,int] | None = None) -> bool:
    """Return True only for an authored/inferred container composition.

    A child is allowed to overlap its parent; it is *not* allowed to cross the
    parent's border. Explicit ``parent`` wins. When older storyboards omit it,
    a text object whose anchor starts inside a card is treated as a child.
    This distinction is critical: parent/child composition must not fall through
    into the generic sibling-collision detector after border QA has run.
    """
    pt, ct = parent.get("type"), child.get("type")
    if pt not in CONTAINER_TYPES or ct not in TEXT_TYPES:
        return False
    pid = parent.get("id")
    if child.get("parent") and pid:
        return str(child.get("parent")) == str(pid)
    if parent_box is None:
        parent_box = _box(parent)
    if parent_box is None:
        return False
    x, y = float(child.get("x", 0)), float(child.get("y", 0))
    pad = 2.0
    return parent_box[0] + pad <= x <= parent_box[2] - pad and parent_box[1] + pad <= y <= parent_box[3] - pad


def _pair_is_parent_child(a: dict[str, Any], b: dict[str, Any],
                          ba: tuple[int,int,int,int] | None = None,
                          bb: tuple[int,int,int,int] | None = None) -> bool:
    return _is_intentional_parent_child(a, b, ba, bb) or _is_intentional_parent_child(b, a, bb, ba)

def inspect_rendered_video(video_path: str | Path, project: dict[str, Any], width=1280, height=720,
                           fps=30, hand=True, per_scene=3) -> dict[str, Any]:
    """Inspect sampled *rasterized* frames from the generated MP4.

    Frames are decoded sequentially once instead of repeatedly seeking into the
    MP4; this matters for 30–60 second videos and keeps QA cheap enough for a
    local generation service.
    """
    cap = cv2.VideoCapture(str(video_path))
    if not cap.isOpened():
        return {"ok": False, "issues": [asdict(FrameIssue("error", "VIDEO_OPEN", "Could not open rendered MP4"))], "samples": 0}
    frame_count = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
    actual_fps = float(cap.get(cv2.CAP_PROP_FPS) or fps)
    issues: list[FrameIssue] = []
    samples = _sample_times(project, per_scene=per_scene)
    targets = sorted([(max(0, min(frame_count - 1, int(round(abs_t * actual_fps)))), scene_no, abs_t) for scene_no, abs_t, _ in samples])
    target_i = 0
    hashes: list[tuple[int, int]] = []
    frame_idx = -1
    try:
        while target_i < len(targets):
            ok, frame = cap.read()
            frame_idx += 1
            if not ok:
                break
            target_frame, scene_no, abs_t = targets[target_i]
            if frame_idx < target_frame:
                continue
            if frame_idx > target_frame:
                target_i += 1
                continue
            if frame.shape[1] != width or frame.shape[0] != height:
                issues.append(FrameIssue("error", "FRAME_SIZE", f"Rendered frame is {frame.shape[1]}x{frame.shape[0]}", frame_idx, scene_no))
                target_i += 1
                continue
            mask = _foreground_mask(frame)
            border = np.concatenate([mask[:6, :].ravel(), mask[-6:, :].ravel(), mask[:, :6].ravel(), mask[:, -6:].ravel()])
            edge_ratio = float(np.count_nonzero(border)) / max(1, mask.size)
            if edge_ratio > 0.0018:
                issues.append(FrameIssue("warning", "FRAME_EDGE_INK", "Visible artwork reaches the raster edge", frame_idx, scene_no, metric=edge_ratio))

            info = _scene_for_time(project, abs_t)
            if not info:
                target_i += 1
                continue
            _, scene, elapsed = info
            active = _active(scene, elapsed)
            # Completed objects remain on the whiteboard. Rendered-frame QA must
            # inspect them too; otherwise a finished text label can overlap a
            # finished icon/money object while escaping the active-object check.
            visible = [o for o in scene.get('objects', []) if float(o.get('start',0)) <= elapsed + 0.02]
            is_summary = any(o.get('type') == 'summary_board' for o in scene.get('objects', []))
            if is_summary and elapsed >= float(scene.get('duration',0))*0.995:
                issues.extend(_summary_text_checks(frame, scene, width, height, frame_idx, scene_no))
                issues.extend(_summary_render_zone_checks(frame, scene, width, height, frame_idx, scene_no))
                issues.extend(_summary_ocr_checks(frame, scene, width, height, frame_idx, scene_no))
            if elapsed >= float(scene.get('duration',0))*0.96 and not is_summary:
                issues.extend(_ocr_semantic_checks(frame, scene, scene_no, width, height, frame_idx))
            for i, a in enumerate(visible):
                ba = _box(a)
                if not ba or a.get("allow_overlap") is True or a.get("type") == "summary_board":
                    continue
                for b in visible[i + 1:]:
                    if b.get("allow_overlap") is True or b.get("type") == "summary_board":
                        continue
                    bb = _box(b)
                    if not bb:
                        continue
                    x1, y1 = max(ba[0], bb[0]), max(ba[1], bb[1])
                    x2, y2 = min(ba[2], bb[2]), min(ba[3], bb[3])
                    if x2 <= x1 or y2 <= y1:
                        continue
                    # A text label may legitimately live inside a card/container,
                    # but it must not cross the container's border. Check the
                    # rendered border band separately so a label placed just past
                    # a card edge cannot hide behind the containment exemption.
                    a_text=a.get("type") in {"text","equation","number"}
                    b_text=b.get("type") in {"text","equation","number"}
                    a_rect=a.get("type") in {"round_rect","rect","highlight"}
                    b_rect=b.get("type") in {"round_rect","rect","highlight"}
                    parent_child = _pair_is_parent_child(a, b, ba, bb)
                    if (a_text and b_rect) or (b_text and a_rect):
                        text_obj=a if a_text else b; rect_obj=b if a_text else a; rb=bb if a_text else ba
                        if rect_obj.get("type") == "highlight":
                            continue
                        inset=10
                        ix1,iy1=rb[0]+inset,rb[1]+inset;ix2,iy2=rb[2]-inset,rb[3]-inset
                        tb=_box(text_obj)
                        if tb and (tb[0]<ix1 or tb[1]<iy1 or tb[2]>ix2 or tb[3]>iy2):
                            border_x1=max(tb[0],rb[0]); border_y1=max(tb[1],rb[1]); border_x2=min(tb[2],rb[2]); border_y2=min(tb[3],rb[3])
                            if border_x2>border_x1 and border_y2>border_y1:
                                bd=_ink_density(mask,(border_x1,border_y1,border_x2,border_y2))
                                if bd>0.008:
                                    issues.append(FrameIssue("error","TEXT_CONTAINER_EDGE_OVERLAP",
                                        f"Rendered text {text_obj.get('id')} crosses container {rect_obj.get('id')} border",frame_idx,scene_no,text_obj.get('id'),bd))
                    # Nested objects are often intentional: money/text inside a
                    # card, labels inside a box, chart markers inside the chart.
                    # Rendered QA should catch true sibling collisions, not valid
                    # composition containment.
                    a_contains_b=(ba[0] <= bb[0] and ba[1] <= bb[1] and ba[2] >= bb[2] and ba[3] >= bb[3])
                    b_contains_a=(bb[0] <= ba[0] and bb[1] <= ba[1] and bb[2] >= ba[2] and bb[3] >= ba[3])
                    if a_contains_b or b_contains_a or parent_child:
                        # Parent/child composition is intentional. Border
                        # crossing was already checked above; never feed this
                        # same pair into sibling collision repair.
                        continue
                    inter_density = _ink_density(mask, (x1, y1, x2, y2))
                    inter_area = (x2-x1)*(y2-y1)
                    smaller = max(1, min((ba[2]-ba[0])*(ba[3]-ba[1]), (bb[2]-bb[0])*(bb[3]-bb[1])))
                    ratio=inter_area / smaller
                    a_text=a.get("type") in {"text","equation","number"}
                    b_text=b.get("type") in {"text","equation","number"}
                    if (a_text or b_text) and not (a.get("type") in {"round_rect","rect","highlight"} or b.get("type") in {"round_rect","rect","highlight"}):
                        # Text colliding with a semantic graphic is much more severe
                        # than two decorative strokes touching. Use a lower area
                        # threshold because a short label can visibly cross a money
                        # note or icon while occupying only a small fraction of it.
                        if ratio > 0.055 and inter_density > 0.010:
                            text_obj=a if a_text else b
                            other=b if a_text else a
                            issues.append(FrameIssue("error", "TEXT_GRAPHIC_OVERLAP",
                                f"Rendered text {text_obj.get('id')} overlaps graphic {other.get('id')}",
                                frame_idx, scene_no, text_obj.get("id"), inter_density))
                    elif ratio > 0.16 and inter_density > 0.015:
                        issues.append(FrameIssue("error", "RENDER_OVERLAP", f"Rendered foreground overlaps {a.get('id')} and {b.get('id')}", frame_idx, scene_no, b.get("id"), inter_density))

            for obj in active:
                if any(o.get('type') == 'summary_board' for o in scene.get('objects', [])):
                    continue
                if obj.get("type") not in {"text", "equation", "number"}:
                    continue
                st = float(obj.get("start", 0)); od = float(obj.get("duration", 1))
                if elapsed < st + 0.90 * od:
                    continue
                box = _box(obj)
                if not box:
                    continue
                text_value = str(obj.get("text", obj.get("value", ""))).strip()
                d = _ink_density(mask, box)
                if d < 0.0015 and len(text_value) > 1 and float(obj.get("size",46)) >= 24:
                    # Bounding boxes are intentionally conservative for hand-drawn
                    # text and can include substantial empty whitespace. Before
                    # declaring malformed/vanished text, corroborate with the
                    # deterministic glyph-template matcher used by OCR QA. This
                    # prevents false failures when the raster contains the text
                    # but the coarse density metric is diluted by a large bbox.
                    try:
                        coverage, _ = _expected_text_presence(
                            frame, text_value, box,
                            int(float(obj.get("size", 46))),
                            bool(obj.get("bold", False))
                        )
                    except Exception:
                        coverage = 0.0
                    coverage_threshold = 0.45 if len(text_value) < 12 else 0.55
                    if coverage < coverage_threshold:
                        issues.append(FrameIssue("error", "MALFORMED_TEXT", "Expected text region contains almost no rendered ink", frame_idx, scene_no, obj.get("id"), d))
                elif d > 0.34 and len(text_value) >= 4:
                    issues.append(FrameIssue("warning", "TEXT_OVERDENSE", "Text region is unusually dense; possible overwrite/garbling", frame_idx, scene_no, obj.get("id"), d))

            if hand:
                moving = [o for o in active if o.get("type") != "summary_board" and o.get("hand_follow", True) is not False and elapsed < float(o.get("start", 0)) + float(o.get("duration", 1)) * 0.98]
                if moving:
                    obj = moving[-1]
                    st=float(obj.get("start",0)); od=max(0.001,float(obj.get("duration",1)))
                    progress=max(0.0,min(1.0,(elapsed-st)/od))
                    if progress < 0.65:
                        target_i += 1
                        continue
                    # Text has a distributed raster footprint rather than a single
                    # stroke endpoint. Use the whole expected text region first to
                    # avoid false positives caused by font side-bearings.
                    if obj.get("type") in {"text","equation","number"}:
                        # OCR/template QA is authoritative for text. A hand tip can
                        # legitimately sit just beyond the final glyph, so do not
                        # treat font side-bearings as a stroke mismatch.
                        continue
                    ex, ey = _endpoint(obj, elapsed); cx, cy = int(round(ex)), int(round(ey)); r = 30
                    x1, y1, x2, y2 = max(0,cx-r), max(0,cy-r), min(width,cx+r), min(height,cy+r)
                    local = mask[y1:y2, x1:x2]
                    density = float(np.count_nonzero(local)) / max(1, local.size)
                    if density < 0.003:
                        issues.append(FrameIssue("warning", "HAND_STROKE_MISMATCH", "Active hand endpoint has no nearby rendered stroke/hand pixels", frame_idx, scene_no, obj.get("id"), density))

            small = cv2.resize(frame, (32, 18), interpolation=cv2.INTER_AREA); gray = cv2.cvtColor(small, cv2.COLOR_BGR2GRAY)
            mean = float(gray.mean()); bits = (gray > mean).flatten(); ph = 0
            for bit in bits: ph = (ph << 1) | int(bool(bit))
            hashes.append((scene_no, ph))
            target_i += 1
    finally:
        cap.release()

    for scene_no, scene in enumerate(project.get('scenes',[]),1):
        issues.extend(_static_visual_check(scene,scene_no))
        issues.extend(_semantic_scene_checks(scene,scene_no))

    by_scene: dict[int, list[int]] = {}
    for scene_no, ph in hashes: by_scene.setdefault(scene_no, []).append(ph)
    for scene_no, hs in by_scene.items():
        scene_obj = project.get("scenes", [])[scene_no-1] if 0 < scene_no <= len(project.get("scenes", [])) else {}
        is_summary = any(o.get("type") == "summary_board" for o in scene_obj.get("objects", []))
        if is_summary:
            continue  # a recap is intentionally static after its reveal
        if len(hs) >= 3:
            distances=[(a^b).bit_count() for a,b in zip(hs,hs[1:])]
            if max(distances, default=1) <= 2:
                issues.append(FrameIssue("warning", "VISUAL_REPETITION", "Sampled rendered frames are nearly identical throughout the scene", scene=scene_no, metric=float(max(distances, default=0))))

    if _ocr_engine() is None:
        issues.append(FrameIssue("error", "OCR_RUNTIME_UNAVAILABLE", "Tesseract/pytesseract is required for strict semantic rendered-frame QA"))
    errors = [i for i in issues if i.severity == "error"]
    return {"ok": not errors, "issues": [asdict(i) for i in issues], "samples": len(samples), "frame_count": frame_count, "ocr_available": _ocr_engine() is not None}


def repair_project_for_visual_qa(project: dict[str, Any], report: dict[str, Any], width=1280, height=720) -> tuple[dict[str, Any], list[str]]:
    """Apply bounded deterministic repairs; never invent new teaching content."""
    from copy import deepcopy
    from .scene_graph import normalize_project
    out = deepcopy(project)
    actions=[]
    error_codes={i.get("code") for i in report.get("issues",[]) if i.get("severity")=="error"}
    warning_codes={i.get("code") for i in report.get("issues",[]) if i.get("severity")=="warning"}

    # Repair only concrete preflight geometry defects. Do NOT turn on global
    # auto-layout for authored scenes: that can move labels out of intentionally
    # designed cards. Rendered-frame QA remains the authority for true collisions.
    for issue in report.get("issues",[]):
        if issue.get("code") != "NEAR_EDGE" or not issue.get("object_id"):
            continue
        oid=issue.get("object_id")
        for scene in out.get("scenes",[]):
            for obj in scene.get("objects",[]):
                if obj.get("id") != oid or obj.get("type") == "summary_board":
                    continue
                from .scene_graph import object_bbox
                b=object_bbox(obj)
                if not b: continue
                dx=0.0; dy=0.0
                if b.x < 60: dx += 60-b.x
                if b.x2+dx > width-60: dx += (width-60)-(b.x2+dx)
                if b.y < 45: dy += 45-b.y
                if b.y2+dy > height-45: dy += (height-45)-(b.y2+dy)
                for k in ('x','x2'):
                    if k in obj: obj[k]=float(obj[k])+dx
                for k in ('y','y2'):
                    if k in obj: obj[k]=float(obj[k])+dy
                actions.append(f"moved near-edge object {oid} into safe bounds")

    # Do NOT turn on global auto-layout after raster QA. Authored scenes may use
    # intentional parent/container geometry; global repacking can move text away
    # from its diagram or even place it below the card it labels. Rendered QA
    # therefore triggers targeted repairs only.
    if {"RENDER_OVERLAP","TEXT_GRAPHIC_OVERLAP","TEXT_CONTAINER_EDGE_OVERLAP","TEXT_OVERDENSE","FRAME_EDGE_INK","MALFORMED_TEXT"} & (error_codes | warning_codes):
        actions.append("kept authored scene geometry; applied targeted visual repairs only")

    handled_repairs=set()
    for issue in report.get("issues",[]):
        code=issue.get("code")
        repair_key=(code, issue.get("scene"), issue.get("object_id"))
        if repair_key in handled_repairs and code in {"TEXT_CONTAINER_EDGE_OVERLAP","TEXT_GRAPHIC_OVERLAP","TEXT_OVERDENSE","MALFORMED_TEXT","HAND_STROKE_MISMATCH","SUMMARY_TEXT_CLIPPED","OCR_TEXT_MISMATCH"}:
            continue
        handled_repairs.add(repair_key)
        if code == "STATIC_HOLD" and issue.get("scene"):
            idx=int(issue.get("scene"))-1
            if 0 <= idx < len(out.get("scenes",[])):
                out["scenes"][idx]["visual_accent_pulse"] = True
                actions.append(f"added motion cue to static scene {issue.get('scene')}")
            continue
        oid=issue.get("object_id")
        if not oid:
            continue
        for scene in out.get("scenes",[]):
            for obj in scene.get("objects",[]):
                if obj.get("id") != oid:
                    continue
                code=issue.get("code")
                if code == "TEXT_CONTAINER_EDGE_OVERLAP":
                    # Reflow the child INSIDE its parent card. Older v4.2 logic
                    # moved it outside, which could immediately create a second
                    # sibling collision. v4.3 treats the composition as a unit.
                    import re as _re
                    msg=str(issue.get("message","")); m=_re.search(r"container ([^ ]+)",msg); cid=m.group(1) if m else None
                    rect=None
                    for candidate in scene.get("objects",[]):
                        if candidate.get("id")==cid and candidate.get("type") in CONTAINER_TYPES:
                            rect=candidate; break
                    if rect is not None:
                        rx=float(rect.get("x",0)); ry=float(rect.get("y",0))
                        rx2=float(rect.get("x2",rx+200)); ry2=float(rect.get("y2",ry+100))
                        pad=20.0
                        text=str(obj.get("text",obj.get("value","")))
                        from .renderer_worldclass import _text_metrics
                        from .scene_graph import object_bbox
                        size=float(obj.get("size",46)); bold=bool(obj.get("bold",False))
                        max_w=max(60.0,rx2-rx-2*pad)
                        # Use the same conservative bbox model as QA, not only
                        # font advance metrics. This prevents a repair from
                        # appearing safe to the renderer but still failing the
                        # next raster inspection.
                        def conservative_width(sz):
                            return max(20.0, len(text) * sz * 0.52 * float(obj.get("scale",1)))
                        while size>18 and conservative_width(size) > max_w:
                            size-=1
                        obj["size"]=round(size,1)
                        tw=max(20.0, conservative_width(size))
                        th=max(1.0, size*1.25*float(obj.get("scale",1)))
                        max_x=rx2-pad-tw; max_y=ry2-pad-th
                        min_x=rx+pad; min_y=ry+pad
                        candidates=[
                            (float(obj.get("x",min_x)),float(obj.get("y",min_y))),
                            (min_x,min_y),
                            (min_x,max_y),
                            (max_x,min_y),
                            (max_x,max_y),
                            (rx+(rx2-rx-tw)/2, ry+(ry2-ry-th)/2),
                        ]
                        # Avoid other child graphics (money, icons, labels).
                        def overlap_area(a,b):
                            x1=max(a[0],b[0]); y1=max(a[1],b[1]); x2=min(a[2],b[2]); y2=min(a[3],b[3])
                            return max(0,x2-x1)*max(0,y2-y1)
                        other_boxes=[]
                        for other in scene.get("objects",[]):
                            if other is obj or other.get("id")==cid or other.get("type") in {"space","summary_board"}:
                                continue
                            ob=_box(other)
                            if ob: other_boxes.append(ob)
                        best=None
                        for cx,cy in candidates:
                            cx=max(min_x,min(max_x,cx)); cy=max(min_y,min(max_y,cy))
                            tb=(int(cx),int(cy),int(cx+tw),int(cy+th))
                            score=sum(overlap_area(tb,ob) for ob in other_boxes)
                            # Prefer the current position when it is already safe;
                            # otherwise prefer the least-colliding deterministic slot.
                            dist=abs(cx-float(obj.get("x",cx)))+abs(cy-float(obj.get("y",cy)))
                            key=(score,dist)
                            if best is None or key<best[0]:
                                best=(key,cx,cy)
                        _,obj["x"],obj["y"]=best
                        obj["parent"]=cid
                        obj["composition"]="parent_child"
                    else:
                        obj["x"]=min(width-300.0,float(obj.get("x",0))+120.0)
                        obj["y"]=min(height-90.0,float(obj.get("y",0))+70.0)
                    actions.append(f"reflowed text {oid} inside parent container {cid or 'unknown'}")
                elif code == "TEXT_GRAPHIC_OVERLAP":
                    x=float(obj.get("x",0)); y=float(obj.get("y",0))
                    obj["x"]=max(70.0,x-180.0) if x>width*0.68 else min(width-300.0,x+120.0)
                    if y>height*0.65: obj["y"]=max(70.0,y-90.0)
                    obj["size"]=round(max(20.0,float(obj.get("size",46))*0.92),1)
                    actions.append(f"moved overlapping text {oid} into a clean label zone")
                elif code == "TEXT_OVERDENSE":
                    obj["size"]=round(max(22,float(obj.get("size",46))*0.88),1)
                    obj["color"]="#20242B"
                    actions.append(f"reduced text size for {oid}")
                elif code == "MALFORMED_TEXT":
                    # Rebuild the object from a clean text value if possible;
                    # normalization has already removed control characters.
                    text=str(obj.get("text",obj.get("value",""))).strip()
                    if text:
                        obj["text"]=text
                        obj["bold"]=bool(obj.get("bold",False))
                        obj["size"]=round(max(24,float(obj.get("size",46))*0.92),1)
                        actions.append(f"re-normalized and resized text {oid}")
                elif code == "HAND_STROKE_MISMATCH":
                    # Keep the drawing itself correct; disable hand only for this
                    # object rather than hiding the entire lesson.
                    obj["hand_follow"] = False
                    actions.append(f"disabled hand-follow for {oid}")
                elif code == "SUMMARY_TEXT_CLIPPED" and obj.get("type") == "summary_board":
                    obj["reveal_seconds"] = max(float(obj.get("reveal_seconds", 6.0)), 4.0)
                    obj["summary_safe_mode"] = True
                    actions.append("enabled summary safe-mode and full-copy reveal")
    if "SUMMARY_ICON_COPY_OVERLAP" in error_codes or "SUMMARY_COPY_INCOMPLETE" in error_codes or "SUMMARY_OCR_MISMATCH" in error_codes or "SUMMARY_ICON_DUPLICATE" in error_codes:
        for scene in out.get("scenes",[]):
            boards=[o for o in scene.get("objects",[]) if o.get("type")=="summary_board"]
            if not boards: continue
            board=boards[0]
            board["summary_safe_mode"]=True
            cards=board.get("cards",[])
            used=set()
            # Deterministically assign distinct semantic icons based on title.
            choices=["base","return_growth","curve","retrieve","context","generate","basket","share","trade","raw_data","window","average","result","question","mechanism"]
            for card in cards:
                title=str(card.get("title","")).lower()
                icon=str(card.get("icon","")).lower()
                if icon in used or not icon:
                    if any(k in title for k in ("base","capital","principal","money")): cand="base"
                    elif any(k in title for k in ("return","gain","interest","growth")): cand="return_growth"
                    elif any(k in title for k in ("curve","trend","result","signal")): cand="curve"
                    elif any(k in title for k in ("retrieve","search","find")): cand="retrieve"
                    elif any(k in title for k in ("augment","context","evidence")): cand="context"
                    elif any(k in title for k in ("generate","answer","model")): cand="generate"
                    elif any(k in title for k in ("basket","holdings")): cand="basket"
                    elif any(k in title for k in ("share",)): cand="share"
                    elif any(k in title for k in ("trade","tradable","wrapper")): cand="trade"
                    elif any(k in title for k in ("raw","data","noise")): cand="raw_data"
                    elif any(k in title for k in ("window",)): cand="window"
                    elif any(k in title for k in ("average","move")): cand="average"
                    elif any(k in title for k in ("question",)): cand="question"
                    else: cand="result"
                    if cand in used:
                        cand=next((c for c in choices if c not in used),"result")
                    card["icon"]=cand
                used.add(str(card.get("icon","")).lower())
                # Shorter copy is preferable to tiny type; only tighten if the
                # authored takeaway is clearly overlong.
                text=str(card.get("takeaway","")).strip()
                if len(text)>105:
                    words=text.split(); cut=[]; n=0
                    for word in words:
                        if n+len(word)+(1 if cut else 0)>105: break
                        cut.append(word); n+=len(word)+(1 if cut else 0)
                    card["takeaway"]=" ".join(cut).rstrip(" ,;:")+"."
            board["reveal_seconds"]=max(float(board.get("reveal_seconds",4.0)),4.2)
            actions.append("enabled compact summary safe-mode, unique semantic icons, and bounded takeaway copy")
            break
    if "OCR_TEXT_MISMATCH" in error_codes:
        # Scene-level OCR failures are usually presentation defects. Repair the
        # affected scene conservatively: hold text to the scene end, keep it inside
        # a wider safe margin, and shrink only long labels.
        affected={int(i.get("scene"))-1 for i in report.get("issues",[]) if i.get("code")=="OCR_TEXT_MISMATCH" and i.get("scene")}
        for idx,scene in enumerate(out.get("scenes",[])):
            if affected and idx not in affected: continue
            for obj in scene.get("objects",[]):
                if obj.get("type") not in {"text","equation","number"}: continue
                # Keep the authored timing. Extending every text object to the
                # scene end makes the hand animate for too long and can turn a
                # small repair into a slow render. Final raster QA already checks
                # the completed hold.
                text=str(obj.get("text",obj.get("value",""))).strip()
                if len(text)>=8:
                    obj["size"] = round(max(20,float(obj.get("size",46))*0.90),1)
                # Keep long labels away from the right/bottom raster boundary.
                if float(obj.get("x",0)) > width-330:
                    obj["x"] = max(70.0,width-430.0)
                if float(obj.get("y",0)) > height-105:
                    obj["y"] = max(60.0,height-170.0)
        actions.append("repaired OCR-mismatched scene text with full holds, conservative sizing, and expanded safe margins")
    if "SEMANTIC_TEXT_SLIDE" in error_codes:
        for issue in report.get("issues",[]):
            if issue.get("code") != "SEMANTIC_TEXT_SLIDE" or not issue.get("scene"):
                continue
            idx=int(issue["scene"])-1
            if 0 <= idx < len(out.get("scenes",[])):
                scene=out["scenes"][idx]
                # Give an otherwise text-only scene a neutral visual anchor. This
                # is a presentation repair, not a new factual claim.
                scene.setdefault("objects",[]).insert(0,{
                    "type":"target","x":170,"y":300,"scale":0.8,"start":0.25,"duration":0.7,
                    "color":"#4F46E5","semantic_role":"visual_anchor","teaching_job":"attention_anchor","generated_by":"visual_qa_repair","authored":False,"repair_priority":"generated"
                })
                scene["visual_accent_pulse"] = True
        actions.append("added a neutral visual anchor to text-only teaching scenes")
    if "SEMANTIC_FLOW_WEAK" in warning_codes:
        for issue in report.get("issues",[]):
            if issue.get("code") != "SEMANTIC_FLOW_WEAK" or not issue.get("scene"):
                continue
            idx=int(issue["scene"])-1
            if 0 <= idx < len(out.get("scenes",[])):
                scene=out["scenes"][idx]
                visuals=[o for o in scene.get("objects",[]) if o.get("type") not in {"text","equation","number","space","summary_board"}]
                if len(visuals)>=2 and not any(o.get("type") in {"arrow","line","chart","trend","pipeline"} for o in visuals):
                    a,b=visuals[0],visuals[-1]
                    ax=float(a.get("x",150))+55*float(a.get("scale",1)); ay=float(a.get("y",280))+35*float(a.get("scale",1))
                    bx=float(b.get("x",850))+55*float(b.get("scale",1)); by=float(b.get("y",280))+35*float(b.get("scale",1))
                    scene.setdefault("objects",[]).append({
                        "type":"arrow","x":min(ax,bx)+30,"y":ay,"x2":max(ax,bx)-30,"y2":by,
                        "start":0.55,"duration":0.65,"color":"#4F46E5","semantic_role":"relationship","teaching_job":"show_transformation","generated_by":"visual_qa_repair","authored":False,"repair_priority":"generated","relationship":"transformation"
                    })
                scene["visual_accent_pulse"] = True
        actions.append("prepared candidate flow arrows for semantic transformation scenes")

    if "VISUAL_REPETITION" in warning_codes:
        for scene in out.get("scenes",[]):
            # Add a subtle camera drift only where the model has not requested a
            # deliberate static composition. This changes pixels without inventing
            # content and makes long explanatory holds feel alive.
            scene["visual_accent_pulse"] = True
        actions.append("added a lightweight animated accent to visually repetitive scenes")

    out=normalize_project(out)
    return out, actions

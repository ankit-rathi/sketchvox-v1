import json


def _valid_answer():
    return {
        "canonical_question": "What is photosynthesis?",
        "one_sentence_answer": "Plants use light energy to make glucose from water and carbon dioxide while releasing oxygen.",
        "must_explain": ["light energy", "raw materials", "products"],
        "useful_example": "A green leaf uses sunlight, water and carbon dioxide to make sugar.",
        "must_not_confuse_with": ["cellular respiration"],
        "final_mental_model": "Light powers a plant system that turns water and carbon dioxide into stored chemical energy and oxygen.",
        "concepts": [
            {"name": "Light energy", "explanation": "Sunlight supplies the energy that drives photosynthesis."},
            {"name": "Raw materials", "explanation": "Plants use water and carbon dioxide as the main inputs."},
            {"name": "Products", "explanation": "Photosynthesis makes glucose and releases oxygen."},
        ],
    }


def test_answer_schema_requires_topic_specific_concept_explanations():
    from whiteboard_engine.storyboard import ANSWER_IR_SCHEMA
    item = ANSWER_IR_SCHEMA["properties"]["concepts"]["items"]
    assert item["required"] == ["name", "explanation"]
    assert item["properties"]["explanation"]["minLength"] == 1


def test_lock_answer_ir_rejects_named_but_unexplained_concepts():
    from whiteboard_engine.answer_ir import lock_answer_ir
    raw = _valid_answer()
    raw["concepts"][1].pop("explanation")
    try:
        lock_answer_ir("Explain photosynthesis", raw)
    except ValueError as exc:
        assert "concept 2 is missing an explanation" in str(exc)
    else:
        raise AssertionError("unexplained concept was accepted")


def test_stale_malformed_answer_cache_is_ignored_and_model_is_called(monkeypatch, tmp_path):
    import whiteboard_engine.storyboard as sb
    monkeypatch.setenv("SKETCHVOX_CACHE", "1")
    monkeypatch.setenv("SKETCHVOX_CACHE_DIR", str(tmp_path / "cache"))
    stale = _valid_answer()
    stale["concepts"][0].pop("explanation")
    calls = []

    def fake_load(provider, model, prompt):
        if provider.endswith("_answer"):
            return {"answer_ir": stale}
        return None

    def fake_generate(prompt, model, schema, system, **kwargs):
        calls.append(kwargs.get("stage"))
        if kwargs.get("stage") == "answer_architect":
            return _valid_answer()
        raise RuntimeError("visual timeout")

    monkeypatch.setattr(sb, "_load_cache", fake_load)
    monkeypatch.setattr(sb, "generate_ollama", fake_generate)
    out = sb.generate("Explain photosynthesis", provider="ollama", model="qwen3:test", strict=False, duration=45)
    assert calls == ["answer_architect", "visual_director"]
    assert out["meta"]["coverage_gate"]["ok"]
    assert all(c.get("explanation") for c in out["meta"]["answer_ir"]["concepts"])


def test_cache_schema_was_bumped_for_answer_contract():
    from whiteboard_engine.teaching_providers import _cache_key
    key = _cache_key("ollama_answer", "qwen3:8b", "x")
    # SHA-256 hex output proves the key is still deterministic; the schema bump
    # itself is asserted by inspecting the implementation contract below.
    assert len(key) == 64

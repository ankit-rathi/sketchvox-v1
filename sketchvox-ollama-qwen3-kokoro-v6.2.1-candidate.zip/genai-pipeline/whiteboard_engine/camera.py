"""Camera choreography: subtle deterministic pans/zooms driven by semantic targets."""
from __future__ import annotations
from .scene_graph import object_bbox
from PIL import Image

def camera_for_scene(scene, width=1280, height=720):
    c=scene.get("camera") or {}
    return {
        "enabled": bool(c.get("enabled",False)),
        "start_zoom": float(c.get("start_zoom",1.0)),
        "end_zoom": float(c.get("end_zoom",1.0)),
        "target": c.get("target"),
        "pan_x": float(c.get("pan_x",0)), "pan_y": float(c.get("pan_y",0)),
    }

def frame_transform(frame, scene, p, width, height):
    c=camera_for_scene(scene,width,height)
    if not c["enabled"]: return frame
    zoom=c["start_zoom"]+(c["end_zoom"]-c["start_zoom"])*max(0,min(1,p))
    tx,ty=width/2+c["pan_x"],height/2+c["pan_y"]
    target=c["target"]
    if target:
        for obj in scene.get("objects",[]):
            if obj.get("id")==target:
                b=object_bbox(obj)
                if b: tx,ty=b.x+b.w/2,b.y+b.h/2
                break
    if abs(zoom-1)<1e-4 and tx==width/2 and ty==height/2: return frame
    crop_w=width/zoom; crop_h=height/zoom
    left=max(0,min(width-crop_w,tx-crop_w/2)); top=max(0,min(height-crop_h,ty-crop_h/2))
    crop=frame.crop((int(left),int(top),int(left+crop_w),int(top+crop_h)))
    return crop.resize((width,height), Image.Resampling.LANCZOS)

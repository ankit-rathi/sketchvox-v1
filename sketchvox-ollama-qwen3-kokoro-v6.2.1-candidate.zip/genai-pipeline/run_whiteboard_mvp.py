import argparse, json, os, sys
from pathlib import Path
from whiteboard_engine.dsl import validate_storyboard, load_storyboard
from whiteboard_engine.renderer import render_storyboard
from whiteboard_engine.finance_examples import compound_interest_demo
from whiteboard_engine.renderer_worldclass import render_worldclass
from whiteboard_engine.deterministic_director import build_plan


def main():
    ap=argparse.ArgumentParser(description="Deterministic finance/Data/AI whiteboard MVP")
    ap.add_argument("--storyboard", help="Path to storyboard JSON")
    ap.add_argument("--demo", action="store_true", help="Render built-in Worldclass compound-interest demo")
    ap.add_argument("--legacy-demo", action="store_true", help="Render the original MVP demo renderer")
    ap.add_argument("--out", default="output/whiteboard_mvp")
    args=ap.parse_args()
    if args.demo and args.legacy_demo:
        ap.error("choose --demo or --legacy-demo, not both")
    if args.demo:
        doc=build_plan("compound interest")
        out=Path(args.out)
        out.mkdir(parents=True,exist_ok=True)
        storyboard_path=out/"storyboard.json"
        storyboard_path.write_text(json.dumps(doc,indent=2,ensure_ascii=False),encoding="utf-8")
        final=out/"compound_interest_worldclass.mp4"
        print("Rendered:", render_worldclass(doc,final))
        return
    elif args.legacy_demo:
        doc=compound_interest_demo()
    elif args.storyboard:
        doc=load_storyboard(args.storyboard)
    else:
        ap.error("use --demo, --legacy-demo, or --storyboard")
    errors=validate_storyboard(doc)
    if errors:
        print("Storyboard validation failed:")
        for e in errors: print(" -",e)
        sys.exit(2)
    Path(args.out).mkdir(parents=True,exist_ok=True)
    (Path(args.out)/"storyboard.json").write_text(json.dumps(doc,indent=2,ensure_ascii=False),encoding="utf-8")
    final, scenes=render_storyboard(doc,args.out)
    print("Rendered:",final)
    for p in scenes: print("Scene:",p)

if __name__ == "__main__": main()

"""Reusable hand-drawn semantic stroke assets for SketchVox."""
from __future__ import annotations
import math

def strokes(name,x,y,s=1):
    r=[]
    if name=="coin":
        r=[[(x+32*s*math.cos(a),y+32*s*math.sin(a)) for a in [i*2*math.pi/36 for i in range(37)]],[(x-16*s,y),(x+16*s,y)]]
    elif name=="bank":
        r=[[(x,y+25*s),(x+140*s,y+25*s),(x+70*s,y-25*s),(x,y+25*s)],[(x+14*s,y+25*s),(x+14*s,y+105*s)],[(x+60*s,y+25*s),(x+60*s,y+105*s)],[(x+106*s,y+25*s),(x+106*s,y+105*s)],[(x,y+105*s),(x+140*s,y+105*s)]]
    elif name=="database":
        r=[[(x+70*s,y),(x+125*s,y+15*s),(x+70*s,y+30*s),(x+15*s,y+15*s),(x+70*s,y)],[(x+15*s,y+15*s),(x+15*s,y+95*s),(x+70*s,y+110*s),(x+125*s,y+95*s),(x+125*s,y+15*s)],[(x+15*s,y+55*s),(x+70*s,y+70*s),(x+125*s,y+55*s)],[(x+18*s,y+92*s),(x+70*s,y+105*s),(x+122*s,y+92*s)]]
    elif name=="cloud":
        r=[[(x,y+55*s),(x+20*s,y+25*s),(x+55*s,y+28*s),(x+75*s,y),(x+110*s,y+10*s),(x+125*s,y+45*s),(x+150*s,y+55*s),(x+135*s,y+80*s),(x+20*s,y+80*s),(x,y+55*s)]]
    elif name=="check": r=[[(x,y+25*s),(x+25*s,y+50*s),(x+78*s,y)]]
    elif name=="cross": r=[[(x,y),(x+55*s,y+55*s)],[(x+55*s,y),(x,y+55*s)]]
    elif name=="magnifier": r=[[(x+35*s*math.cos(a),y+35*s*math.sin(a)) for a in [i*2*math.pi/32 for i in range(33)]],[(x+25*s,y+25*s),(x+70*s,y+70*s)]]
    elif name=="warning": r=[[(x+35*s,y),(x+70*s,y+65*s),(x,y+65*s),(x+35*s,y)],[(x+35*s,y+18*s),(x+35*s,y+42*s)]]
    elif name=="server": r=[[(x,y),(x+130*s,y),(x+130*s,y+100*s),(x,y+100*s),(x,y)],[(x+15*s,y+25*s),(x+25*s,y+25*s)],[(x+15*s,y+55*s),(x+25*s,y+55*s)]]
    elif name=="wallet": r=[[(x,y+20*s),(x+115*s,y+20*s),(x+135*s,y+45*s),(x+135*s,y+95*s),(x,y+95*s),(x,y+20*s)],[(x+80*s,y+45*s),(x+135*s,y+45*s)],[(x+105*s,y+65*s),(x+118*s,y+65*s)]]
    elif name=="spark": r=[[(x,y-34*s),(x,y+34*s)],[(x-34*s,y),(x+34*s,y)],[(x-24*s,y-24*s),(x+24*s,y+24*s)],[(x-24*s,y+24*s),(x+24*s,y-24*s)]]
    elif name=="shield":
        r=[[(x+45*s,y),(x+85*s,y+16*s),(x+78*s,y+68*s),(x+45*s,y+95*s),(x+12*s,y+68*s),(x+5*s,y+16*s),(x+45*s,y)],[(x+25*s,y+48*s),(x+40*s,y+63*s),(x+68*s,y+30*s)]]
    elif name=="target":
        r=[[(x+45*s,y+5*s),(x+77*s,y+18*s),(x+90*s,y+50*s),(x+77*s,y+82*s),(x+45*s,y+95*s),(x+13*s,y+82*s),(x,y+50*s),(x+13*s,y+18*s),(x+45*s,y+5*s)],[(x+45*s,y+27*s),(x+60*s,y+35*s),(x+67*s,y+50*s),(x+60*s,y+65*s),(x+45*s,y+73*s),(x+30*s,y+65*s),(x+23*s,y+50*s),(x+30*s,y+35*s),(x+45*s,y+27*s)],[(x+45*s,y+43*s),(x+52*s,y+50*s),(x+45*s,y+57*s),(x+38*s,y+50*s),(x+45*s,y+43*s)]]
    elif name=="trend":
        r=[[(x,y+90*s),(x+35*s,y+62*s),(x+65*s,y+72*s),(x+100*s,y+38*s),(x+145*s,y+8*s)],[(x+115*s,y+8*s),(x+145*s,y+8*s),(x+145*s,y+38*s)]]
    elif name=="stack":
        r=[[(x+12*s,y+10*s),(x+92*s,y+10*s),(x+110*s,y+22*s),(x+30*s,y+22*s),(x+12*s,y+10*s)],[(x+12*s,y+35*s),(x+92*s,y+35*s),(x+110*s,y+47*s),(x+30*s,y+47*s),(x+12*s,y+35*s)],[(x+12*s,y+60*s),(x+92*s,y+60*s),(x+110*s,y+72*s),(x+30*s,y+72*s),(x+12*s,y+60*s)]]
    elif name=="cpu":
        r=[[(x+20*s,y+20*s),(x+95*s,y+20*s),(x+95*s,y+95*s),(x+20*s,y+95*s),(x+20*s,y+20*s)],[(x+40*s,y+40*s),(x+75*s,y+40*s),(x+75*s,y+75*s),(x+40*s,y+75*s),(x+40*s,y+40*s)]]
        for q in (32,52,72):
            r += [[(x+q*s,y+5*s),(x+q*s,y+20*s)],[(x+q*s,y+95*s),(x+q*s,y+110*s)],[(x+5*s,y+q*s),(x+20*s,y+q*s)],[(x+95*s,y+q*s),(x+110*s,y+q*s)]]
    elif name=="filter":
        r=[[(x,y),(x+120*s,y),(x+78*s,y+48*s),(x+78*s,y+100*s),(x+48*s,y+85*s),(x+48*s,y+48*s),(x,y)]]
    elif name=="link":
        r=[[(x+35*s,y+35*s),(x+52*s,y+18*s),(x+78*s,y+18*s),(x+92*s,y+32*s),(x+92*s,y+48*s)],[(x+65*s,y+65*s),(x+48*s,y+82*s),(x+22*s,y+82*s),(x+8*s,y+68*s),(x+8*s,y+52*s)],[(x+40*s,y+62*s),(x+62*s,y+40*s)]]
    elif name=="calendar":
        r=[[(x+10*s,y+20*s),(x+100*s,y+20*s),(x+100*s,y+100*s),(x+10*s,y+100*s),(x+10*s,y+20*s)],[(x+10*s,y+40*s),(x+100*s,y+40*s)],[(x+30*s,y+5*s),(x+30*s,y+28*s)],[(x+80*s,y+5*s),(x+80*s,y+28*s)]]
    elif name=="book":
        r=[[(x+10*s,y+10*s),(x+55*s,y+20*s),(x+55*s,y+105*s),(x+10*s,y+95*s),(x+10*s,y+10*s)],[(x+55*s,y+20*s),(x+100*s,y+10*s),(x+100*s,y+95*s),(x+55*s,y+105*s)]]
    elif name=="folder": r=[[(x,y+20*s),(x+38*s,y+20*s),(x+50*s,y+8*s),(x+120*s,y+8*s),(x+135*s,y+25*s),(x+125*s,y+90*s),(x,y+90*s),(x,y+20*s)]]
    return r

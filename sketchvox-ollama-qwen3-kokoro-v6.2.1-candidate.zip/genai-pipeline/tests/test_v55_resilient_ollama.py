import json


def _answer():
    return {
        "canonical_question": "What is photosynthesis?",
        "one_sentence_answer": "Photosynthesis is how plants use light energy to make glucose from water and carbon dioxide, releasing oxygen.",
        "must_explain": ["light energy", "water and carbon dioxide", "glucose and oxygen"],
        "useful_example": "A green leaf uses sunlight, water and carbon dioxide to make food for the plant.",
        "must_not_confuse_with": ["cellular respiration"],
        "final_mental_model": "Light powers a plant's conversion of water and carbon dioxide into stored chemical energy, with oxygen released.",
        "concepts": [
            {"id": "c1", "name": "Light energy", "explanation": "Sunlight provides the energy that drives the process."},
            {"id": "c2", "name": "Water and carbon dioxide", "explanation": "Plants use water and carbon dioxide as the main raw materials."},
            {"id": "c3", "name": "Glucose and oxygen", "explanation": "The process produces glucose as stored chemical energy and releases oxygen."},
        ],
    }


def test_ollama_payload_requests_keep_alive(monkeypatch, tmp_path):
    from whiteboard_engine import teaching_providers as tp
    seen = {}

    class Resp:
        def __enter__(self): return self
        def __exit__(self, *args): pass
        def read(self): return json.dumps({"message": {"content": "{}"}}).encode()

    def fake_urlopen(req, timeout):
        seen["payload"] = json.loads(req.data.decode())
        seen["timeout"] = timeout
        return Resp()

    monkeypatch.setattr(tp.urllib.request, "urlopen", fake_urlopen)
    tp.generate_ollama("x", "qwen3:8b", {"type": "object"}, "sys", timeout=17, validate_scene=False, stage="test")
    assert seen["payload"]["keep_alive"] == "10m"
    assert seen["timeout"] == 17


def test_visual_timeout_compiles_from_locked_answer_ir(monkeypatch, tmp_path):
    import whiteboard_engine.storyboard as sb
    monkeypatch.setenv("SKETCHVOX_CACHE", "0")
    monkeypatch.setenv("SKETCHVOX_CACHE_DIR", str(tmp_path / "cache"))
    calls = []

    def fake(prompt, model, schema, system, **kwargs):
        calls.append(kwargs.get("stage"))
        if kwargs.get("stage") == "answer_architect":
            return _answer()
        raise RuntimeError("Ollama visual_director request timed out after 1s.")

    monkeypatch.setattr(sb, "generate_ollama", fake)
    out = sb.generate("Explain photosynthesis to a class-10 student", provider="ollama", model="qwen3:test", strict=False, duration=45)
    assert calls == ["answer_architect", "visual_director"]
    assert out["meta"]["fallback"] == "semantic_compiler"
    assert out["meta"]["answer_ir"]["concepts"]
    assert out["meta"]["coverage_gate"]["ok"]
    assert out["meta"]["summary_contract"].startswith("one_final_summary")
    assert any("Light energy" in str(o) for s in out["scenes"] for o in s.get("objects", []))

"""Teaching-model providers for SketchVox.

Default: local Ollama + Qwen3. Cloud Gemini remains available as an optional
provider. All providers return the same validated SketchVox scene graph.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any

from .schema import validate_scene_graph
from .asset_resolver import resolve_scene_graph


def _cache_dir() -> Path:
    p = Path(os.getenv("SKETCHVOX_CACHE_DIR", ".sketchvox_cache")) / "storyboards"
    p.mkdir(parents=True, exist_ok=True)
    return p


def _cache_key(provider: str, model: str, prompt: str) -> str:
    payload = json.dumps({"cache_schema": "6.2.1", "provider": provider, "model": model, "prompt": prompt}, sort_keys=True, ensure_ascii=False)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def _load_cache(provider: str, model: str, prompt: str) -> dict[str, Any] | None:
    if os.getenv("SKETCHVOX_CACHE", "1").lower() in {"0", "false", "no"}:
        return None
    p = _cache_dir() / f"{_cache_key(provider, model, prompt)}.json"
    if not p.exists():
        return None
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return None


def _save_cache(provider: str, model: str, prompt: str, doc: dict[str, Any]) -> None:
    if os.getenv("SKETCHVOX_CACHE", "1").lower() in {"0", "false", "no"}:
        return
    p = _cache_dir() / f"{_cache_key(provider, model, prompt)}.json"
    p.write_text(json.dumps(doc, indent=2, ensure_ascii=False), encoding="utf-8")


def _clean_json_text(raw: str) -> str:
    raw = str(raw).strip()
    raw = re.sub(r"^```(?:json)?\s*", "", raw, flags=re.I)
    raw = re.sub(r"\s*```$", "", raw)
    start, end = raw.find("{"), raw.rfind("}")
    if start >= 0 and end > start:
        raw = raw[start:end + 1]
    return raw


def _validate(doc: dict[str, Any]) -> dict[str, Any]:
    # Semantic object vocabulary is open. Resolve safe model-created domain
    # objects before renderer validation; malformed structures still fail.
    doc = resolve_scene_graph(doc)
    errors = validate_scene_graph(doc)
    if errors:
        raise ValueError("Scene graph validation failed: " + "; ".join(errors))
    return doc


def _ollama_url() -> str:
    return os.getenv("SKETCHVOX_OLLAMA_URL", "http://localhost:11434").rstrip("/")


def generate_ollama(prompt: str, model: str, schema: dict[str, Any], system: str,
                    timeout: int = 600, validate_scene: bool = True, stage: str = "ollama",
                    keep_alive: str | int | None = None) -> dict[str, Any]:
    """Call Ollama's local /api/chat endpoint using JSON-schema constrained output."""
    payload = {
        "model": model,
        "messages": [
            {"role": "system", "content": system},
            {"role": "user", "content": prompt},
        ],
        "stream": False,
        "format": schema,
        "options": {"temperature": 0.25},
        "think": False,
        "keep_alive": keep_alive if keep_alive is not None else os.getenv("SKETCHVOX_OLLAMA_KEEP_ALIVE", "10m"),
    }
    req = urllib.request.Request(
        _ollama_url() + "/api/chat",
        data=json.dumps(payload).encode("utf-8"),
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            body = json.loads(resp.read().decode("utf-8"))
    except urllib.error.URLError as exc:
        raise RuntimeError(
            "Ollama is not reachable at " + _ollama_url() + ". Start Ollama and run `ollama pull " + model + "`. " + str(exc)
        ) from exc
    except (TimeoutError, OSError) as exc:
        raise RuntimeError(f"Ollama {stage} request timed out or was interrupted after {timeout}s.") from exc

    content = ((body.get("message") or {}).get("content") or "").strip()
    if not content:
        raise RuntimeError("Ollama returned no message content.")
    try:
        parsed=json.loads(_clean_json_text(content))
        return _validate(parsed) if validate_scene else parsed
    except json.JSONDecodeError as exc:
        raise RuntimeError("Ollama returned non-JSON output: " + content[:1000]) from exc


def generate_gemini(prompt: str, model: str, schema: dict[str, Any], system: str,
                    api_key: str | None = None, max_retries: int = 2, validate_scene: bool = True) -> dict[str, Any]:
    import time
    from google import genai

    key = api_key or os.getenv("GEMINI_API_KEY") or os.getenv("GOOGLE_API_KEY")
    if not key:
        raise RuntimeError("GEMINI_API_KEY is not set.")
    client = genai.Client(api_key=key)
    full = f"{system}\n\n{prompt}"
    last: Exception | None = None
    for attempt in range(max_retries + 1):
        try:
            interaction = client.interactions.create(
                model=model,
                input=full,
                response_format={"type": "text", "mime_type": "application/json", "schema": schema},
            )
            raw = getattr(interaction, "output_text", None)
            if not raw:
                outputs = getattr(interaction, "outputs", []) or []
                text_output = next((o for o in outputs if getattr(o, "type", None) == "text"), None)
                raw = getattr(text_output, "text", None)
            if not raw:
                raise RuntimeError("Gemini returned no text output.")
            parsed=json.loads(_clean_json_text(raw))
            return _validate(parsed) if validate_scene else parsed
        except Exception as exc:
            last = exc
            if attempt >= max_retries:
                break
            time.sleep(1.5 * (attempt + 1))
    raise RuntimeError(str(last or "Gemini request failed"))

"""Scene Graph 2.0 helpers for SketchVox.

The scene graph is the stable contract between a teaching director and any
renderer (Pillow today, browser/SVG later). It deliberately contains semantic
fields rather than renderer-specific instructions.
"""
from __future__ import annotations
from copy import deepcopy
from .content_guard import normalize_project_content
from .asset_resolver import resolve_scene_graph
from dataclasses import dataclass
from typing import Any
import hashlib, json

DEFAULTS = {
    "enter": "draw", "exit": "hold", "z": 0, "start": 0.0,
    "duration": None, "opacity": 1.0, "emphasis": False,
}

@dataclass(frozen=True)
class BBox:
    x: float; y: float; w: float; h: float
    @property
    def x2(self): return self.x+self.w
    @property
    def y2(self): return self.y+self.h
    def intersects(self, other: "BBox", padding: float=0) -> bool:
        return not (self.x2+padding <= other.x or other.x2+padding <= self.x or
                    self.y2+padding <= other.y or other.y2+padding <= self.y)

def stable_id(scene_index:int, object_index:int, obj:dict[str,Any]) -> str:
    raw=json.dumps({k:v for k,v in obj.items() if k not in {"id"}}, sort_keys=True, ensure_ascii=False)
    digest=hashlib.sha1(raw.encode()).hexdigest()[:8]
    return f"s{scene_index:02d}o{object_index:02d}-{digest}"

def _stage_zero_start_objects(scene: dict[str,Any]) -> None:
    """Prevent LLMs from making every object appear at once.

    Explicit timing is respected. If the model leaves every object at t=0,
    SketchVox turns that into a readable drawing sequence unless the scene
    explicitly opts into simultaneous composition.
    """
    objs=scene.get("objects", [])
    if len(objs) <= 1 or scene.get("simultaneous") or scene.get("board_mode") == "simultaneous":
        return
    if any(abs(float(o.get("start",0))) > 1e-6 for o in objs):
        return
    dur=max(1.0,float(scene.get("duration",5)))
    usable=max(0.8,dur-0.45)
    gap=min(0.72,max(0.22,usable/(len(objs)*1.35)))
    for i,obj in enumerate(objs):
        start=0.15+i*gap
        if start >= dur-0.35:
            start=max(0.05,dur-0.75)
        obj["start"]=round(start,2)
        remaining=max(0.35,dur-start-0.18)
        requested=obj.get("duration")
        if requested is None or float(requested) <= 0:
            requested=min(1.5,remaining)
        obj["duration"]=round(min(float(requested),remaining),2)


def _fit_text_objects(scene: dict[str,Any], width: int = 1280, height: int = 720) -> None:
    """Shrink overlong model text before it reaches the renderer.

    Handwritten text is intentionally drawn as one coherent line. A model can
    still produce a long title, so the compiler reduces font size rather than
    letting the tail overwrite or leave the canvas.
    """
    for obj in scene.get("objects",[]):
        if obj.get("type") not in {"text","equation","number"}: continue
        text=str(obj.get("text",obj.get("value","")))
        if not text: continue
        x=float(obj.get("x",0)); y=float(obj.get("y",0)); size=float(obj.get("size",46)); scale=max(0.25,float(obj.get("scale",1)))
        max_right=width-70; max_bottom=height-55
        # Conservative width estimate matching the renderer's handwriting metrics.
        avail=max(80.0,max_right-x)
        est=max(20.0,len(text)*size*0.52*scale)
        if est>avail:
            size=max(22.0, size*(avail/est)*0.94)
            obj["size"]=round(size,1)
        line_h=size*1.25*scale
        if y+line_h>max_bottom:
            obj["y"]=max(55.0,max_bottom-line_h)


def _remove_duplicate_amount_text(scene: dict[str,Any]) -> None:
    """Remove a separate amount text when a money object already owns that label."""
    money=[]
    for o in scene.get("objects",[]):
        if o.get("type")=="money" and o.get("label"):
            money.append(str(o.get("label")).strip())
    if not money: return
    kept=[]
    for o in scene.get("objects",[]):
        if o.get("type") in {"text","number","equation"} and str(o.get("text",o.get("value",""))).strip() in money:
            # Preserve the explicitly authored text if it has a materially
            # different position; otherwise the money object's built-in label
            # is the single source of truth.
            ox,oy=float(o.get("x",0)),float(o.get("y",0))
            duplicate=False
            for m in scene.get("objects",[]):
                if m is o or m.get("type")!="money" or not m.get("label"): continue
                mx,my=float(m.get("x",0)),float(m.get("y",0))
                if abs(ox-mx)<240 and abs(oy-my)<150:
                    duplicate=True; break
            if duplicate: continue
        kept.append(o)
    scene["objects"]=kept


def normalize_project(doc:dict[str,Any]) -> dict[str,Any]:
    out=deepcopy(doc)
    currency=str(out.get("meta",{}).get("currency", "INR")).upper()
    if currency not in {"INR","USD","EUR","GBP"}: currency="INR"
    out=normalize_project_content(out,currency)
    out=resolve_scene_graph(out)
    for si,scene in enumerate(out.get("scenes",[]),1):
        scene.setdefault("id", f"scene-{si:02d}")
        scene.setdefault("transition", "none" if si==1 else "wipe")
        is_summary=any(o.get("type")=="summary_board" for o in scene.get("objects",[])) or str(scene.get("purpose","")).lower() in {"summary","recap"}
        scene.setdefault("clear_board", bool(is_summary or si>1))
        scene.setdefault("camera", {})
        for oi,obj in enumerate(scene.get("objects",[]),1):
            obj.update({k:v for k,v in DEFAULTS.items() if k not in obj})
            # LLMs sometimes confuse the visual `color` property with the
            # numeric `stroke` width. Normalize that before any renderer or
            # layout code attempts numeric conversion.
            raw_stroke = obj.get("stroke")
            if isinstance(raw_stroke, str):
                sv = raw_stroke.strip()
                if sv.startswith("#"):
                    obj.setdefault("color", sv)
                    obj["stroke"] = 4.0
                else:
                    try:
                        obj["stroke"] = max(0.5, float(sv.replace("px", "").strip()))
                    except ValueError:
                        obj["stroke"] = 4.0
            elif not isinstance(raw_stroke, (int, float)) or isinstance(raw_stroke, bool):
                obj["stroke"] = 4.0
            obj.setdefault("id", stable_id(si,oi,obj))
            if obj.get("duration") is None:
                dur=float(scene.get("duration",5))
                obj["duration"]=max(0.35, dur-float(obj.get("start",0))-0.25)
            obj.setdefault("anchor", "top_left")
            obj.setdefault("parent", None)
        _remove_duplicate_amount_text(scene)
        _fit_text_objects(scene)
        _stage_zero_start_objects(scene)
        # Constraint layout is a mandatory compiler invariant, not an opt-in
        # visual polish step. It runs after normalization so IDs/timing/types
        # are stable and before final QA measures the scene.
        from .layout import auto_layout_scene
        out["scenes"][si-1] = auto_layout_scene(scene)
    out.setdefault("meta", {})["layout_contract"] = {
        "version": "constraint-v1",
        "safe_margin": [72,58,72,62],
        "geometry_source": "renderer-matched-font-metrics",
        "invariant": "every drawable object fits the safe canvas before render",
    }
    return out

def object_bbox(obj:dict[str,Any]) -> BBox|None:
    t=obj.get("type"); x=float(obj.get("x",0)); y=float(obj.get("y",0)); s=float(obj.get("scale",1))
    if t in {"text","equation","number"}:
        # Canonical renderer-matched text geometry.  The old character-count
        # estimate was the source of false/late canvas failures for long copy.
        text=str(obj.get("text",obj.get("value","")) or "")
        size=float(obj.get("size",46))*s
        try:
            from PIL import Image, ImageDraw
            from .assets import font
            f=font(max(1,int(size)), bool(obj.get("bold",t=="equation")))
            draw=ImageDraw.Draw(Image.new("RGB",(4,4)))
            max_width=float(obj.get("max_width",900))*s
            words=text.split()
            lines=[]; cur=""
            for word in words:
                trial=(cur+" "+word).strip()
                if not cur or draw.textbbox((0,0),trial,font=f)[2] <= max_width:
                    cur=trial
                else:
                    lines.append(cur); cur=word
            if cur: lines.append(cur)
            if not lines: lines=[""]
            widths=[draw.textbbox((0,0),line,font=f)[2] for line in lines]
            line_h=float(obj.get("line_height",1.2))*size
            return BBox(x,y,max(20.0,max(widths)),max(size*1.15,line_h*len(lines)))
        except Exception:
            return BBox(x,y,max(20,len(text)*size*.52),size*1.25)
    if t=="person": return BBox(x-35*s,y-35*s,100*s,205*s)
    if t=="money": return BBox(x,y,180*s,105*s)
    if t in {"circle","ellipse"}:
        return BBox(x-float(obj.get("rx",obj.get("r",50)))*s,y-float(obj.get("ry",obj.get("r",50)))*s,2*float(obj.get("rx",obj.get("r",50)))*s,2*float(obj.get("ry",obj.get("r",50)))*s)
    if t in {"arrow","line"}:
        x2=float(obj.get("x2",x+200)); y2=float(obj.get("y2",y))
        return BBox(min(x,x2)-15,min(y,y2)-15,abs(x2-x)+30,abs(y2-y)+30)
    if t in {"rect","round_rect"}:
        x2=float(obj.get("x2",x+100)); y2=float(obj.get("y2",y+60));
        return BBox(min(x,x2),min(y,y2),abs(x2-x),abs(y2-y))
    if t in {"chart","line_chart","bar_chart","pie_chart"}:
        return BBox(x,y,float(obj.get("width",700))*s,float(obj.get("height",350))*s+55*s)
    if t == "pipeline":
        items=obj.get("items") or []
        bw=float(obj.get("box_width",180))*s
        bh=float(obj.get("box_height",80))*s
        gap=20*s
        return BBox(x,y,max(bw,len(items)*bw+max(0,len(items)-1)*gap),bh)
    if t == "timeline":
        x2=float(obj.get("x2",x+600))*s
        return BBox(min(x,x2),y,max(1,abs(x2-x)),110*s)
    if t == "table":
        rows=obj.get("rows") or []
        cols=max([len(r) for r in rows],default=1)
        return BBox(x,y,cols*float(obj.get("cell_width",150))*s,len(rows)*float(obj.get("cell_height",50))*s)
    if t == "summary_board":
        return BBox(x,y,float(obj.get("width",1280)),float(obj.get("height",720)))
    if t == "token_strip":
        tokens=obj.get("tokens") or []
        width=sum(max(54,24+len(str(tok))*13)*s for tok in tokens)+max(0,len(tokens)-1)*12*s
        return BBox(x,y,width,62*s)
    if t == "ratio":
        return BBox(x,y,float(obj.get("width",330))*s,220*s)
    if t == "speech_bubble":
        return BBox(x,y,float(obj.get("width",420))*s,float(obj.get("height",170))*s+30*s)
    if t == "flow_node":
        x2=float(obj.get("x2",x+180)); y2=float(obj.get("y2",y+90))
        return BBox(min(x,x2),min(y,y2),abs(x2-x),abs(y2-y2) if False else abs(y2-y))
    if t in {"starburst","highlight_ring"}:
        r=float(obj.get("r",54))*s; return BBox(x-r,y-r,2*r,2*r)
    if t in {"icon","doodle_icon"}:
        # Conservative envelope covering the bundled doodle glyph family.
        return BBox(x-95*s,y-105*s,190*s,220*s)
    return BBox(x-55*s,y-35*s,110*s,70*s)

def validate_v2(doc:dict[str,Any], width:int=1280, height:int=720) -> list[str]:
    errors=[]
    ids=set()
    for si,scene in enumerate(doc.get("scenes",[]),1):
        sd=float(scene.get("duration",0))
        if sd<=0: errors.append(f"scene {si}: duration must be > 0")
        for oi,obj in enumerate(scene.get("objects",[]),1):
            oid=obj.get("id")
            if not oid: errors.append(f"scene {si}, object {oi}: missing id")
            elif oid in ids: errors.append(f"duplicate object id: {oid}")
            else: ids.add(oid)
            st=float(obj.get("start",0)); od=float(obj.get("duration",0))
            if st<0: errors.append(f"scene {si}, object {oi}: start < 0")
            if od<=0: errors.append(f"scene {si}, object {oi}: duration <= 0")
            if st+od>sd+0.05: errors.append(f"scene {si}, object {oi}: animation exceeds scene duration")
            if obj.get("type") not in {"group","space","summary_board"}:
                b=object_bbox(obj)
                if b and (b.x < -30 or b.y < -30 or b.x2 > width+30 or b.y2 > height+30):
                    errors.append(f"scene {si}, object {oi}: outside safe canvas bounds")
    return errors

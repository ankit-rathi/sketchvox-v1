"""Visual-first presentation compiler.

Narration is the explanatory channel. The board is a visual memory aid:
short labels, semantic icons, relationships and a small number of words.
This module is deterministic and runs after the teaching contract is locked.
It never edits narration or AnswerIR facts.
"""
from __future__ import annotations

from copy import deepcopy
import re
from typing import Any

from PIL import Image, ImageDraw

# Common semantic relationships -> compact display phrase.
_RELATIONS = [
    (r"\b(absorb|absorbs|capture|captures|takes in)\b", "captures"),
    (r"\b(split|splits|break|breaks)\b", "splits"),
    (r"\b(convert|converts|turn|turns|transform|transforms)\b", "converts"),
    (r"\b(produce|produces|produced|make|makes|made|generate|generates)\b", "produces"),
    (r"\b(release|releases|emit|emits)\b", "releases"),
    (r"\b(use|uses|require|requires)\b", "uses"),
    (r"\b(retrieve|retrieves|find|finds)\b", "retrieves"),
    (r"\b(generate|generates|predict|predicts)\b", "generates"),
    (r"\b(compare|compares|contrast|contrasts)\b", "compares"),
    (r"\b(increase|increases|grow|grows|rise|rises)\b", "increases"),
    (r"\b(decrease|decreases|reduce|reduces|fall|falls)\b", "reduces"),
    (r"\b(average|averages|smooth|smooths)\b", "smooths"),
]

# Semantic concept/explanation vocabulary -> concrete doodle primitives.
_HINTS: list[tuple[tuple[str, ...], tuple[str, ...]]] = [
    (("sunlight", "sun", "light"), ("sun",)),
    (("water", "h2o"), ("water",)),
    (("oxygen", "o2"), ("oxygen",)),
    (("carbon dioxide", "co2"), ("carbon_dioxide",)),
    (("glucose", "sugar"), ("glucose",)),
    (("chlorophyll", "chloroplast", "plant", "leaf", "photosynthesis"), ("leaf", "sun")),
    (("cell", "membrane", "nucleus"), ("cell",)),
    (("database", "data store", "storage"), ("database",)),
    (("document", "documents", "text chunk"), ("document",)),
    (("retrieve", "retrieval", "search", "query"), ("magnifier", "database")),
    (("generate", "generation", "llm", "language model", "chatgpt"), ("robot", "brain")),
    (("attention", "transformer"), ("attention", "neuron")),
    (("embedding", "vector"), ("stack", "database")),
    (("api", "endpoint"), ("api", "server")),
    (("model", "machine learning", "prediction", "classifier"), ("brain", "chart")),
    (("stock", "price", "return", "portfolio", "invest", "capital"), ("coin", "trend")),
    (("bank", "loan", "interest", "cash"), ("bank", "coin")),
    (("average", "moving average", "trend", "time series"), ("chart", "trend")),
    (("equation", "formula", "calculate", "calculation", "probability"), ("calculator", "chart")),
    (("algorithm", "step", "process", "pipeline"), ("flow_node", "arrow")),
]


def _text(value: Any) -> str:
    return str(value or "").strip()


def _compact_name(name: str, max_words: int = 6, max_chars: int = 38) -> str:
    s=re.sub(r"\s+", " ", _text(name)).strip(" .:;,-")
    words=s.split()
    if len(words)>max_words:
        s=" ".join(words[:max_words])
    return s[:max_chars].rstrip(" .:;,-")


def _phrase(explanation: str, name: str) -> str:
    """Create a board phrase, never a compressed narration sentence.

    The screen is a visual memory aid. Prefer 2–4 high-signal words and
    domain symbols; narration carries the complete explanation.
    """
    s=_text(explanation)
    low=s.lower()
    if "split water" in low and "oxygen" in low:
        return "SPLITS WATER"
    if "released" in low and "oxygen" in low:
        return "RELEASES O2"
    if "released" in low and "atmosphere" in low:
        return "RELEASES TO AIR"
    if "stored chemical energy" in low or "stores chemical energy" in low:
        return "STORES ENERGY"
    if "raw materials" in low:
        return "MAIN RAW MATERIALS"
    if "convert carbon dioxide into sugars" in low or ("carbon dioxide" in low and "glucose" in low):
        return "BUILDS SUGAR"
    if "absorbs sunlight" in low or "absorb sunlight" in low or "captures sunlight" in low:
        return "CAPTURES SUNLIGHT"
    for pat, verb in _RELATIONS:
        m=re.search(pat, low)
        if m:
            tail=s[m.end():].strip(" ,.;:-")
            words=re.findall(r"[A-Za-z0-9₂₃₄₅₆₇₈₉%₹$€£+-]+", tail)
            stop={"the","a","an","is","are","of","in","to","and","that","this","it","for","with","which","from","as","by","on","into","its","their","they","can","also","during"}
            keep=[w for w in words if w.lower() not in stop]
            if keep:
                return f"{verb.upper()} {' '.join(keep[:2]).upper()}"[:34]
    words=re.findall(r"[A-Za-z0-9₂₃₄₅₆₇₈₉%₹$€£+-]+", s)
    stop={"the","a","an","is","are","of","in","to","and","that","this","it","for","with","which","from","as","by","on","into","its","their","they","can","also","during"}
    keep=[w for w in words if w.lower() not in stop]
    return " ".join(keep[:4]).upper()[:34] or _compact_name(name,4,34).upper()


def _icons_for(name: str, explanation: str, max_icons: int = 3) -> list[str]:
    hay=(name+" "+explanation).lower()
    # Directional teaching relationships get an explicit input -> process ->
    # output order. This avoids accidentally drawing a scientifically reversed
    # arrow simply because keyword matching found the right icons.
    if "released" in hay and "oxygen" in hay:
        return ["leaf", "oxygen", "cloud"][:max_icons]
    if "split water" in hay:
        return ["sun", "water", "oxygen"][:max_icons]
    if "convert carbon dioxide into sugars" in hay or "calvin cycle" in hay:
        return ["carbon_dioxide", "energy", "glucose"][:max_icons]
    if "glucose" in hay and "chemical energy" in hay:
        return ["leaf", "glucose", "energy"][:max_icons]
    found=[]
    for keys, icons in _HINTS:
        if any(k in hay for k in keys):
            for icon in icons:
                if icon not in found and len(found)<max_icons:
                    found.append(icon)
    if not found:
        # Domain-neutral visual anchors for unfamiliar concepts.
        if any(k in hay for k in ("result","effect","output","outcome")): found=["check","trend"]
        elif any(k in hay for k in ("definition","means","refers")): found=["book","lightbulb"]
        else: found=["spark","brain"]
    return found[:max_icons]


def _icon(x: float, y: float, semantic: str, scale: float=.82, role: str="teaching_evidence") -> dict[str,Any]:
    # Compact inner glyph labels prevent a second full word from competing with
    # the centered caption underneath the icon.
    labels={"carbon_dioxide":"CO2","oxygen":"O2","glucose":"SUGAR","energy":"ENERGY"}
    out={"type":"icon","icon":semantic,"semantic_type":semantic,"x":x,"y":y,"scale":scale,
         "semantic_role":role,"asset_resolution":"deterministic_vector","teaching_job":"visual_anchor",
         "start":0.25,"duration":0.72}
    if semantic in labels: out["label"]=labels[semantic]
    return out


def _label_width(text: str, size: int, bold: bool=False) -> float:
    try:
        from .assets import font
        f=font(int(size), bold)
        d=ImageDraw.Draw(Image.new("RGB",(4,4)))
        return float(d.textbbox((0,0),str(text),font=f)[2])
    except Exception:
        return max(24.0, len(str(text))*float(size)*0.52)


def _center_label(cx: float, y: float, text: str, size: int=22, bold: bool=True, role: str="annotation", max_width: float=220) -> dict[str,Any]:
    w=min(max_width, max(40.0,_label_width(text,size,bold)))
    return {"type":"text","x":round(cx-w/2,2),"y":y,"text":text,"size":size,"bold":bold,
            "font_role":"display","semantic_role":role,"line_role":"label","max_width":max_width,
            "start":0.82,"duration":0.58,"text_align":"center"}


def _label(x: float, y: float, text: str, size: int=28, bold: bool=True, role: str="annotation") -> dict[str,Any]:
    font_role="handwriting" if role=="headline" else "display"
    return {"type":"text","x":x,"y":y,"text":text,"size":size,"bold":bold,"font_role":font_role,
            "semantic_role":role,"line_role":"label","max_width":300,"start":0.35,"duration":0.72}


def _arrow(x: float,y: float,x2: float,y2: float, start: float=0.70, duration: float=0.55) -> dict[str,Any]:
    return {"type":"arrow","x":x,"y":y,"x2":x2,"y2":y2,"size":4,"semantic_role":"relationship",
            "relationship":"semantic_flow","start":start,"duration":duration}


def _concept_for_scene(scene: dict[str,Any], answer_ir: dict[str,Any]) -> dict[str,Any] | None:
    ids=set(str(x) for x in scene.get("teaches",[]) or [])
    for c in answer_ir.get("concepts",[]) or []:
        if str(c.get("id")) in ids: return c
    return None


def _node_caption(ic: str) -> str:
    return {
        "carbon_dioxide":"CARBON DIOXIDE","oxygen":"OXYGEN","glucose":"GLUCOSE",
        "sun":"SUNLIGHT","water":"WATER","leaf":"PLANT / LEAF","cloud":"AIR",
        "energy":"ENERGY"
    }.get(ic, ic.replace("_"," ").upper())


def _rebuild_concept_scene(scene: dict[str,Any], concept: dict[str,Any]) -> dict[str,Any]:
    name=_compact_name(concept.get("name", "Concept"),6,42)
    explanation=_text(concept.get("explanation"))
    phrase=_phrase(explanation,name)
    icons=_icons_for(name,explanation,3)
    objs=[_label(92,86,name,40,True,"headline")]

    # Some relationships are additive/converging rather than sequential. Do
    # not draw a misleading A -> B -> C chain when B is an input or resource.
    if icons == ["sun","water","oxygen"] or icons == ["carbon_dioxide","energy","glucose"] or icons == ["leaf","glucose","energy"]:
        if icons == ["leaf","glucose","energy"]:
            # The concept is production of glucose; energy is an explanation
            # of what glucose stores, not a second material flowing into it.
            objs.append(_icon(350,330,"leaf",.9,"semantic_icon"))
            objs.append(_center_label(350,440,"PLANT / LEAF",20,True,"annotation",210))
            objs.append(_arrow(455,330,805,330))
            objs.append(_icon(900,330,"glucose",.82,"semantic_icon"))
            objs.append(_center_label(900,440,"GLUCOSE",21,True,"annotation",210))
            objs.append(_label(92,535,phrase,31,True,"emphasis"))
            scene["objects"]=objs
            scene["visual_archetype"]="visual_flow"
            scene["design_intent"]="Show plant to glucose production directly; narration explains the energy role."
            scene["presentation_mode"]="visual_first"
            return scene
        else:
            left=[(icons[0],_node_caption(icons[0]),235),(icons[1],_node_caption(icons[1]),420)]
            out_ic=icons[2]; out_label=_node_caption(out_ic)
        # Two inputs are arranged as a balanced pair; both arrows converge on
        # the output so the viewer reads them as co-factors/materials, not a
        # sequential transformation.
        if len(left)==2:
            # Stagger the two inputs vertically so neither connector crosses
            # the other input icon. Both paths converge cleanly on the result.
            pair=[(260,260),(260,400)]
            for (ic,lab,_),(x,y) in zip(left,pair):
                objs.append(_icon(x,y,ic,.72,"semantic_icon"))
                objs.append(_center_label(x,y+78,lab,19,True,"annotation",210))
                objs.append(_arrow(x+82,y,785,330 + (-10 if y < 330 else 10)))
        objs.append(_icon(930,330,out_ic,.82,"semantic_icon"))
        objs.append(_center_label(930,442,out_label,21,True,"annotation",230))
        objs.append(_label(92,535,phrase,31,True,"emphasis"))
    else:
        xs=[220,640,1060][:len(icons)]
        for i,ic in enumerate(icons):
            objs.append(_icon(xs[i],325,ic,.86 if i==1 else .78,"semantic_icon"))
            objs.append(_center_label(xs[i],442,_node_caption(ic),21,True,"annotation",220))
            if i < len(icons)-1:
                gap_left=xs[i]+92; gap_right=xs[i+1]-92
                objs.append(_arrow(gap_left,325,gap_right,325))
        objs.append(_label(92,535,phrase,31,True,"emphasis"))

    scene["objects"]=objs
    scene["visual_archetype"]="converging_flow" if len(icons)>=3 and (icons == ["sun","water","oxygen"] or icons == ["carbon_dioxide","energy","glucose"] or icons == ["leaf","glucose","energy"]) else "visual_flow"
    scene["design_intent"]="Show the semantic relationship explicitly with aligned doodles and directional connectors; narration carries the explanation."
    scene["presentation_mode"]="visual_first"
    return scene


def _looks_text_heavy(scene: dict[str,Any]) -> bool:
    texts=[o for o in scene.get("objects",[]) if o.get("type") in {"text","equation","number"}]
    long=[o for o in texts if len(_text(o.get("text",o.get("value",""))))>58]
    visuals=[o for o in scene.get("objects",[]) if o.get("type") not in {"text","equation","number","arrow","line","space","highlight"}]
    return bool(long) or (len(texts)>=3 and len(visuals)<2)


def _rebuild_example_scene(scene: dict[str,Any], example: str, topic: str) -> None:
    hay=(example+" "+topic).lower()
    objs=[_label(92,86,"A CONCRETE EXAMPLE",38,True,"headline")]
    if "sun" in hay and "water" in hay and ("photosynthesis" in hay or "leaf" in hay or "plant" in hay):
        # Grouped causal layout: inputs converge on the plant; outputs leave it.
        inputs=[(190,235,"sun","SUNLIGHT"),(190,355,"water","WATER"),(190,475,"carbon_dioxide","AIR")]
        for x,y,ic,label in inputs:
            objs.append(_icon(x,y,ic,.52,"semantic_icon"))
            objs.append(_center_label(x,y+72,label,18,True,"annotation",190))
            objs.append(_arrow(x+78,y,555,345))
        objs.append(_icon(650,345,"leaf",.95,"semantic_icon"))
        objs.append(_center_label(650,455,"PLANT",20,True,"annotation",180))
        outputs=[(1030,305,"glucose","GLUCOSE"),(1030,415,"oxygen","OXYGEN")]
        for x,y,ic,label in outputs:
            objs.append(_icon(x,y,ic,.52,"semantic_icon"))
            objs.append(_center_label(x,y+72,label,18,True,"annotation",180))
            objs.append(_arrow(745,345,x-78,y))
        
    else:
        icons=_icons_for(topic,example,4)[:4]
        objs.append(_label(92,185,"IDEA IN ACTION",20,True,"section_label"))
        xs=[190,480,770,1060]
        for i,ic in enumerate(icons):
            objs.append(_icon(xs[i],325,ic,.72,"semantic_icon"))
            objs.append(_center_label(xs[i],430,_node_caption(ic),19,True,"annotation",210))
            if i<len(icons)-1:
                objs.append(_arrow(xs[i]+82,325,xs[i+1]-82,325))
        objs.append(_label(92,535,"SEE THE IDEA IN ACTION",28,True,"emphasis"))
    scene["objects"]=objs
    scene["presentation_mode"]="visual_first"
    scene["visual_archetype"]="example_flow"
    scene["design_intent"]="Make the narrated example concrete with grouped inputs, process and outputs."


def _rebuild_distinction_scene(scene: dict[str,Any], distinctions: list[str], topic: str) -> None:
    other=_compact_name(distinctions[0] if distinctions else "a different process",5,32)
    objs=[_label(92,86,"DON'T CONFUSE",40,True,"headline")]
    objs += [
        _icon(320,315,"leaf",.9,"semantic_icon"),
        _center_label(320,435,_display_topic_name(topic).upper(),21,True,"annotation",300),
        _arrow(430,315,530,315),
        {"type":"cross","x":640,"y":315,"scale":.65,"semantic_role":"attention_cue","start":0.58,"duration":0.65},
        _arrow(750,315,850,315),
        _icon(940,315,"energy",.82,"semantic_icon"),
        _center_label(940,435,other.upper(),21,True,"annotation",300),
        _label(92,535,"DIFFERENT JOBS",29,True,"emphasis")
    ]
    scene["objects"]=objs
    scene["presentation_mode"]="visual_first"
    scene["visual_archetype"]="contrast"
    scene["design_intent"]="Use explicit separation and comparison cues rather than a paragraph of caveats."


def _rebuild_mental_scene(scene: dict[str,Any], mental: str, topic: str) -> None:
    hay=(mental+" "+topic).lower()
    objs=[_label(92,86,"THE MENTAL MODEL",38,True,"headline")]
    if "sunlight" in hay and "water" in hay:
        inputs=[(190,235,"sun","SUNLIGHT"),(190,355,"water","WATER"),(190,475,"carbon_dioxide","AIR")]
        for x,y,ic,label in inputs:
            objs.append(_icon(x,y,ic,.52,"semantic_icon"))
            objs.append(_center_label(x,y+72,label,18,True,"annotation",190))
            objs.append(_arrow(x+78,y,555,345))
        objs.append(_icon(650,345,"leaf",.98,"semantic_icon"))
        objs.append(_center_label(650,455,"PLANT",20,True,"annotation",180))
        outputs=[(1030,305,"glucose","GLUCOSE"),(1030,415,"oxygen","OXYGEN")]
        for x,y,ic,label in outputs:
            objs.append(_icon(x,y,ic,.52,"semantic_icon"))
            objs.append(_center_label(x,y+72,label,18,True,"annotation",180))
            objs.append(_arrow(745,345,x-78,y))
        
    else:
        icons=_icons_for(topic,mental,4); xs=[180,450,720,1010]
        for i,ic in enumerate(icons):
            objs.append(_icon(xs[i],320,ic,.68,"semantic_icon"))
            objs.append(_center_label(xs[i],420,_node_caption(ic),19,True,"annotation",210))
            if i<len(icons)-1: objs.append(_arrow(xs[i]+78,320,xs[i+1]-78,320))
    scene["objects"]=objs
    scene["presentation_mode"]="visual_first"
    scene["visual_archetype"]="mental_model_flow"
    scene["design_intent"]="Make the final mental model readable as a causal diagram, not a sentence."


def _display_topic_name(topic: str) -> str:
    s=_text(topic)
    s=re.sub(r"^\s*(explain|what is|what are|how does|how do|define)\s+", "", s, flags=re.I)
    s=re.sub(r"\s+to\s+(a|an)\s+class[- ]?\d+.*$", "", s, flags=re.I)
    return re.sub(r"[?!.]+$", "", s).strip()[:30] or "THE TOPIC"


def enforce_visual_first(project: dict[str,Any], topic: str="") -> dict[str,Any]:
    """Make the presentation channel concise and visual without touching narration."""
    out=deepcopy(project)
    ir=out.get("meta",{}).get("answer_ir") or {}
    concepts=ir.get("concepts",[]) or []
    meta=out.setdefault("meta",{})
    meta["presentation_contract"]={
        "version":"1.0",
        "principle":"narration_explains_visuals_demonstrate",
        "display_copy":"phrases_labels_not_commentary",
        "max_body_chars":58,
        "visual_minimum":"one_focal_visual_plus_relationship_or_supporting_visual",
    }
    for scene in out.get("scenes",[]) or []:
        if any(o.get("type")=="summary_board" for o in scene.get("objects",[])):
            continue
        purpose=str(scene.get("purpose","")).lower()
        if purpose=="example" and ir.get("useful_example"):
            _rebuild_example_scene(scene,_text(ir.get("useful_example")),topic)
            continue
        if purpose in {"takeaway","mental-model","mental_model"} and ir.get("final_mental_model"):
            _rebuild_mental_scene(scene,_text(ir.get("final_mental_model")),topic)
            continue
        if purpose in {"comparison","distinction","misconception"} and ir.get("must_not_confuse_with"):
            _rebuild_distinction_scene(scene,list(ir.get("must_not_confuse_with") or []),topic)
            continue
        c=_concept_for_scene(scene,ir)
        if c and (_looks_text_heavy(scene) or str(scene.get("presentation_mode"))=="visual_first" or meta.get("fallback")=="semantic_compiler"):
            _rebuild_concept_scene(scene,c)
            continue
        # Even when preserving a richer authored diagram, eliminate commentary
        # from the board. Long explanatory text belongs in narration.
        for obj in scene.get("objects",[]) or []:
            if obj.get("type") not in {"text","equation"}: continue
            txt=_text(obj.get("text"))
            if len(txt)<=58: continue
            if c:
                obj["text"]=_phrase(c.get("explanation",txt),c.get("name",""))
                obj["size"]=max(28,float(obj.get("size",30)))
                obj["max_width"]=min(520,float(obj.get("max_width",520)))
                obj["semantic_role"]="emphasis"
            else:
                obj["text"]=" ".join(txt.split()[:6]).rstrip(".,")
                obj["size"]=max(28,float(obj.get("size",30)))
        scene.setdefault("presentation_mode","visual_first")
    return out

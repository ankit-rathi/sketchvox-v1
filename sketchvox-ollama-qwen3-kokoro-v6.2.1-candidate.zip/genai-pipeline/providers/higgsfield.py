from __future__ import annotations
import os, requests

class HiggsfieldAPI:
    """Thin HTTP adapter for optional AI-image/video generation. Endpoints can change; keep them configurable."""
    def __init__(self,api_key=None,base_url=None):
        self.api_key=api_key or os.getenv('HIGGSFIELD_API_KEY'); self.base_url=(base_url or os.getenv('HIGGSFIELD_API_BASE','https://platform.higgsfield.ai')).rstrip('/')
    def _headers(self): return {'Authorization':f'Bearer {self.api_key}','Content-Type':'application/json'}
    def create(self,path,payload):
        if not self.api_key: raise RuntimeError('Set HIGGSFIELD_API_KEY')
        r=requests.post(self.base_url+path,headers=self._headers(),json=payload,timeout=120); r.raise_for_status(); return r.json()

"""High-quality deterministic doodle renderer with progressive drawing and optional hand cursor."""
from __future__ import annotations
import math, os, subprocess, tempfile
from pathlib import Path
from PIL import Image, ImageDraw
from .assets import font, draw_icon
from .schema import ProjectConfig

def wrap_text(text, font_obj, max_width, draw):
    words=str(text).split(); lines=[]; cur=[]
    for word in words:
        trial=' '.join(cur+[word])
        if draw.textbbox((0,0),trial,font=font_obj)[2] <= max_width or not cur:
            cur.append(word)
        else:
            lines.append(' '.join(cur)); cur=[word]
    if cur: lines.append(' '.join(cur))
    return lines


def hexrgb(v):
    if isinstance(v,(list,tuple)): return tuple(v)
    v=str(v).lstrip('#'); return tuple(int(v[i:i+2],16) for i in (0,2,4))

def xy(v,default=0):
    try: return float(v)
    except: return float(default)

def draw_partial_line(draw,p1,p2,p,ink,width):
    ex=p1[0]+(p2[0]-p1[0])*p; ey=p1[1]+(p2[1]-p1[1])*p; draw.line((p1[0],p1[1],ex,ey),fill=ink,width=width); return ex,ey

def draw_obj(draw,obj,p,theme,canvas_width=1280):
    typ=obj.get('render_type') if obj.get('type') == 'icon' else obj.get('type'); ink=hexrgb(obj.get('color',theme['ink'])); accent=hexrgb(obj.get('accent',theme['accent'])); s=float(obj.get('scale',1)); w=max(2,int(obj.get('stroke',5)*s)); x=xy(obj.get('x')); y=xy(obj.get('y'))
    p=max(0,min(1,p))
    if typ in {'person','money','coin','bank','wallet','house','calculator','question','lightbulb','warning','check','cross','magnifier','book','robot','brain','database','server','cloud','gpu','api','tree','leaf','sun','water','oxygen','carbon_dioxide','glucose','dna','cell','atom','molecule','energy','force','gradient','loss','token','query','attention','neuron','probability','generic'}:
        if p>0: draw_icon(draw,typ,x,y,s,ink,accent,p,obj.get('label'))
        return (x,y)
    if typ=='text' or typ=='equation':
        f=font(int(obj.get('size',48)*s),bool(obj.get('bold',typ=='equation'))); text=str(obj.get('text',''))
        max_width=min(float(obj.get('max_width',900))*s, max(100.0, canvas_width-x-50))
        lines=wrap_text(text,f,max_width,draw); lh=int(obj.get('line_height',1.2)*f.size)
        for li,line in enumerate(lines): draw.text((x,y+li*lh),line,font=f,fill=ink)
        return (x,y+max(0,len(lines)-1)*lh)
    if typ=='number':
        f=font(int(obj.get('size',84)*s),True); draw.text((x,y),str(obj.get('value','0')),font=f,fill=ink); return (x,y)
    if typ=='line':
        return draw_partial_line(draw,(x,y),(xy(obj.get('x2')),xy(obj.get('y2'))),p,ink,w)
    if typ=='arrow':
        ex,ey=draw_partial_line(draw,(x,y),(xy(obj.get('x2')),xy(obj.get('y2'))),p,ink,w)
        if p>=.85:
            ang=math.atan2(ey-y,ex-x); L=20*s; a1=ang+2.55; a2=ang-2.55; draw.polygon([(ex,ey),(ex+L*math.cos(a1),ey+L*math.sin(a1)),(ex+L*math.cos(a2),ey+L*math.sin(a2))],fill=ink)
        return (ex,ey)
    if typ in {'rect','round_rect'}:
        x2,y2=xy(obj.get('x2')),xy(obj.get('y2')); ex=x+(x2-x)*p; ey=y+(y2-y)*p
        if typ=='rect': draw.rectangle((x,y,ex,ey),outline=ink,width=w)
        else: draw.rounded_rectangle((x,y,ex,ey),radius=int(15*s),outline=ink,width=w)
        return (ex,ey)
    if typ in {'circle','ellipse'}:
        rx=float(obj.get('rx',obj.get('r',50)))*s; ry=float(obj.get('ry',obj.get('r',50)))*s
        draw.ellipse((x-rx,y-ry,x+rx,y+ry),outline=ink,width=w); return (x+rx,y)
    if typ in {'chart','bar_chart','pie_chart'}:
        vals=obj.get('values') or [10,25,18,35]; width=float(obj.get('width',430))*s; height=float(obj.get('height',260))*s
        draw.line((x,y+height,x+width,y+height),fill=ink,width=w); draw.line((x,y,x,y+height),fill=ink,width=w)
        if typ=='pie_chart':
            total=sum(float(v) for v in vals) or 1; start=-90
            for v in vals:
                end=start+360*float(v)/total*p; draw.pieslice((x,y,x+height,y+height),start,end,outline=ink,width=w); start=end
        elif typ=='bar_chart':
            mx=max(map(float,vals)) or 1; n=len(vals); bw=width/max(1,n)*.62
            for i,v in enumerate(vals):
                bh=height*float(v)/mx*p; bx=x+i*width/max(1,n)+(width/max(1,n)-bw)/2; draw.rectangle((bx,y+height-bh,bx+bw,y+height),outline=ink,width=w)
        else:
            mx=max(map(float,vals)) or 1; pts=[]; n=len(vals)
            for i,v in enumerate(vals): pts.append((x+i*width/max(1,n-1),y+height-height*float(v)/mx))
            upto=max(1,int(len(pts)*p));
            if upto>1: draw.line(pts[:upto],fill=ink,width=w,joint='curve')
            for px,py in pts[:upto]: draw.ellipse((px-4*s,py-4*s,px+4*s,py+4*s),fill=ink)
        if obj.get('label'): draw.text((x,y+height+15*s),str(obj['label']),font=font(int(26*s)),fill=ink)
        return (x+width,y+height)
    if typ=='timeline':
        x2=xy(obj.get('x2',x+600)); yy=y; ex=draw_partial_line(draw,(x,yy),(x2,yy),p,ink,w)[0]
        for i,item in enumerate(obj.get('items',[])):
            t=i/max(1,len(obj['items'])-1); xx=x+(x2-x)*t
            if xx<=ex+1: draw.ellipse((xx-7*s,yy-7*s,xx+7*s,yy+7*s),fill=ink); draw.text((xx,yy+18*s),str(item),font=font(int(24*s)),fill=ink)
        return (ex,yy)
    if typ=='pipeline':
        items=obj.get('items',[]); gap=20*s; bw=float(obj.get('box_width',180))*s; bh=float(obj.get('box_height',80))*s
        for i,item in enumerate(items):
            bx=x+i*(bw+gap); draw.rounded_rectangle((bx,y,bx+bw,y+bh),radius=int(12*s),outline=ink,width=w); tw=str(item); draw.text((bx+12*s,y+22*s),tw,font=font(int(24*s),True),fill=ink)
            if i<len(items)-1: draw.line((bx+bw,y+bh/2,bx+bw+gap,y+bh/2),fill=ink,width=w)
        return (x+len(items)*(bw+gap),y+bh)
    if typ=='table':
        rows=obj.get('rows',[]); cols=max([len(r) for r in rows],default=1); cw=float(obj.get('cell_width',150))*s; ch=float(obj.get('cell_height',50))*s
        for r,row in enumerate(rows):
            for c,val in enumerate(row):
                bx=x+c*cw; by=y+r*ch; draw.rectangle((bx,by,bx+cw,by+ch),outline=ink,width=w); draw.text((bx+8*s,by+10*s),str(val),font=font(int(20*s),r==0),fill=ink)
        return (x+cols*cw,y+len(rows)*ch)
    if typ=='image':
        path=obj.get('path');
        if path and os.path.exists(path):
            im=Image.open(path).convert('RGBA'); maxw=float(obj.get('width',300)); maxh=float(obj.get('height',220)); im.thumbnail((maxw,maxh)); draw._image.paste(im,(int(x),int(y)),im)
        return (x+float(obj.get('width',300)),y+float(obj.get('height',220)))
    if typ=='group':
        for child in obj.get('children',[]): draw_obj(draw,child,p,theme,canvas_width)
    return (x,y)


def _hand(draw, pos, scale=1.0, ink=(35,35,35)):
    x,y=pos; s=scale; w=max(2,int(4*s));
    # Minimal line-art hand/cursor. Kept intentionally generic, not photorealistic.
    draw.line((x,y+35*s,x+10*s,y+90*s),fill=ink,width=w); draw.line((x,y+35*s,x-8*s,y+5*s),fill=ink,width=w); draw.line((x-8*s,y+5*s,x-2*s,y-5*s),fill=ink,width=w); draw.line((x-2*s,y-5*s,x+4*s,y+5*s),fill=ink,width=w); draw.line((x+4*s,y+5*s,x+18*s,y-5*s),fill=ink,width=w); draw.line((x+18*s,y-5*s,x+25*s,y+5*s),fill=ink,width=w); draw.line((x+25*s,y+5*s,x+35*s,y+18*s),fill=ink,width=w); draw.line((x+35*s,y+18*s,x+42*s,y+35*s),fill=ink,width=w)


def render_scene(scene,out_path,config:ProjectConfig,include_hand=True):
    from cv2 import VideoWriter, VideoWriter_fourcc, cvtColor, COLOR_RGB2BGR
    import numpy as np
    Path(out_path).parent.mkdir(parents=True,exist_ok=True)
    duration=float(scene.get('duration',5)); nframes=max(1,int(duration*config.fps)); size=(config.width,config.height)
    writer=VideoWriter(str(out_path),VideoWriter_fourcc(*'mp4v'),config.fps,size)
    objects=scene.get('objects',[]); theme={'ink':config.ink,'accent':config.accent}; hand=bool(scene.get('hand',include_hand))
    for fi in range(nframes):
        t=fi/max(1,nframes-1); im=Image.new('RGB',size,config.background); draw=ImageDraw.Draw(im)
        last=(config.width*.5,config.height*.5)
        for idx,obj in enumerate(objects):
            start=(idx/max(1,len(objects)))*0.78; end=min(.98,start+.22)
            p=0 if t<start else 1 if t>=end else (t-start)/(end-start)
            last=draw_obj(draw,obj,p,theme,config.width)
        if hand: _hand(draw,last,max(.55,min(1.2,config.width/1280)),hexrgb(config.ink))
        writer.write(cvtColor(np.array(im),COLOR_RGB2BGR))
    writer.release(); return str(out_path)


def concat_videos(paths,out_path):
    Path(out_path).parent.mkdir(parents=True,exist_ok=True); concat=Path(out_path).with_suffix('.concat.txt')
    concat.write_text(''.join("file '"+str(Path(p).resolve()).replace("'","'\\''")+"'\n" for p in paths),encoding='utf-8')
    subprocess.run(['ffmpeg','-y','-f','concat','-safe','0','-i',str(concat),'-c:v','libx264','-pix_fmt','yuv420p',str(out_path)],check=True,capture_output=True)
    return str(out_path)


def mux_audio(video,audio,out_path):
    subprocess.run(['ffmpeg','-y','-i',video,'-i',audio,'-map','0:v:0','-map','1:a:0','-c:v','copy','-c:a','aac','-shortest',str(out_path)],check=True,capture_output=True); return str(out_path)


def render_project(project,out_dir,config=None):
    config=config or ProjectConfig(); out=Path(out_dir); out.mkdir(parents=True,exist_ok=True); scenes=[]
    for i,scene in enumerate(project.get('scenes',[]),1):
        p=out/f'scene_{i:03d}.mp4'; render_scene(scene,p,config,config.hand); scenes.append(str(p))
    silent=out/'whiteboard_silent.mp4'; concat_videos(scenes,silent)
    return str(silent),scenes

# Backward-compatible API used by the original MVP launcher.
def render_storyboard(storyboard, out_dir, fps=30):
    cfg=ProjectConfig(fps=fps)
    return render_project(storyboard,out_dir,cfg)

"""v5.4 semantic-object resilience regression suite."""
from whiteboard_engine.asset_resolver import resolve_scene_graph
from whiteboard_engine.schema import validate_scene_graph
from whiteboard_engine.renderer import render_scene
from whiteboard_engine.schema import ProjectConfig


def _scene(objects):
    return {"meta": {}, "scenes": [{"id": "s1", "duration": 1, "narration": "Explain it.", "objects": objects}]}


def test_domain_vocabulary_is_open_but_malformed_types_still_fail():
    doc = _scene([
        {"type": "tree", "x": 100, "y": 100},
        {"type": "sun", "x": 300, "y": 100},
        {"type": "oxygen", "x": 500, "y": 100},
        {"type": "novel_quantum_particle", "x": 700, "y": 100},
    ])
    resolved = resolve_scene_graph(doc)
    assert all(o["type"] == "icon" for o in resolved["scenes"][0]["objects"])
    assert validate_scene_graph(resolved) == []

    bad = _scene([{"type": {"not": "a string"}, "x": 100, "y": 100}])
    assert validate_scene_graph(bad)


def test_photosynthesis_semantics_render_without_special_case_failures(tmp_path):
    doc = resolve_scene_graph(_scene([
        {"type": "tree", "x": 100, "y": 140},
        {"type": "sun", "x": 330, "y": 120},
        {"type": "chlorophyll", "x": 560, "y": 140},
        {"type": "water", "x": 760, "y": 140},
        {"type": "carbon_dioxide", "x": 930, "y": 140},
        {"type": "oxygen", "x": 1080, "y": 320},
        {"type": "glucose", "x": 760, "y": 430},
    ]))
    out = tmp_path / "semantic.mp4"
    render_scene(doc["scenes"][0], out, ProjectConfig(fps=2), include_hand=False)
    assert out.exists() and out.stat().st_size > 1000


def test_provider_validation_resolves_unknown_model_object_types():
    from whiteboard_engine.teaching_providers import _validate
    doc = _validate(_scene([{"type": "tree", "x": 100, "y": 100}, {"type": "sun", "x": 300, "y": 100}]))
    assert [o["semantic_type"] for o in doc["scenes"][0]["objects"]] == ["tree", "sun"]
    assert all(o["type"] == "icon" for o in doc["scenes"][0]["objects"])

"""Local SketchVox UI: prompt -> teaching story -> deterministic whiteboard MP4."""
from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path

import streamlit as st

try:
    from dotenv import load_dotenv
    load_dotenv(Path(__file__).resolve().parent / ".env")
except Exception:
    pass

from whiteboard_engine.deterministic_director import build_plan
from whiteboard_engine.renderer_worldclass import render_worldclass
from whiteboard_engine.storyboard import generate as generate_gemini
from whiteboard_engine.voiceover import build_scene_voiceover, retime_project_to_audio, concatenate_audio, mux_audio
from whiteboard_engine.scene_graph import normalize_project, validate_v2
from whiteboard_engine.qa import qa_report

st.set_page_config(page_title="SketchVox — Visual Storyteller", layout="wide")
st.title("✏️ SketchVox")
st.caption("Explain a concept visually. Local Qwen3 teaches; Kokoro voices; the deterministic renderer draws the final video.")

with st.sidebar:
    st.subheader("Intelligence")
    intelligence = st.radio("Teaching director", ["Ollama / Qwen3", "Gemini", "Offline"], index=0)
    if intelligence == "Ollama / Qwen3":
        model = st.text_input("Ollama model", os.getenv("SKETCHVOX_OLLAMA_MODEL", "qwen3:8b"))
        strict = st.checkbox("Fail if Ollama fails", True)
        research_file = st.text_input("Optional research file", "")
        st.caption("Local inference: no API key or cloud quota. Ollama must be running.")
    elif intelligence == "Gemini":
        model = st.text_input("Gemini model", os.getenv("SKETCHVOX_GEMINI_MODEL", "gemini-3.8-flash"))
        strict = st.checkbox("Fail if Gemini fails", True)
        research_file = st.text_input("Optional research file", "")
        st.caption("Optional cloud provider. Free-tier quotas apply; avoid confidential/private data.")
    else:
        model = None
        strict = False
        research_file = ""
    st.subheader("Narration")
    narration = st.selectbox("Voice", ["Kokoro (local)", "Gemini TTS", "Local eSpeak", "None"], index=0)
    if narration == "Kokoro (local)":
        voice = st.text_input("Kokoro voice", os.getenv("SKETCHVOX_KOKORO_VOICE", "am_michael"))
        speed = st.number_input("Kokoro speed", min_value=0.6, max_value=1.4, value=float(os.getenv("SKETCHVOX_KOKORO_SPEED", "1.0")), step=0.05)
        tts_model = style = None
    elif narration == "Gemini TTS":
        tts_model = st.text_input("TTS model", os.getenv("SKETCHVOX_TTS_MODEL", "gemini-3.8-flash-tts"))
        voice = st.text_input("Voice", os.getenv("SKETCHVOX_GEMINI_VOICE", "Kore"))
        style = st.text_input("Style", os.getenv("SKETCHVOX_GEMINI_STYLE", "warm, clear, confident educational narration; natural pacing"))
        speed = None
    else:
        tts_model = voice = style = speed = None
    st.subheader("Render")
    hand = st.checkbox("Drawing hand", True)
    texture = st.checkbox("Paper texture", True)

prompt = st.text_area("What should SketchVox explain?", height=130, placeholder="Explain RAG in AI to a beginner")
col1, col2 = st.columns([1, 3])
with col1:
    generate = st.button("Generate video", type="primary", disabled=not prompt.strip())

if generate:
    out = Path("output/ui_run")
    out.mkdir(parents=True, exist_ok=True)
    safe = "_".join(prompt.strip().lower().split())[:48] or "explainer"
    run_dir = out / safe
    run_dir.mkdir(parents=True, exist_ok=True)

    with st.status("Teaching → storyboarding → drawing → QA → MP4...", expanded=True) as status:
        try:
            research = Path(research_file).read_text(encoding="utf-8") if research_file else ""
            if intelligence == "Ollama / Qwen3":
                st.write("Generating teaching plan with local Qwen3…")
                project = generate_gemini(prompt, research=research, language="english", duration=60, model=model, strict=strict, provider="ollama")
            elif intelligence == "Gemini":
                st.write("Generating teaching plan with Gemini…")
                project = generate_gemini(prompt, research=research, language="english", duration=60, model=model, strict=strict, provider="gemini")
            else:
                st.write("Using deterministic offline teaching plan…")
                project = build_plan(prompt)

            project = normalize_project(project)
            st.write(f"Scenes: {len(project.get('scenes', []))} · Concepts: {project.get('meta', {}).get('concept_count', 'n/a')}")

            final_project = project
            if narration != "None":
                provider = "kokoro" if narration == "Kokoro (local)" else ("gemini" if narration == "Gemini TTS" else "local")
                st.write(f"Synthesizing {provider} narration…")
                if narration == "Gemini TTS":
                    old = os.getenv("SKETCHVOX_TTS_MODEL")
                    os.environ["SKETCHVOX_TTS_MODEL"] = tts_model or "gemini-3.8-flash-tts"
                    try:
                        paths, durations = build_scene_voiceover(project, run_dir / "voice", provider="gemini", voice_name=voice, style=style)
                    finally:
                        if old is None:
                            os.environ.pop("SKETCHVOX_TTS_MODEL", None)
                        else:
                            os.environ["SKETCHVOX_TTS_MODEL"] = old
                elif narration == "Kokoro (local)":
                    paths, durations = build_scene_voiceover(project, run_dir / "voice", provider="kokoro", voice=voice, language="english", speed=speed)
                else:
                    paths, durations = build_scene_voiceover(project, run_dir / "voice", provider="local")
                final_project = normalize_project(retime_project_to_audio(project, durations, fps=30))
            errors = validate_v2(final_project)
            report = qa_report(final_project)
            if errors or not report["ok"]:
                raise RuntimeError(f"Visual QA failed: {errors or report['issues']}")

            st.write("Rendering deterministic whiteboard…")
            silent = run_dir / "sketchvox-silent.mp4"
            render_worldclass(final_project, silent, {"hand": hand, "texture": texture, "qa_strict": True})
            final = silent
            if narration != "None":
                audio = run_dir / "voiceover.m4a"
                concatenate_audio(paths, audio, target_durations=[float(s["duration"]) for s in final_project["scenes"]])
                final = run_dir / "sketchvox.mp4"
                mux_audio(silent, audio, final)

            project_json = run_dir / "storyboard.json"
            project_json.write_text(json.dumps(final_project, indent=2, ensure_ascii=False), encoding="utf-8")
            st.session_state["project"] = final_project
            st.session_state["video"] = str(final)
            st.session_state["project_json"] = str(project_json)
            status.update(label="Complete", state="complete", expanded=False)
        except Exception as exc:
            status.update(label="Generation failed", state="error")
            st.exception(exc)

if "project" in st.session_state:
    project = st.session_state["project"]
    st.subheader("Story beats")
    for i, scene in enumerate(project.get("scenes", []), 1):
        beat = scene.get("beat", scene.get("purpose", scene.get("id", f"scene-{i}")))
        with st.expander(f"{i}. {beat}"):
            st.write(scene.get("narration", ""))
            st.caption(f"{scene.get('duration', 0)} sec · {len(scene.get('objects', []))} visual objects")

if "video" in st.session_state:
    st.subheader("Preview")
    st.video(st.session_state["video"])
    with open(st.session_state["video"], "rb") as f:
        st.download_button("Download MP4", f, file_name=Path(st.session_state["video"]).name, mime="video/mp4")

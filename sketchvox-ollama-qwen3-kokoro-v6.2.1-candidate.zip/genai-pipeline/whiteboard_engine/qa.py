"""Preflight visual QA and actionable diagnostics."""
from __future__ import annotations
from dataclasses import dataclass,asdict
from .scene_graph import object_bbox

@dataclass
class Issue:
    severity:str; code:str; message:str; scene:int|None=None; object_id:str|None=None



TEXT_TYPES = {"text", "equation", "number"}
CONTAINER_TYPES = {"round_rect", "rect"}

def _intentional_parent_child(a, b, ab, bb):
    if a.get("type") in CONTAINER_TYPES and b.get("type") in TEXT_TYPES:
        parent, child, pb = a, b, ab
    elif b.get("type") in CONTAINER_TYPES and a.get("type") in TEXT_TYPES:
        parent, child, pb = b, a, bb
    else:
        return False
    if child.get("parent") and parent.get("id"):
        return str(child.get("parent")) == str(parent.get("id"))
    x,y=float(child.get("x",0)),float(child.get("y",0))
    return pb.x+2 <= x <= pb.x2-2 and pb.y+2 <= y <= pb.y2-2
def inspect_project(project,width=1280,height=720)->list[Issue]:
    issues=[]
    for si,scene in enumerate(project.get("scenes",[]),1):
        dur=float(scene.get("duration",0))
        if not scene.get("narration"): issues.append(Issue("warning","NO_NARRATION","Scene has no narration",si))
        if dur>90: issues.append(Issue("error","SCENE_TOO_LONG","Scene exceeds 90 seconds",si))
        visible=0
        boxes=[]
        for obj in scene.get("objects",[]):
            b=object_bbox(obj)
            if b: boxes.append((obj,b)); visible+=1
            if b and obj.get("type") != "summary_board" and (b.x < 40 or b.y < 35 or b.x2 > width-40 or b.y2 > height-35):
                issues.append(Issue("warning","NEAR_EDGE",f"Object is close to canvas edge",si,obj.get("id")))
            if float(obj.get("start",0))+float(obj.get("duration",0))>dur+0.05:
                issues.append(Issue("error","TIMING_OVERFLOW","Object animation exceeds scene duration",si,obj.get("id")))
        if visible==0: issues.append(Issue("error","EMPTY_SCENE","Scene has no renderable objects",si))
        for i,(a,ab) in enumerate(boxes):
            for b,bb in boxes[i+1:]:
                if ab.intersects(bb, padding=4) and a.get("allow_overlap") is not True and b.get("allow_overlap") is not True:
                    # Simultaneous objects are more likely to be visually problematic.
                    a0=float(a.get("start",0)); a1=a0+float(a.get("duration",0)); b0=float(b.get("start",0)); b1=b0+float(b.get("duration",0))
                    if max(a0,b0) < min(a1,b1):
                        # Containment is often intentional (text inside a card,
                        # annotation inside a chart, etc.).
                        contains = (ab.x <= bb.x and ab.y <= bb.y and ab.x2 >= bb.x2 and ab.y2 >= bb.y2) or (bb.x <= ab.x and bb.y <= ab.y and bb.x2 >= ab.x2 and bb.y2 >= ab.y2)
                        intentional = a.get("allow_overlap") is True or b.get("allow_overlap") is True
                        if not contains and not intentional and not _intentional_parent_child(a, b, ab, bb):
                            arrow_label_adjacent = (a.get("type") in {"arrow","line"} and b.get("type") in {"text","number","equation"} and abs(float(b.get("x",0))-float(a.get("x2",0))) < 24) or (b.get("type") in {"arrow","line"} and a.get("type") in {"text","number","equation"} and abs(float(a.get("x",0))-float(b.get("x2",0))) < 24)
                            # Intentional semantic attachments are not collisions.
                            semantic_attachment = (
                                a.get("type") in {"arrow", "line", "highlight"}
                                or b.get("type") in {"arrow", "line", "highlight"}
                                or {a.get("type"), b.get("type")} in ({"document", "lock"}, {"wallet", "coin"}, {"bank", "coin"})
                            )
                            if not arrow_label_adjacent and not semantic_attachment:
                                issues.append(Issue("warning","OVERLAP",f"Objects overlap during animation",si,b.get("id")))

    summary_scenes=[s for s in project.get("scenes",[]) if str(s.get("purpose","")).lower() in {"summary","recap"} or any(o.get("type")=="summary_board" for o in s.get("objects",[]))]
    if len(summary_scenes)!=1:
        issues.append(Issue("error","SUMMARY_COUNT",f"Expected exactly one final summary scene; found {len(summary_scenes)}"))
    elif summary_scenes[-1] is not project.get("scenes",[])[-1]:
        issues.append(Issue("error","SUMMARY_NOT_FINAL","Summary scene must be the final scene"))
    else:
        boards=[o for o in summary_scenes[0].get("objects",[]) if o.get("type")=="summary_board"]
        if len(boards)!=1:
            issues.append(Issue("error","SUMMARY_BOARD_COUNT",f"Expected exactly one summary_board; found {len(boards)}"))
        elif int(project.get("meta",{}).get("concept_count",len(boards[0].get("cards",[])))) != len(boards[0].get("cards",[])):
            issues.append(Issue("error","SUMMARY_CONCEPT_MISMATCH","Summary card count does not match concept_count"))
    currency=project.get("meta",{}).get("currency")
    if currency:
        symbols={"INR":"₹","USD":"$","EUR":"€","GBP":"£"}
        symbol=symbols.get(str(currency).upper())
        if symbol:
            all_text=[]
            for sc in project.get("scenes",[]):
                all_text.append(str(sc.get("narration","")))
                for o in sc.get("objects",[]):
                    all_text.extend(str(o.get(k,"")) for k in ("text","value","label","title","subtitle","takeaway"))
                    if o.get("type")=="summary_board":
                        for c in o.get("cards",[]): all_text.extend([str(c.get("title","")),str(c.get("takeaway",""))])
            joined=" ".join(all_text)
            foreign=[s for s in ("₹","$","€","£") if s in joined and s!=symbol]
            if foreign:
                issues.append(Issue("error","MIXED_CURRENCY",f"Mixed currency symbols detected; expected {symbol}, found {foreign}"))
    return issues

def qa_report(project,width=1280,height=720):
    issues=inspect_project(project,width,height)
    return {"ok":not any(i.severity=="error" for i in issues),"issues":[asdict(i) for i in issues]}

#!/usr/bin/env python3
"""Run SketchVox OCR/raster/semantic QA against an existing MP4 + storyboard."""
from __future__ import annotations
import argparse, json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from whiteboard_engine.visual_qa import inspect_rendered_video


def main():
    ap=argparse.ArgumentParser(description="Inspect an existing SketchVox MP4 with OCR + rendered-frame QA")
    ap.add_argument("video")
    ap.add_argument("storyboard")
    ap.add_argument("--samples",type=int,default=4)
    ap.add_argument("--out",default=None)
    args=ap.parse_args()
    project=json.loads(Path(args.storyboard).read_text(encoding="utf-8"))
    report=inspect_rendered_video(args.video,project,1280,720,30,hand=True,per_scene=args.samples)
    out=Path(args.out) if args.out else Path(args.video).with_suffix(".visual-qa.json")
    out.write_text(json.dumps(report,indent=2,ensure_ascii=False),encoding="utf-8")
    print(json.dumps(report,indent=2,ensure_ascii=False))
    raise SystemExit(0 if report.get("ok") and not any(i.get("severity")=="warning" for i in report.get("issues",[])) else 2)

if __name__=="__main__":
    main()

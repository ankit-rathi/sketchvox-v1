import json
from whiteboard_engine.storyboard import fallback
from whiteboard_engine.schema import validate_scene_graph

def test_fallback_valid():
    doc=fallback('compound interest'); assert not validate_scene_graph(doc)

def test_json_roundtrip(tmp_path):
    doc=fallback('ETFs'); p=tmp_path/'x.json'; p.write_text(json.dumps(doc),encoding='utf-8'); assert json.loads(p.read_text())['scenes']


def test_ollama_payload_uses_schema_and_no_thinking(monkeypatch):
    import json
    from whiteboard_engine import teaching_providers as tp

    captured = {}

    class Resp:
        def __enter__(self): return self
        def __exit__(self, *args): pass
        def read(self):
            doc = {"meta": {}, "scenes": [{"duration": 1, "narration": "x", "objects": []}]}
            return json.dumps({"message": {"content": json.dumps(doc)}}).encode()

    def fake_urlopen(req, timeout=0):
        captured.update(json.loads(req.data.decode()))
        return Resp()

    monkeypatch.setattr(tp.urllib.request, "urlopen", fake_urlopen)
    schema = {"type": "object", "properties": {"meta": {"type": "object"}, "scenes": {"type": "array"}}}
    doc = tp.generate_ollama("hello", "qwen3:8b", schema, "system")
    assert doc["scenes"]
    assert captured["model"] == "qwen3:8b"
    assert captured["stream"] is False
    assert captured["think"] is False
    assert captured["format"] == schema


def test_storyboard_compiler_removes_duplicate_summary_and_enforces_currency(monkeypatch):
    from whiteboard_engine.storyboard import _repair_summary_contract
    doc={
        "meta":{"title":"Compound Interest","concepts":[{"title":"Concept"},{"title":"Concept"},{"title":"Concept"}]},
        "scenes":[
            {"purpose":"hook","duration":4,"narration":"Start with $100.","objects":[{"type":"money","x":100,"y":100,"label":"$100"},{"type":"text","x":100,"y":100,"text":"$100"}]},
            {"purpose":"example","duration":8,"narration":"After one year, $100 becomes $105.","objects":[{"type":"money","x":100,"y":100,"label":"$105"},{"type":"text","x":100,"y":100,"text":"$105"}]},
            {"purpose":"summary","duration":8,"narration":"Old summary","objects":[{"type":"summary_board","cards":[{"title":"Concept","takeaway":"x"}]}]},
            {"purpose":"summary","duration":8,"narration":"Another summary","objects":[{"type":"summary_board","cards":[{"title":"Concept","takeaway":"y"}]}]},
        ]
    }
    out=_repair_summary_contract(doc,currency="INR")
    assert len(out["scenes"]) == 3
    assert out["scenes"][-1]["purpose"] == "summary"
    assert sum(o.get("type")=="summary_board" for o in out["scenes"][-1]["objects"]) == 1
    assert out["meta"]["concept_count"] == 1
    joined=json.dumps(out,ensure_ascii=False)
    assert "$" not in joined and "₹" in joined


def test_normalize_stages_zero_start_objects_and_sanitizes_color():
    from whiteboard_engine.scene_graph import normalize_project
    p=normalize_project({"meta":{"currency":"INR"},"scenes":[{"duration":6,"narration":"x","objects":[
        {"type":"text","x":100,"y":100,"text":"₹100","color":"No"},
        {"type":"text","x":100,"y":160,"text":"₹105","color":"#00AA00"},
        {"type":"text","x":100,"y":220,"text":"₹110","color":"None"},
    ]}]})
    starts=[o["start"] for o in p["scenes"][0]["objects"]]
    assert starts == sorted(starts) and len(set(starts)) == 3
    assert all(len(o["color"])==7 and o["color"].startswith("#") for o in p["scenes"][0]["objects"])


def test_renderer_rgb_is_defensive():
    from whiteboard_engine.renderer_worldclass import _rgb
    assert _rgb("No") == (38,38,38)
    assert _rgb("#0af") == (0,170,255)


def test_normalize_project_repairs_color_in_stroke():
    from whiteboard_engine.scene_graph import normalize_project
    doc = {
        "meta": {},
        "scenes": [{
            "duration": 5,
            "narration": "test",
            "objects": [{"type": "line", "x": 100, "y": 100, "x2": 300, "y2": 100, "stroke": "#000000"}]
        }]
    }
    out = normalize_project(doc)
    obj = out["scenes"][0]["objects"][0]
    assert obj["stroke"] == 4.0
    assert obj["color"] == "#000000"


def test_hybrid_compiler_uses_demo_quality_benchmark_plan():
    from whiteboard_engine.hybrid_director import compile_story
    from whiteboard_engine.scene_graph import normalize_project
    doc = normalize_project(compile_story(
        "Explain compound interest to a beginner",
        {"meta": {"title": "Qwen draft", "concepts": [{"title": "Concept"}]}, "scenes": []},
    ))
    assert doc["meta"]["director"] == "5.4.0-hybrid-teaching-first"
    assert doc["meta"]["visual_regression_class"] == "compound_interest"
    assert doc["meta"]["concept_count"] == 3
    summary = [o for s in doc["scenes"] for o in s["objects"] if o.get("type") == "summary_board"]
    assert len(summary) == 1 and len(summary[0]["cards"]) == 3
    assert any(o.get("type") == "chart" for s in doc["scenes"] for o in s["objects"])


def test_preflight_all_four_visual_regression_benchmarks_are_clean():
    from whiteboard_engine.hybrid_director import compile_story
    from whiteboard_engine.scene_graph import normalize_project
    from whiteboard_engine.qa import qa_report
    prompts = [
        "Explain compound interest to a beginner",
        "Explain RAG in AI to a beginner",
        "Explain what an ETF is",
        "Explain moving average to a beginner",
    ]
    for prompt in prompts:
        doc = normalize_project(compile_story(prompt, {"meta": {}, "scenes": []}))
        assert qa_report(doc)["ok"]

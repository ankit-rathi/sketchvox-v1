#!/usr/bin/env python3
"""Prompt -> local Ollama/Qwen3 -> Kokoro -> deterministic SketchVox MP4."""
from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

try:
    from dotenv import load_dotenv
    load_dotenv(ROOT / ".env")
except Exception:
    pass

from whiteboard_engine.storyboard import generate
from whiteboard_engine.voiceover import build_scene_voiceover, retime_project_to_audio, concatenate_audio, mux_audio
from whiteboard_engine.renderer_worldclass import render_worldclass
from whiteboard_engine.scene_graph import normalize_project, validate_v2
from whiteboard_engine.timing import fit_project_duration
from whiteboard_engine.qa import qa_report
from whiteboard_engine.design_system import design_advisory


def probe_duration(path: Path, stream: str) -> float:
    return float(subprocess.check_output([
        "ffprobe", "-v", "error", "-show_entries", f"stream=duration", "-select_streams", stream,
        "-of", "default=nw=1:nk=1", str(path)
    ], text=True).strip())


def main():
    ap = argparse.ArgumentParser(description="SketchVox: local Qwen3 teaching + Kokoro TTS + deterministic renderer")
    ap.add_argument("prompt", help="Topic/question to explain")
    ap.add_argument("--research-file", help="Optional UTF-8 research/source notes")
    ap.add_argument("--language", default="english")
    ap.add_argument("--duration", type=int, default=60)
    ap.add_argument("--currency", choices=["auto","INR","USD","EUR","GBP"], default="auto", help="Finance currency; auto detects explicit currency, otherwise INR")
    ap.add_argument("--model", default=None, help="Ollama model; default SKETCHVOX_OLLAMA_MODEL")
    ap.add_argument("--voice", default=None, help="Kokoro voice; default SKETCHVOX_KOKORO_VOICE")
    ap.add_argument("--tts-provider", choices=["kokoro","clone"], default="kokoro", help="Voice engine; clone uses an authorized reference voice via SKETCHVOX_CLONER_CMD")
    ap.add_argument("--voice-reference", default=None, help="Authorized reference recording for --tts-provider clone")
    ap.add_argument("--speed", type=float, default=None, help="Kokoro speech speed, e.g. 1.0")
    ap.add_argument("--out-dir", default="output/local")
    ap.add_argument("--qa-passes", type=int, default=12, help="Maximum closed-loop render/inspect/repair passes")
    ap.add_argument("--no-voice", action="store_true")
    ap.add_argument("--strict", action="store_true", help="Fail instead of compiling a semantic storyboard when the visual LLM stage fails")
    ap.add_argument("--ollama-answer-timeout", type=int, default=None, help="AnswerIR timeout in seconds")
    ap.add_argument("--ollama-visual-timeout", type=int, default=None, help="Visual Director timeout in seconds")
    ap.add_argument("--offline", action="store_true", help="Use deterministic teaching director instead of Ollama")
    ap.add_argument("--no-hand", action="store_true")
    ap.add_argument("--no-texture", action="store_true")
    args = ap.parse_args()

    os.environ["SKETCHVOX_CURRENCY"]=args.currency
    if args.ollama_answer_timeout is not None:
        os.environ["SKETCHVOX_ANSWER_TIMEOUT"] = str(args.ollama_answer_timeout)
    if args.ollama_visual_timeout is not None:
        os.environ["SKETCHVOX_VISUAL_TIMEOUT"] = str(args.ollama_visual_timeout)

    if args.offline:
        provider = "offline"
    else:
        provider = "ollama"

    # Kokoro 0.9.x currently requires Python <3.13. Fail fast with an
    # actionable message instead of generating a storyboard and failing during
    # TTS import. --no-voice remains usable on newer Python versions.
    if not args.no_voice and args.tts_provider == "kokoro" and sys.version_info >= (3, 13):
        raise SystemExit(
            "Kokoro voiceover requires Python 3.10-3.12. "
            "Create a dedicated venv with Python 3.12, install "
            "requirements-kokoro.txt, and rerun. "
            "Use --no-voice if you only want the video/teaching pipeline."
        )

    research = Path(args.research_file).read_text(encoding="utf-8") if args.research_file else ""
    print(f"[1/5] Teaching director ({provider} → hybrid visual compiler): {args.prompt}")
    project = generate(args.prompt, research=research, language=args.language, duration=args.duration,
                       model=args.model, strict=args.strict, provider=provider)
    project = normalize_project(project)
    project = fit_project_duration(project, args.duration, min_scene=2.8)
    project = normalize_project(project)
    print(f"      mode={project.get('meta', {}).get('mode')} model={project.get('meta', {}).get('model', 'offline')} director={project.get('meta', {}).get('director', 'legacy')}")
    print(f"      scenes={len(project.get('scenes', []))} concepts={project.get('meta', {}).get('concept_count', 'n/a')}")

    out = Path(args.out_dir)
    out.mkdir(parents=True, exist_ok=True)
    project_design_qa=design_advisory(project)
    (out / "design-qa.json").write_text(json.dumps(project_design_qa, indent=2, ensure_ascii=False), encoding="utf-8")
    (out / "storyboard.json").write_text(json.dumps(project, indent=2, ensure_ascii=False), encoding="utf-8")

    if args.no_voice:
        errors = validate_v2(project)
        qa = qa_report(project)
        if errors or not qa["ok"]:
            raise SystemExit(f"QA failed: {errors or qa['issues']}")
        silent = out / "sketchvox-silent.mp4"
        _, project, render_qa = render_worldclass(project, silent, {"hand": not args.no_hand, "texture": not args.no_texture, "qa_strict": True, "visual_qa": True, "visual_qa_repair": True, "visual_qa_passes": args.qa_passes, "visual_qa_samples": 4, "qa_standard_strict": True, "return_details": True})
        (out / "storyboard.json").write_text(json.dumps(project, indent=2, ensure_ascii=False), encoding="utf-8")
        (out / "report.json").write_text(json.dumps({"prompt":args.prompt,"rendered_frame_qa":render_qa,"qa_ok":render_qa.get("ok",False),"final":str(silent)}, indent=2), encoding="utf-8")
        print(f"[done] {silent}")
        return

    print(f"[2/5] {args.tts_provider} TTS: synthesizing scene narration")
    if args.tts_provider == "clone":
        if not args.voice_reference:
            raise SystemExit("--voice-reference is required when --tts-provider clone is selected.")
        voice_kwargs = {"reference_audio": args.voice_reference}
    else:
        voice_kwargs = {"voice": args.voice or os.getenv("SKETCHVOX_KOKORO_VOICE", "am_michael"), "language": args.language}
        if args.speed is not None:
            voice_kwargs["speed"] = args.speed
    paths, durations = build_scene_voiceover(project, out / "voice", provider=args.tts_provider, **voice_kwargs)

    print("[3/5] Retiming visuals to actual narration")
    synced = normalize_project(retime_project_to_audio(project, durations, fps=30))
    errors = validate_v2(synced)
    qa = qa_report(synced)
    if errors or not qa["ok"]:
        raise SystemExit(f"QA failed before render: {errors or qa['issues']}")
    design_sync_qa=design_advisory(synced)
    (out / "design-qa-synced.json").write_text(json.dumps(design_sync_qa, indent=2, ensure_ascii=False), encoding="utf-8")
    (out / "storyboard-synced.json").write_text(json.dumps(synced, indent=2, ensure_ascii=False), encoding="utf-8")

    print("[4/5] Deterministic whiteboard render + rendered-frame QA/auto-repair")
    silent = out / "sketchvox-silent.mp4"
    _, synced, render_qa = render_worldclass(
        synced, silent,
        {"hand": not args.no_hand, "texture": not args.no_texture, "qa_strict": True,
         "visual_qa": True, "visual_qa_repair": True, "visual_qa_passes": args.qa_passes, "visual_qa_samples": 4, "qa_standard_strict": True, "return_details": True}
    )
    (out / "storyboard-synced.json").write_text(json.dumps(synced, indent=2, ensure_ascii=False), encoding="utf-8")

    print("[5/5] Muxing audio + final QA")
    audio = out / "kokoro-voiceover.m4a"
    concatenate_audio(paths, audio, target_durations=[float(s["duration"]) for s in synced["scenes"]])
    final = out / "sketchvox-local.mp4"
    mux_audio(silent, audio, final)
    vdur = probe_duration(final, "v:0")
    adur = probe_duration(final, "a:0")
    # Final gate re-inspects the actual muxed MP4 video stream. The mux step is
    # expected to preserve video exactly, but the production contract verifies
    # the returned artifact rather than assuming that.
    from whiteboard_engine.visual_qa import inspect_rendered_video
    final_visual_qa = inspect_rendered_video(final, synced, 1280, 720, 30, hand=not args.no_hand, per_scene=4)
    delta = abs(vdur - adur)
    if delta > (1 / 30 + 0.03):
        raise SystemExit(f"A/V sync QA failed: video={vdur:.3f}s audio={adur:.3f}s delta={delta:.3f}s")
    if not final_visual_qa.get("ok", False):
        raise SystemExit(f"Final rendered-frame QA failed after mux: {final_visual_qa}")
    report = {
        "prompt": args.prompt,
        "llm_provider": provider,
        "model": project.get("meta", {}).get("model", "offline"),
        "tts_provider": args.tts_provider,
        "tts_voice": args.voice or os.getenv("SKETCHVOX_KOKORO_VOICE", "am_michael") if args.tts_provider == "kokoro" else "personal_reference",
        "voice_reference": args.voice_reference if args.tts_provider == "clone" else None,
        "concept_count": project.get("meta", {}).get("concept_count"),
        "scene_audio_durations": durations,
        "final_video_duration": vdur,
        "final_audio_duration": adur,
        "final_av_delta": delta,
        "qa_ok": qa["ok"] and render_qa.get("ok", False) and final_visual_qa.get("ok", False),
        "rendered_frame_qa": render_qa,
        "design_qa": design_advisory(synced),
        "final_rendered_frame_qa": final_visual_qa,
        "final": str(final),
    }
    (out / "report.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()

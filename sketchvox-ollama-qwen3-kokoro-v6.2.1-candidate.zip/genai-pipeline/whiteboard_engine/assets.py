"""Reusable programmatic doodle asset library."""
from __future__ import annotations
import math
from PIL import ImageDraw, ImageFont


def font(size, bold=False):
    """Load the bundled doodle typefaces first, with platform fallback.

    Comic Neue is the primary SketchVox handwriting/display face.  Keeping the
    lookup here means renderer and geometry QA use identical metrics.
    """
    import os
    root=os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
    bundled=os.path.join(root,"assets","fonts")
    paths=[
        os.path.join(bundled,"ComicNeue-Bold.otf" if bold else "ComicNeue-Regular.otf"),
        os.path.join(bundled,"NotoSans-Bold.ttf" if bold else "NotoSans-Regular.ttf"),
        "C:/Windows/Fonts/arialbd.ttf" if bold else "C:/Windows/Fonts/arial.ttf",
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf" if bold else "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
    ]
    for p in paths:
        if os.path.exists(p):
            return ImageFont.truetype(p,int(size))
    return ImageFont.load_default()


def stroke(draw, pts, ink, width=5): draw.line(pts, fill=ink, width=width, joint="curve")

def draw_icon(draw, typ, x, y, scale, ink, accent, progress=1.0, label=None):
    s=scale; w=max(2,int(5*s)); p=max(0,min(1,progress))
    def text(t, dx=0, dy=0, size=30, bold=False): draw.text((x+dx*s,y+dy*s),t,font=font(int(size*s),bold),fill=ink)
    if typ=="coin":
        r=35*s; draw.ellipse((x-r,y-r,x+r,y+r),outline=ink,width=w); text("₹",-14,-25,48,True)
    elif typ=="wallet":
        draw.rounded_rectangle((x,y,x+150*s,y+95*s),radius=int(15*s),outline=ink,width=w); draw.line((x+95*s,y+55*s,x+150*s,y+55*s),fill=ink,width=w); draw.ellipse((x+112*s,y+48*s,x+122*s,y+58*s),fill=ink)
    elif typ=="house":
        pts=[(x,y+65*s),(x+75*s,y),(x+150*s,y+65*s),(x+150*s,y+165*s),(x,y+165*s),(x,y+65*s)]; draw.polygon(pts,outline=ink); draw.rectangle((x+55*s,y+100*s,x+95*s,y+165*s),outline=ink,width=w)
    elif typ=="calculator":
        draw.rounded_rectangle((x,y,x+120*s,y+165*s),radius=int(10*s),outline=ink,width=w); draw.rectangle((x+18*s,y+18*s,x+102*s,y+52*s),outline=ink,width=w)
        for rr in range(3):
            for cc in range(3): draw.ellipse((x+(20+32*cc)*s,y+(70+28*rr)*s,x+(30+32*cc)*s,y+(80+28*rr)*s),fill=ink)
    elif typ=="lightbulb":
        r=45*s; draw.ellipse((x-r,y-r,x+r,y+r),outline=ink,width=w); draw.line((x-25*s,y+40*s,x+25*s,y+40*s),fill=ink,width=w); draw.line((x-18*s,y+55*s,x+18*s,y+55*s),fill=ink,width=w)
    elif typ=="warning":
        pts=[(x,y-60*s),(x-70*s,y+60*s),(x+70*s,y+60*s)]; draw.polygon(pts,outline=ink); text("!",-10,-25,60,True)
    elif typ in ("check","cross"):
        if typ=="check": stroke(draw,[(x-45*s,y),(x-10*s,y+35*s),(x+55*s,y-45*s)],ink,w)
        else: stroke(draw,[(x-40*s,y-40*s),(x+40*s,y+40*s)],ink,w); stroke(draw,[(x+40*s,y-40*s),(x-40*s,y+40*s)],ink,w)
    elif typ=="magnifier":
        r=42*s; draw.ellipse((x-r,y-r,x+r,y+r),outline=ink,width=w); draw.line((x+30*s,y+30*s,x+80*s,y+80*s),fill=ink,width=w)
    elif typ=="book":
        draw.polygon([(x,y),(x+65*s,y+15*s),(x+65*s,y+135*s),(x,y+120*s)],outline=ink); draw.polygon([(x+65*s,y+15*s),(x+130*s,y),(x+130*s,y+120*s),(x+65*s,y+135*s)],outline=ink)
    elif typ=="robot":
        draw.rounded_rectangle((x-65*s,y-55*s,x+65*s,y+65*s),radius=int(15*s),outline=ink,width=w); draw.ellipse((x-35*s,y-20*s,x-15*s,y),fill=ink); draw.ellipse((x+15*s,y-20*s,x+35*s,y),fill=ink); draw.line((x-25*s,y+35*s,x+25*s,y+35*s),fill=ink,width=w); draw.line((x,y-55*s,x,y-85*s),fill=ink,width=w); draw.ellipse((x-8*s,y-93*s,x+8*s,y-77*s),outline=ink,width=w)
    elif typ=="brain":
        draw.ellipse((x-65*s,y-55*s,x+5*s,y+55*s),outline=ink,width=w); draw.ellipse((x-5*s,y-55*s,x+65*s,y+55*s),outline=ink,width=w); stroke(draw,[(x-20*s,y-35*s),(x-35*s,y-5*s),(x-15*s,y+20*s),(x-35*s,y+40*s)],ink,w)
    elif typ=="database":
        for yy in (0,45,90): draw.ellipse((x-65*s,y+yy*s,x+65*s,y+(yy+35)*s),outline=ink,width=w)
        draw.line((x-65*s,y+17*s,x-65*s,y+107*s),fill=ink,width=w); draw.line((x+65*s,y+17*s,x+65*s,y+107*s),fill=ink,width=w)
    elif typ=="server":
        for yy in (0,55,110):
            draw.rounded_rectangle((x-80*s,y+yy*s,x+80*s,y+(yy+42)*s),radius=int(7*s),outline=ink,width=w); draw.ellipse((x-60*s,y+(yy+14)*s,x-48*s,y+(yy+26)*s),fill=accent); draw.line((x-20*s,y+(yy+20)*s,x+50*s,y+(yy+20)*s),fill=ink,width=w)
    elif typ=="cloud":
        draw.ellipse((x-90*s,y-10*s,x-20*s,y+50*s),outline=ink,width=w); draw.ellipse((x-45*s,y-45*s,x+40*s,y+50*s),outline=ink,width=w); draw.ellipse((x+10*s,y-5*s,x+85*s,y+50*s),outline=ink,width=w); draw.line((x-90*s,y+50*s,x+85*s,y+50*s),fill=ink,width=w)
    elif typ=="gpu":
        draw.rectangle((x-75*s,y-55*s,x+75*s,y+55*s),outline=ink,width=w); draw.rectangle((x-40*s,y-30*s,x+40*s,y+30*s),outline=ink,width=w); 
        for i in range(-60,61,30): draw.line((x+i*s,y-70*s,x+i*s,y-55*s),fill=ink,width=w); draw.line((x+i*s,y+55*s,x+i*s,y+70*s),fill=ink,width=w)
    elif typ=="api":
        draw.rounded_rectangle((x-65*s,y-45*s,x+65*s,y+45*s),radius=int(12*s),outline=ink,width=w); text("API",-28,-22,42,True)
    elif typ=="person":
        r=32*s; draw.ellipse((x-r,y-r,x+r,y+r),outline=ink,width=w); stroke(draw,[(x,y+r),(x,y+110*s)],ink,w); stroke(draw,[(x,y+55*s),(x-45*s,y+90*s)],ink,w); stroke(draw,[(x,y+55*s),(x+45*s,y+90*s)],ink,w); stroke(draw,[(x,y+110*s),(x-40*s,y+165*s)],ink,w); stroke(draw,[(x,y+110*s),(x+40*s,y+165*s)],ink,w)
    elif typ=="money":
        draw.rounded_rectangle((x,y,x+180*s,y+105*s),radius=int(12*s),outline=ink,width=w); text(label or "₹",65,18,58,True)
    elif typ in {"tree", "leaf", "sun", "water", "oxygen", "carbon_dioxide", "glucose", "dna", "cell", "atom", "molecule", "energy", "force", "gradient", "loss", "token", "query", "attention", "neuron", "probability", "generic"}:
        # Deterministic semantic glyphs: recognisable enough to teach, but
        # deliberately simple so every novel domain remains renderer-safe.
        lab = label or typ.replace("_", " ")
        if typ == "tree":
            draw.line((x,y+70*s,x,y+150*s),fill=ink,width=w); draw.line((x,y+105*s,x-35*s,y+80*s),fill=ink,width=w); draw.line((x,y+105*s,x+35*s,y+80*s),fill=ink,width=w)
            draw.ellipse((x-70*s,y-10*s,x+5*s,y+85*s),outline=ink,width=w); draw.ellipse((x-5*s,y-30*s,x+70*s,y+75*s),outline=ink,width=w)
        elif typ == "sun":
            r=42*s; draw.ellipse((x-r,y-r,x+r,y+r),outline=ink,width=w)
            for a in range(0,360,45):
                import math as _m; draw.line((x+55*s*_m.cos(_m.radians(a)),y+55*s*_m.sin(_m.radians(a)),x+78*s*_m.cos(_m.radians(a)),y+78*s*_m.sin(_m.radians(a))),fill=ink,width=w)
        elif typ == "water":
            draw.polygon([(x,y-65*s),(x-42*s,y+10*s),(x-35*s,y+48*s),(x,y+72*s),(x+35*s,y+48*s),(x+42*s,y+10*s)],outline=ink)
        elif typ in {"oxygen", "carbon_dioxide", "glucose", "generic", "token", "query", "probability"}:
            draw.rounded_rectangle((x-72*s,y-42*s,x+72*s,y+42*s),radius=int(14*s),outline=ink,width=w); text(lab[:12],-50,-16,26,True)
        elif typ == "leaf":
            draw.ellipse((x-18*s,y-75*s,x+45*s,y+70*s),outline=ink,width=w); draw.line((x-5*s,y+60*s,x+25*s,y-55*s),fill=ink,width=w)
        elif typ == "energy":
            pts=[(x-12*s,y-70*s),(x+28*s,y-10*s),(x+4*s,y-10*s),(x+24*s,y+68*s),(x-30*s,y+2*s),(x-4*s,y+2*s)]
            draw.polygon(pts,outline=ink)
        elif typ == "cell":
            draw.ellipse((x-62*s,y-62*s,x+62*s,y+62*s),outline=ink,width=w)
            draw.ellipse((x-18*s,y-22*s,x+18*s,y+22*s),outline=accent,width=max(2,int(4*s)))
            draw.line((x-45*s,y-8*s,x-18*s,y-12*s),fill=ink,width=max(2,int(3*s)))
        elif typ in {"dna", "molecule", "neuron", "attention", "gradient", "loss", "force", "atom"}:
            draw.ellipse((x-52*s,y-52*s,x+52*s,y+52*s),outline=ink,width=w); draw.line((x-35*s,y-35*s,x+35*s,y+35*s),fill=ink,width=w); draw.line((x+35*s,y-35*s,x-35*s,y+35*s),fill=ink,width=w); text(lab[:10],-38,68,22,True)

"""SketchVox Teaching Contract 2.0.

A stable semantic bridge between AnswerIR, teaching beats, visual scenes and
summary cards.  The contract is authoritative for *what* is taught; the visual
compiler is responsible only for *how* it is shown.
"""
from __future__ import annotations

import re
from copy import deepcopy
from typing import Any

CONCEPT_TYPES = {
    "DEFINITION", "MECHANISM", "COMPONENT", "RELATIONSHIP", "CALCULATION",
    "EXAMPLE", "COMPARISON", "MISCONCEPTION", "INTERPRETATION", "MENTAL_MODEL",
}


def _slug(value: str) -> str:
    s = re.sub(r"[^a-z0-9]+", "_", str(value or "").lower()).strip("_")
    return s[:56] or "concept"


def stable_concept_id(name: str, used: set[str] | None = None) -> str:
    """Create a deterministic ID from the canonical concept name."""
    used = used if used is not None else set()
    base = "c_" + _slug(name)
    candidate = base
    i = 2
    while candidate in used:
        candidate = f"{base}_{i}"
        i += 1
    used.add(candidate)
    return candidate


def infer_concept_type(name: str, explanation: str = "") -> str:
    text = (str(name) + " " + str(explanation)).lower()
    if any(k in text for k in ("formula", "divided", "divide", "multiplied", "calculate", "computed", "equation", "average")):
        return "CALCULATION"
    if any(k in text for k in ("example", "suppose", "imagine", "for instance")):
        return "EXAMPLE"
    if any(k in text for k in ("not ", "isn't", "versus", "vs", "distinction", "confused", "rather than")):
        return "MISCONCEPTION"
    if any(k in text for k in ("because", "causes", "leads to", "depends on", "relationship", "relative to")):
        return "RELATIONSHIP"
    if any(k in text for k in ("how", "works", "step", "process", "flow", "predict", "retrieve", "generate")):
        return "MECHANISM"
    if any(k in text for k in ("part", "component", "contains", "includes", "consists")):
        return "COMPONENT"
    return "DEFINITION"


def evidence_requirements(concept: dict[str, Any]) -> dict[str, Any]:
    ctype = str(concept.get("type") or "DEFINITION").upper()
    req = {"narration": True, "visual": True, "display_label": True}
    if ctype == "CALCULATION":
        req["visual"] = True; req["formula_or_operation"] = True
    elif ctype == "COMPARISON":
        req["visual"] = True; req["comparison"] = True
    elif ctype == "MECHANISM":
        req["visual"] = True; req["flow_or_transformation"] = True
    elif ctype == "MISCONCEPTION":
        req["visual"] = True; req["contrast"] = True
    elif ctype == "EXAMPLE":
        req["visual"] = True; req["concrete_example"] = True
    return req


def normalize_contract(answer_ir: dict[str, Any]) -> dict[str, Any]:
    """Normalize AnswerIR concepts into stable, model-independent identities."""
    out = deepcopy(answer_ir)
    used: set[str] = set()
    concepts = []
    for raw in out.get("concepts", []) or []:
        if not isinstance(raw, dict):
            continue
        name = str(raw.get("name") or raw.get("title") or raw.get("concept") or "").strip()
        if not name:
            continue
        explanation = str(raw.get("explanation") or raw.get("takeaway") or raw.get("support") or "").strip()
        cid = stable_concept_id(name, used)
        ctype = str(raw.get("type") or infer_concept_type(name, explanation)).upper()
        if ctype not in CONCEPT_TYPES:
            ctype = infer_concept_type(name, explanation)
        concepts.append({
            "id": cid,
            "name": name,
            "type": ctype,
            "explanation": explanation,
            "why_it_matters": str(raw.get("why_it_matters") or "").strip(),
            "prerequisites": list(raw.get("prerequisites") or []),
            "evidence_requirements": raw.get("evidence_requirements") or evidence_requirements({"type": ctype}),
        })
    out["concepts"] = concepts
    out["must_explain"] = [c["name"] for c in concepts]
    out["version"] = "5.4"
    out["teaching_contract_version"] = "2.0"
    return out


def build_teaching_contract(answer_ir: dict[str, Any]) -> dict[str, Any]:
    """Build first-class teaching beats from the locked AnswerIR."""
    beats = []
    concepts = answer_ir.get("concepts", []) or []
    for i, c in enumerate(concepts, 1):
        cid = c["id"]
        beats.append({
            "beat_id": f"beat_{i:02d}_{cid[2:]}" if cid.startswith("c_") else f"beat_{i:02d}",
            "concept_ids": [cid],
            "concept": c.get("name", ""),  # legacy compatibility alias
            "objective": c.get("explanation") or f"Explain {c.get('name')}",
            "teaching_mode": str(c.get("type") or "DEFINITION").lower(),
            "required_narration": True,
            "required_visual_evidence": True,
            "summary_required": True,
            "evidence_requirements": c.get("evidence_requirements") or evidence_requirements(c),
        })
    return {
        "version": "2.0",
        "topic": answer_ir.get("topic"),
        "answer_ir_version": answer_ir.get("version"),
        "beats": beats,
        "final_mental_model": answer_ir.get("final_mental_model", ""),
    }


def _is_summary(scene: dict[str, Any]) -> bool:
    p = str(scene.get("purpose", "")).lower()
    return p in {"summary", "recap", "final_summary"} or any(o.get("type") == "summary_board" for o in scene.get("objects", []))


def _make_fallback_scene(concept: dict[str, Any], index: int) -> dict[str, Any]:
    """A safe semantic scene when a model returns too few scenes."""
    cid, name, explanation = concept["id"], concept["name"], concept.get("explanation", "")
    title = name[:52].upper()
    return {
        "id": f"teaching-{index:02d}-{cid}",
        "purpose": "teaching",
        "visual_archetype": "concept_card",
        "duration": 5.4,
        "narration": explanation or f"This means {name}.",
        "teaching_claim": explanation or f"{name}: this is a required part of the answer.",
        "teaches": [cid],
        "objects": [
            {"type": "text", "x": 90, "y": 72, "text": title, "size": 38, "bold": True, "start": 0.1, "duration": 0.75},
            {"type": "round_rect", "x": 120, "y": 190, "x2": 1120, "y2": 450, "start": 0.9, "duration": 0.8},
            {"type": "text", "x": 170, "y": 255, "text": explanation[:180] or f"{name}.", "size": 31, "start": 1.9, "duration": 1.2},
            {"type": "icon", "x": 1010, "y": 510, "scale": 0.72, "icon": "concept", "semantic_role": "teaching_evidence", "start": 3.35, "duration": 0.75},
        ],
    }


def bind_visual_story(project: dict[str, Any], answer_ir: dict[str, Any], teaching_plan: dict[str, Any] | None = None) -> dict[str, Any]:
    """Bind concepts to scenes by stable IDs, never by semantic token overlap."""
    out = deepcopy(project)
    contract = normalize_contract(answer_ir)
    concepts = contract.get("concepts", [])
    by_id = {c["id"]: c for c in concepts}
    beats = (teaching_plan or build_teaching_contract(contract)).get("beats", [])
    beat_by_id = {cid: beat for beat in beats for cid in beat.get("concept_ids", [])}

    teaching_scenes = [s for s in out.get("scenes", []) if not _is_summary(s)]
    used_ids: set[str] = set()
    # First honor explicit model-authored teaches IDs. Unknown IDs are ignored.
    for scene in teaching_scenes:
        explicit = [cid for cid in scene.get("teaches", []) if cid in by_id]
        if explicit:
            scene["teaches"] = list(dict.fromkeys(explicit))
            used_ids.update(explicit)

    # Semantic fallback: choose a scene by teaching mode/purpose before using
    # order. This is intentionally a small closed vocabulary, not token overlap.
    purpose_map = {
        "DEFINITION": {"definition", "intro", "explain", "hook", "question"},
        "MECHANISM": {"mechanism", "step", "step_1", "step_2", "step_3", "process", "explain", "definition", "retrieve", "augment", "generate", "tokens", "context", "predict"},
        "COMPONENT": {"definition", "mechanism", "step", "explain"},
        "RELATIONSHIP": {"comparison", "compare", "interpretation", "mechanism", "result"},
        "CALCULATION": {"formula", "calculation", "example", "demonstration", "mechanism"},
        "EXAMPLE": {"example", "demonstration", "application"},
        "COMPARISON": {"comparison", "compare", "interpretation"},
        "MISCONCEPTION": {"interpretation", "comparison", "mistake", "contrast"},
        "INTERPRETATION": {"interpretation", "result", "takeaway"},
        "MENTAL_MODEL": {"takeaway", "mental-model", "mental_model", "result"},
    }
    free_scenes = [s for s in teaching_scenes if not s.get("teaches")]
    for c in [c for c in concepts if c["id"] not in used_ids]:
        cid = c["id"]
        ctype = str(c.get("type") or "DEFINITION").upper()
        preferred = purpose_map.get(ctype, set())
        candidates = [s for s in free_scenes if str(s.get("purpose", "")).lower() in preferred]
        if candidates:
            scene = candidates[0]
            free_scenes.remove(scene)
        else:
            # Prefer an already-bound scene whose visual purpose matches the beat.
            # This is the deliberate 1:N path: several related concepts can share
            # one strong explanatory diagram.
            candidates = [s for s in teaching_scenes if str(s.get("purpose", "")).lower() in preferred]
            if candidates:
                scene = candidates[0]
                if scene in free_scenes:
                    free_scenes.remove(scene)
            elif free_scenes:
                scene = free_scenes.pop(0)
            else:
                scene = None
            if scene is None:
                scene = _make_fallback_scene(c, len(out.get("scenes", [])) + 1)
                out.setdefault("scenes", []).insert(max(0, len(out.get("scenes", [])) - 1), scene)
                teaching_scenes.append(scene)
        scene.setdefault("teaches", []).append(cid)
        scene["teaches"] = list(dict.fromkeys(scene["teaches"]))
        used_ids.add(cid)

    # Teaching content is authoritative: bind the exact concept explanation to
    # its scene. The visual director may elaborate, but cannot silently replace it.
    for scene in teaching_scenes:
        ids = [cid for cid in scene.get("teaches", []) if cid in by_id]
        if not ids:
            continue
        claims = []
        for cid in ids:
            c = by_id[cid]
            exp = str(c.get("explanation") or "").strip()
            if exp:
                claims.append(f"{c['name']}: {exp}")
        if claims:
            scene["teaching_claim"] = " ".join(claims)
            # Preserve a richer model narration only when it contains the
            # authoritative claim; otherwise use the contract explanation.
            narration = str(scene.get("narration", "")).strip()
            if not narration or not all(str(by_id[cid].get("name", "")).lower() in (narration + " ").lower() or str(by_id[cid].get("explanation", "")).lower()[:28] in narration.lower() for cid in ids):
                scene["narration"] = " ".join(str(by_id[cid].get("explanation") or by_id[cid]["name"]) for cid in ids)
        scene["teaching_evidence"] = [
            {"concept_id": cid, "evidence_requirements": by_id[cid].get("evidence_requirements", {})}
            for cid in ids
        ]
        scene["teaching_beat_ids"] = [beat_by_id[cid]["beat_id"] for cid in ids if cid in beat_by_id]

    out.setdefault("meta", {})["answer_ir"] = contract
    out["meta"]["teaching_plan"] = teaching_plan or build_teaching_contract(contract)
    out["meta"]["teaching_contract_version"] = "2.0"
    out["meta"]["concept_count"] = len(concepts)
    return out


def build_summary_cards(answer_ir: dict[str, Any]) -> list[dict[str, Any]]:
    """Create one concise visual-memory card per locked concept.

    The explanation remains in narration/AnswerIR. The recap intentionally
    carries a short phrase and a semantic icon instead of repeating prose.
    """
    import re
    from .presentation import _icons_for, _phrase, _compact_name
    cards = []
    for c in normalize_contract(answer_ir).get("concepts", []):
        name=_compact_name(c["name"], 6, 44)
        explanation=str(c.get("explanation") or name)
        icons=_icons_for(name, explanation, 1)
        cards.append({
            "concept_id": c["id"],
            "title": str(c["name"]).strip()[:80].upper(),
            "phrase": _phrase(explanation, name).upper(),
            # Keep support tiny; the full explanation is narration.
            "support": " ".join(explanation.split()[:7]).rstrip(".,")[:52],
            "takeaway": explanation[:180],
            "icon": icons[0] if icons else "rule",
        })
    return cards


def validate_binding(project: dict[str, Any], answer_ir: dict[str, Any]) -> dict[str, Any]:
    contract = normalize_contract(answer_ir)
    required = [c["id"] for c in contract.get("concepts", [])]
    seen = []
    scene_map = {}
    for s in project.get("scenes", []):
        if _is_summary(s):
            continue
        for cid in s.get("teaches", []) or []:
            if cid in required:
                seen.append(cid); scene_map.setdefault(cid, []).append(s.get("id"))
    missing = [cid for cid in required if cid not in seen]
    duplicates = [cid for cid in required if seen.count(cid) > 1]
    summary_cards = []
    for s in project.get("scenes", []):
        for o in s.get("objects", []):
            if o.get("type") == "summary_board":
                summary_cards.extend(o.get("cards", []) or [])
    summary_ids = [c.get("concept_id") for c in summary_cards]
    return {
        "ok": not missing and summary_ids == required,
        "required_concepts": required,
        "missing_concepts": missing,
        "duplicate_bindings": sorted(set(duplicates)),
        "scene_map": scene_map,
        "summary_ids": summary_ids,
        "errors": ([f"unbound concepts: {missing}"] if missing else []) + ([] if summary_ids == required else ["summary cards do not match locked concept IDs in order"]),
    }

import json
from pathlib import Path

ALLOWED_TYPES = {"text", "arrow", "line", "rect", "circle", "person", "money", "bank", "question", "chart", "equation", "group", "icon", "doodle_icon"}

def load_storyboard(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))

def validate_storyboard(doc):
    errors = []
    if not isinstance(doc, dict):
        return ["Storyboard must be a JSON object"]
    if not isinstance(doc.get("scenes"), list) or not doc["scenes"]:
        errors.append("scenes must be a non-empty list")
        return errors
    for i, scene in enumerate(doc["scenes"], 1):
        if not scene.get("narration"):
            errors.append(f"scene {i}: missing narration")
        if not isinstance(scene.get("objects", []), list):
            errors.append(f"scene {i}: objects must be a list")
        for j, obj in enumerate(scene.get("objects", []), 1):
            typ = obj.get("type")
            if typ not in ALLOWED_TYPES:
                errors.append(f"scene {i}, object {j}: unsupported type {typ!r}")
    return errors

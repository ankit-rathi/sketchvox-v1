"""Semantic visual-object resolution for SketchVox.

The teaching model is allowed to invent domain vocabulary (tree, sun, oxygen,
chlorophyll, gradient, token, etc.).  That vocabulary is semantic data, not a
closed renderer enum.  This module converts it into a small set of renderer
primitives while preserving the original semantic type for QA/provenance.

Policy:
* malformed objects still fail validation;
* unknown-but-safe semantic types never crash the renderer;
* known semantic aliases get a deterministic native doodle;
* everything else gets a readable labelled generic icon;
* the resolver never changes teaching content or concept bindings.
"""
from __future__ import annotations
from copy import deepcopy
import re
from typing import Any

SAFE_SEMANTIC = re.compile(r"^[A-Za-z][A-Za-z0-9_ .:/+\-]{0,80}$")

# Semantic name -> deterministic renderer glyph.  The map is intentionally
# small; adding an entry improves visual specificity without changing the
# teaching contract.
SEMANTIC_GLYPHS = {
    "tree": "tree", "plant": "tree", "leaf": "leaf", "sun": "sun",
    "sunlight": "sun", "water": "water", "oxygen": "oxygen",
    "carbon_dioxide": "carbon_dioxide", "carbon dioxide": "carbon_dioxide",
    "co2": "carbon_dioxide", "glucose": "glucose", "sugar": "glucose",
    "chlorophyll": "leaf", "dna": "dna", "cell": "cell", "atom": "atom",
    "molecule": "molecule", "energy": "energy", "force": "force",
    "gradient": "gradient", "loss": "loss", "token": "token",
    "query": "query", "document": "document", "retrieval": "database",
    "database": "database", "cpu": "cpu", "memory": "database",
    "attention": "attention", "neuron": "neuron", "brain": "brain",
    "probability": "probability", "prior": "probability", "posterior": "probability",
    "likelihood": "probability", "price": "trend", "demand": "trend",
    "supply": "trend", "inflation": "trend", "money": "money",
    "coin": "coin", "bank": "bank", "person": "person", "user": "person",
}

RENDER_NATIVE = {
    "person", "money", "coin", "bank", "wallet", "house", "calculator",
    "question", "lightbulb", "warning", "check", "cross", "magnifier", "book",
    "robot", "brain", "database", "server", "cloud", "gpu", "api", "cpu",
}


def _key(value: Any) -> str:
    return str(value or "").strip().lower().replace("-", "_")


def _label(value: Any) -> str:
    s = str(value or "").strip().replace("_", " ")
    return s[:34] if s else "concept"


def resolve_object(obj: dict[str, Any]) -> dict[str, Any]:
    out = deepcopy(obj)
    typ = out.get("type")
    if not isinstance(typ, str) or not typ.strip():
        return out
    key = _key(typ)

    # Existing renderer types remain untouched.
    from .schema import SUPPORTED_OBJECTS
    if key in SUPPORTED_OBJECTS:
        return out

    # A model can explicitly request semantic/doodle icons too.
    semantic = out.get("semantic_type") or out.get("concept") or typ
    semantic_key = _key(semantic)
    if not SAFE_SEMANTIC.match(str(semantic)):
        return out

    glyph = SEMANTIC_GLYPHS.get(semantic_key, "generic")
    out["semantic_type"] = str(semantic)
    out["render_type"] = glyph
    out["type"] = "icon"
    out.setdefault("icon", glyph)
    out.setdefault("label", _label(semantic))
    out.setdefault("semantic_role", "teaching_evidence")
    out.setdefault("asset_resolution", "native" if glyph in RENDER_NATIVE else "deterministic_generic")
    return out


def resolve_scene_graph(doc: dict[str, Any]) -> dict[str, Any]:
    out = deepcopy(doc)
    for scene in out.get("scenes", []) or []:
        if not isinstance(scene, dict):
            continue
        resolved = []
        for obj in scene.get("objects", []) or []:
            if isinstance(obj, dict):
                resolved.append(resolve_object(obj))
            else:
                resolved.append(obj)
        scene["objects"] = resolved
    out.setdefault("meta", {})["asset_resolution"] = {
        "version": "1.0",
        "policy": "open-semantic-vocabulary",
        "unknown_semantics": sum(
            1 for s in out.get("scenes", []) or [] for o in s.get("objects", []) or []
            if isinstance(o, dict) and o.get("semantic_type") and o.get("asset_resolution") == "deterministic_generic"
        ),
    }
    return out

"""Optional local/cloud audio helpers."""
from __future__ import annotations
import os, subprocess
from pathlib import Path

def ffprobe_duration(path):
    try:
        out=subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration','-of','default=nw=1:nk=1',str(path)],text=True).strip(); return float(out)
    except Exception: return None

def make_silence(path,duration):
    Path(path).parent.mkdir(parents=True,exist_ok=True)
    subprocess.run(['ffmpeg','-y','-f','lavfi','-i','anullsrc=channel_layout=mono:sample_rate=44100','-t',str(duration),'-c:a','aac',str(path)],check=True,capture_output=True); return str(path)

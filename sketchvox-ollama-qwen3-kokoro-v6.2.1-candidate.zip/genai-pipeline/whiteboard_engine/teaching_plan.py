"""Teaching-plan contract for SketchVox 4.4.

The teaching plan is deliberately renderer-independent. It records the mental
model, beats, misconceptions, examples, and visual relationships that a scene
composer must make visible.
"""
from __future__ import annotations
from typing import Any


def build_teaching_contract(topic: str, project: dict[str, Any]) -> dict[str, Any]:
    scenes=project.get("scenes",[])
    beats=[]
    for i,s in enumerate(scenes,1):
        narration=str(s.get("narration","")).strip()
        purpose=str(s.get("purpose", "explain")).strip()
        beats.append({
            "scene":i,"purpose":purpose,"narration":narration,
            "primary_question":str(s.get("design_intent", "")).strip(),
            "visual_archetype":s.get("visual_archetype"),
            "required_relationships":[o.get("relationship") for o in s.get("objects",[]) if o.get("relationship")],
        })
    return {
        "version":"4.4",
        "topic":topic,
        "mental_model":project.get("meta",{}).get("mental_model", "") or "Explain the mechanism before naming the jargon.",
        "concept_count":project.get("meta",{}).get("concept_count"),
        "beats":beats,
        "teaching_rules":[
            "one primary learning objective per beat",
            "show mechanisms and transformations, not only labels",
            "introduce prerequisites before dependent concepts",
            "use concrete examples when they reduce cognitive load",
            "visual presence must overlap narration timing",
            "final takeaway must be supported by the preceding visuals",
        ],
    }

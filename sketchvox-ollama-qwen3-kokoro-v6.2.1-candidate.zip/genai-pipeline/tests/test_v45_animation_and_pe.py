from whiteboard_engine.animation_engine import PRIMITIVES, track, choreograph_scene
from whiteboard_engine.deterministic_director import build_plan
from whiteboard_engine.design_system import apply_visual_design
from whiteboard_engine.repair_governor import is_blocking_issue, issue_score
from whiteboard_engine.scene_graph import object_bbox


def test_animation_primitive_registry_is_semantic():
    assert {"DRAW", "TRANSFORM", "COMPARE", "FLOW", "ZOOM"}.issubset(PRIMITIVES)
    t = track("transform", "obj-1", 1.2)
    assert t["action"] == "TRANSFORM"
    assert t["target"] == "obj-1"


def test_scene_gets_animation_contract_and_draw_order():
    scene = {"objects": [{"id": "a", "type": "text", "start": 0.1, "duration": 0.5}]}
    out = choreograph_scene(scene)
    assert out["animation"]["contract"] == "semantic_animation_v1"
    assert out["animation"]["draw_order"] == ["a"]


def test_pe_plan_is_mechanism_first_and_phrase_summary():
    doc = apply_visual_design(build_plan("Explain P/E ratio to a beginner investor"), "Explain P/E ratio to a beginner investor")
    assert doc["meta"]["style_pack"] == "finance_editorial"
    assert [s["id"] for s in doc["scenes"]][:5] == ["hook", "earnings", "formula", "compare", "mental_model"]
    board = doc["scenes"][-1]["objects"][0]
    assert board["type"] == "summary_board"
    assert all(card.get("phrase") for card in board["cards"])


def test_advisory_warnings_are_non_blocking_for_strict_gate():
    warning={"severity":"warning","code":"SEMANTIC_FLOW_WEAK"}
    assert is_blocking_issue(warning, True) is False
    assert issue_score({"issues":[warning]}) == (0, 0, 1)


def test_rendering_error_remains_blocking():
    error={"severity":"error","code":"TEXT_GRAPHIC_OVERLAP"}
    assert is_blocking_issue(error, True) is True


def test_new_doodle_primitives_have_safe_bboxes():
    assert object_bbox({"type":"token_strip","x":100,"y":100,"tokens":["A","B"]}).x2 > 100
    assert object_bbox({"type":"ratio","x":100,"y":100,"width":300}).x2 == 400
    assert object_bbox({"type":"speech_bubble","x":100,"y":100,"width":300,"height":120}).y2 > 220
    assert object_bbox({"type":"flow_node","x":100,"y":100,"x2":400,"y2":300}).y2 == 300

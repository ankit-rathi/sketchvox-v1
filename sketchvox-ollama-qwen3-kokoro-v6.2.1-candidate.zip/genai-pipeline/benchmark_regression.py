#!/usr/bin/env python3
"""Offline heterogeneous teaching/visual contract benchmark for SketchVox 5.4.

This is a cheap structural gate. It does NOT claim that Ollama/Qwen3 generated
these lessons successfully; the target-machine integration suite remains a
separate release gate.
"""
from __future__ import annotations
import json
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))

from whiteboard_engine.answer_ir import lock_answer_ir
from whiteboard_engine.hybrid_director import compile_story
from whiteboard_engine.scene_graph import normalize_project
from whiteboard_engine.teaching_planner import build_teaching_plan
from whiteboard_engine.teaching_integrity import evaluate_coverage

BENCHMARKS = [
    ("Photosynthesis", ["light energy", "carbon dioxide", "water", "glucose and oxygen"]),
    ("DNA replication", ["template strand", "new DNA", "two resulting molecules"]),
    ("Bayes' theorem", ["prior", "likelihood", "posterior"]),
    ("Supply and demand", ["demand", "supply", "market price"]),
    ("Opportunity cost", ["choice", "next best alternative"]),
    ("Gradient descent", ["loss", "gradient", "parameter update"]),
    ("Transformer attention", ["query", "key-value relevance", "weighted context"]),
    ("CPU instruction execution", ["fetch", "decode", "execute"]),
    ("Kalman filter", ["prediction", "measurement", "updated estimate"]),
    ("Inflation", ["price level", "purchasing power", "rate of change"]),
    ("P/E ratio", ["price", "earnings per share", "valuation ratio"]),
    ("Compound interest", ["principal", "interest on interest", "growth over time"]),
    ("Moving average", ["window", "average", "smoothing"]),
    ("RAG", ["retrieve evidence", "use context", "generate answer"]),
]


def _answer(topic, names):
    concepts=[{"name":n, "explanation":f"{n.capitalize()} is an essential part of understanding {topic}."} for n in names]
    return lock_answer_ir(topic, {
        "canonical_question": f"What is {topic}?",
        "one_sentence_answer": f"{topic} can be understood through its core components and how they connect.",
        "must_explain": names,
        "useful_example": f"Use a simple example of {topic}.",
        "must_not_confuse_with": [],
        "final_mental_model": f"Connect the components of {topic} into one system.",
        "concepts": concepts,
    })


def inspect(project):
    scenes=project.get("scenes",[])
    summary=[o for s in scenes for o in s.get("objects",[]) if o.get("type")=="summary_board"]
    cards=(summary[-1].get("cards",[]) if summary else [])
    teaching=[s for s in scenes if not any(o.get("type")=="summary_board" for o in s.get("objects",[]))]
    semantic=[o for s in teaching for o in s.get("objects",[]) if o.get("semantic_type")]
    return {
        "scenes":len(scenes),
        "teaching_scenes":len(teaching),
        "concept_count":project.get("meta",{}).get("concept_count"),
        "summary_cards":len(cards),
        "semantic_objects":len(semantic),
        "summary_ids":[c.get("concept_id") for c in cards],
    }


def main(out=None):
    reports=[]
    for topic,names in BENCHMARKS:
        answer=_answer(topic,names)
        plan=build_teaching_plan(answer)
        raw={"meta":{"title":topic},"scenes":[
            {"id":f"raw-{i+1}","purpose":"teaching","duration":5,
             "narration":c["explanation"],
             "objects":[{"type":"text","x":90,"y":80,"text":c["name"],"size":34}]}
            for i,c in enumerate(answer["concepts"])
        ]}
        project=normalize_project(compile_story(topic,raw,answer_ir=answer,teaching_plan=plan))
        gate=evaluate_coverage(topic,project,answer)
        m=inspect(project)
        expected_ids=[c["id"] for c in answer["concepts"]]
        ok=(gate["ok"] and m["concept_count"]==len(expected_ids) and m["summary_cards"]==len(expected_ids) and m["summary_ids"]==expected_ids)
        reports.append({"topic":topic,"ok":ok,"coverage_gate":gate,"metrics":m})
    result={"standard":"5.4-heterogeneous-offline-contract","ok":all(r["ok"] for r in reports),"benchmarks":reports}
    if out: Path(out).write_text(json.dumps(result,indent=2,ensure_ascii=False),encoding="utf-8")
    print(json.dumps(result,indent=2,ensure_ascii=False))
    return 0 if result["ok"] else 1

if __name__=="__main__": raise SystemExit(main(sys.argv[1] if len(sys.argv)>1 else None))

from pathlib import Path


def test_answer_architect_uses_compact_system_prompt():
    src = Path(__file__).parents[1] / "whiteboard_engine" / "storyboard.py"
    text = src.read_text(encoding="utf-8")
    assert "ANSWER_SYSTEM" in text
    assert "system=ANSWER_SYSTEM" in text
    assert "system=SYSTEM + \"\nYou are currently the Answer Architect" not in text


def test_visual_director_keeps_rich_system_prompt():
    src = Path(__file__).parents[1] / "whiteboard_engine" / "storyboard.py"
    text = src.read_text(encoding="utf-8")
    assert 'system=SYSTEM' in text

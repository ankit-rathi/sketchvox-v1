from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


def test_rendered_frame_qa_runs_and_writes_report(tmp_path):
    from whiteboard_engine.renderer_worldclass import render_worldclass

    project = {
        "meta": {"currency": "INR"},
        "scenes": [{
            "id": "qa-scene",
            "duration": 1.8,
            "narration": "A simple rendered frame QA test.",
            "clear_board": True,
            "purpose": "summary",
            "objects": [
                {"id": "title", "type": "text", "x": 120, "y": 120, "text": "Hello SketchVox", "size": 42, "start": 0.1, "duration": 1.1},
                {"id": "spark", "type": "spark", "x": 650, "y": 300, "scale": 0.7, "start": 0.9, "duration": 0.6},
                {"id": "summary", "type": "summary_board", "x": 0, "y": 0, "width": 1280, "height": 720, "title": "1 KEY TAKEAWAY", "subtitle": "QA", "cards": [{"title": "CHECK", "takeaway": "Rendered output is inspected."}], "start": 1.0, "duration": 0.7},
            ],
        }]
    }
    out = tmp_path / "qa.mp4"
    path, repaired, report = render_worldclass(
        project, out,
        {"qa_strict": True, "visual_qa": True, "visual_qa_repair": True,
         "visual_qa_passes": 2, "hand": True, "texture": False, "return_details": True}
    )
    assert Path(path).exists()
    assert report["ok"] is True
    assert Path(str(out).replace(".mp4", ".visual-qa.json")).exists()
    assert repaired["scenes"]


def test_modern_icon_types_are_supported():
    from whiteboard_engine.schema import validate_scene_graph
    icons = ["shield", "target", "trend", "stack", "cpu", "filter", "link", "calendar", "book", "spark"]
    doc = {"scenes": [{"duration": 2, "narration": "icons", "objects": [{"type": x} for x in icons]}]}
    assert not validate_scene_graph(doc)


def test_summary_board_reaches_full_render_and_stays_in_bounds(tmp_path):
    from PIL import Image
    from whiteboard_engine.renderer_worldclass import draw_vector_object, _summary_layout
    from whiteboard_engine.visual_qa import _summary_text_checks
    import cv2, numpy as np
    cards=[
        {"title":"STARTING BASE","takeaway":"Start with the original amount.","icon":"capital"},
        {"title":"RETURN ON RETURN","takeaway":"The next return uses the larger base.","icon":"year2"},
        {"title":"THE CURVE","takeaway":"Growing gains bend the path upward.","icon":"curve"},
        {"title":"THE MODEL","takeaway":"Principal, rate, frequency and time drive the result.","icon":"mental"},
    ]
    obj={"type":"summary_board","width":1280,"height":720,"title":"4 KEY TAKEAWAYS — COMPOUND INTEREST","subtitle":"What to remember","cards":cards,"duration":5,"reveal_seconds":6}
    base=Image.new("RGBA",(1280,720),(252,251,247,255))
    cfg={"ink":"#20242B","accent":"#4F46E5","accent2":"#F59E0B","positive":"#10B981","danger":"#EF4444","muted":"#64748B"}
    draw_vector_object(base,obj,1.0,cfg)
    arr=cv2.cvtColor(np.array(base.convert("RGB")),cv2.COLOR_RGB2BGR)
    scene={"objects":[obj]}
    assert not _summary_text_checks(arr,scene,1280,720,1,1)
    positions,w,h=_summary_layout(4,1280,720)
    assert positions[-1][0]+w < 1280 and positions[-1][1]+h < 720


def test_invalid_rgb_is_safe():
    from whiteboard_engine.renderer_worldclass import _rgb
    assert _rgb("No") == (38,38,38)
    assert _rgb("#0af") == (0,170,255)


def test_summary_board_is_not_auto_moved_by_safe_layout():
    from whiteboard_engine.layout import auto_layout_project
    project={"scenes":[{"duration":3,"narration":"summary","objects":[{"type":"summary_board","x":0,"y":0,"width":1280,"height":720,"cards":[]}]}]}
    out=auto_layout_project(project,1280,720)
    assert out["scenes"][0]["objects"][0]["x"] == 0


def test_money_label_is_rendered_once():
    from PIL import Image
    from whiteboard_engine.renderer_worldclass import draw_vector_object
    cfg={"ink":"#20242B","accent":"#4F46E5","positive":"#10B981","accent2":"#F59E0B","danger":"#EF4444","muted":"#64748B"}
    im=Image.new("RGBA",(500,300),(255,255,255,255))
    draw_vector_object(im,{"type":"money","x":100,"y":100,"scale":0.92,"label":"₹10,000","color":"#20242B"},1,cfg)
    # There should be one authoritative amount inside the note, not a second
    # generic label above it. A simple connected-component count in the upper
    # strip is enough to regress the exact duplicate-label bug.
    import numpy as np, cv2
    a=np.asarray(im.convert("RGB")); gray=cv2.cvtColor(a,cv2.COLOR_RGB2GRAY)
    dark=(gray<150).astype(np.uint8)
    upper=dark[80:130,80:300]
    assert upper.sum() < 1200


def test_sample_times_include_final_composition_for_every_scene():
    from whiteboard_engine.visual_qa import _sample_times
    project={"scenes":[{"duration":5,"objects":[{"type":"text","text":"A"}]},{"duration":7,"objects":[{"type":"text","text":"B"}]}]}
    samples=_sample_times(project,per_scene=4)
    assert len(samples)==8
    assert any(scene==1 and local>4.8 for scene,_,local in samples)
    assert any(scene==2 and local>6.8 for scene,_,local in samples)


def test_summary_icons_are_bounded_and_distinct():
    from whiteboard_engine.renderer_worldclass import _render_summary_full
    from whiteboard_engine.deterministic_director import moving_average_plan
    obj = moving_average_plan()["scenes"][-1]["objects"][0]
    layer = _render_summary_full(obj, {"ink":"#20242B","accent":"#4F46E5","accent2":"#F59E0B","positive":"#10B981","danger":"#EF4444","muted":"#64748B"})
    assert layer.size == (1280, 720)
    icons = [c.get("icon") for c in obj["cards"]]
    assert len(icons) == len(set(icons))


def test_summary_final_render_has_no_known_zone_failures(tmp_path):
    from whiteboard_engine.deterministic_director import compound_interest_plan
    from whiteboard_engine.renderer_worldclass import _render_worldclass_once
    from whiteboard_engine.visual_qa import inspect_rendered_video
    project = compound_interest_plan()
    out = tmp_path / "summary.mp4"
    cfg = {"width":1280,"height":720,"fps":10,"background":"#FCFBF7","ink":"#20242B","accent":"#4F46E5","accent2":"#F59E0B","positive":"#10B981","danger":"#EF4444","muted":"#64748B","hand":False,"texture":False}
    _render_worldclass_once({"meta":project["meta"],"scenes":[project["scenes"][-1]]}, str(out), cfg)
    report = inspect_rendered_video(out, {"meta":project["meta"],"scenes":[project["scenes"][-1]]}, 1280, 720, 10, False, 1)
    bad = {"SUMMARY_ICON_COPY_OVERLAP","SUMMARY_COPY_INCOMPLETE","SUMMARY_TEXT_CLIPPED","SUMMARY_OCR_MISMATCH"}
    assert not any(i["code"] in bad for i in report["issues"])

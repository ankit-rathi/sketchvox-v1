from whiteboard_engine.scene_graph import normalize_project, validate_v2, object_bbox
from whiteboard_engine.assets import font
from whiteboard_engine.layout import SAFE, auto_layout_scene

def _doc(objects):
    return {"meta": {}, "scenes": [{
        "id":"s1","purpose":"mechanism","duration":8,"narration":"Explain the idea.",
        "objects":objects
    }]}

def test_long_text_wraps_and_stays_inside_safe_canvas():
    text=("This is deliberately long teaching evidence that should wrap across "
          "multiple lines instead of running beyond the right edge of the board.")
    doc=normalize_project(_doc([{"type":"text","x":1180,"y":650,"text":text,"size":42}]))
    obj=doc["scenes"][0]["objects"][0]
    b=object_bbox(obj)
    assert b.x >= SAFE[0]
    assert b.y >= SAFE[1]
    assert b.x2 <= 1280-SAFE[2]
    assert b.y2 <= 720-SAFE[3]
    assert obj["layout_wrapped"] is True
    assert obj["max_width"] >= 80

def test_extreme_mixed_scene_is_always_safe():
    objs=[
        {"type":"text","x":-500,"y":-300,"text":"A very long headline that needs reflow","size":64,"bold":True},
        {"type":"text","x":1180,"y":680,"text":"Secondary explanatory copy with enough words to require wrapping.","size":34},
        {"type":"person","x":-100,"y":800},
        {"type":"circle","x":1350,"y":-100,"r":100},
        {"type":"arrow","x":-200,"y":400,"x2":1500,"y2":400},
        {"type":"chart","x":1000,"y":500,"width":600,"height":400},
        {"type":"pipeline","x":-100,"y":100,"items":["Input","Transformation","Output"],"box_width":300},
    ]
    doc=normalize_project(_doc(objs))
    assert validate_v2(doc)==[]
    assert all(
        (o.get("type") in {"group","space","summary_board"} or
         (lambda b: b is not None and b.x>=SAFE[0]-0.1 and b.y>=SAFE[1]-0.1 and b.x2<=1208.1 and b.y2<=658.1)(object_bbox(o)))
        for o in doc["scenes"][0]["objects"]
    )

def test_bundled_doodle_font_is_used_when_present():
    f=font(32,False)
    path=getattr(f,"path", "")
    assert "ComicNeue" in str(path) or "NotoSans" in str(path) or path

def test_layout_is_deterministic():
    scene={"duration":6,"objects":[
        {"type":"text","x":1150,"y":620,"text":"Long explanatory phrase","size":44},
        {"type":"brain","x":1100,"y":100,"scale":1.5},
        {"type":"text","x":100,"y":100,"text":"Headline","size":50,"bold":True},
    ]}
    a=auto_layout_scene(scene)
    b=auto_layout_scene(scene)
    assert a==b

"""SketchVox v4.4 visual design system and scene compiler.

This module sits between semantic teaching plans and the renderer. It does not
invent facts. It assigns a coherent visual language, semantic jobs, typography
roles, hierarchy, motion intent, and camera choreography to authored objects.
The renderer remains deterministic and all fields are optional/backward compatible.
"""
from __future__ import annotations
from copy import deepcopy
from typing import Any
from .animation_engine import choreograph_scene

STYLE_PACKS = {
    "finance_editorial": {
        "label": "Finance Editorial",
        "primary": "#1D4ED8", "secondary": "#059669", "warm": "#D97706",
        "display_font": "display", "body_font": "handwriting", "technical_font": "technical",
    },
    "ai_technical": {
        "label": "AI Technical",
        "primary": "#4F46E5", "secondary": "#0891B2", "warm": "#F59E0B",
        "display_font": "display", "body_font": "handwriting", "technical_font": "technical",
    },
    "data_analytical": {
        "label": "Data Analytical Notebook",
        "primary": "#2563EB", "secondary": "#0F766E", "warm": "#EA580C",
        "display_font": "display", "body_font": "handwriting", "technical_font": "technical",
    },
    "math_geometric": {
        "label": "Math Geometric Classroom",
        "primary": "#1D4ED8", "secondary": "#7C3AED", "warm": "#D97706",
        "display_font": "display", "body_font": "handwriting", "technical_font": "technical",
    },
    "modern_explainer": {
        "label": "Modern Explainer Whiteboard",
        "primary": "#4F46E5", "secondary": "#059669", "warm": "#D97706",
        "display_font": "display", "body_font": "handwriting", "technical_font": "technical",
    },
}

ARCHETYPES = {
    "hook": "hook",
    "problem": "cause_effect",
    "definition": "definition",
    "mechanism": "transformation",
    "transform": "transformation",
    "step_1": "pipeline",
    "step_2": "pipeline",
    "step_3": "pipeline",
    "money_flow": "accumulation",
    "calculation": "worked_example",
    "growth_or_risk": "graph_evolution",
    "equation": "worked_example",
    "graph": "graph_evolution",
    "comparison": "comparison",
    "takeaway": "takeaway",
    "summary": "summary",
    "mental-model": "system_map",
}


def infer_style_pack(topic: str, project: dict[str, Any] | None = None) -> str:
    p=(topic or "").lower()
    meta=(project or {}).get("meta", {}) if project else {}
    explicit=str(meta.get("style_pack", "")).strip().lower()
    if explicit in STYLE_PACKS: return explicit
    if any(k in p for k in ("stock","etf","invest","portfolio","interest","inflation","finance","bond","sip","drawdown")): return "finance_editorial"
    if any(k in p for k in ("rag","llm","chatgpt","transformer","embedding","neural network","machine learning","ai","attention")): return "ai_technical"
    if any(k in p for k in ("data","sql","dataset","regression","moving average","chart","statistics","csv","api")): return "data_analytical"
    if any(k in p for k in ("equation","theorem","probability","calculus","algebra","math")): return "math_geometric"
    return "modern_explainer"


def _role_for_object(obj: dict[str, Any], scene: dict[str, Any]) -> tuple[str,str,str]:
    typ=str(obj.get("type", ""))
    purpose=str(scene.get("purpose", "")).lower()
    text=str(obj.get("text", obj.get("value", ""))).strip()
    if typ=="summary_board": return "summary_surface", "editorial", "reveal"
    if typ in {"text","equation","number"}:
        if obj.get("semantic_role") and obj.get("font_role"):
            return str(obj["semantic_role"]), str(obj["font_role"]), str(obj.get("motion","write"))
        upper=text.upper()
        if any(k in upper for k in ("THE MENTAL MODEL","THE MECHANISM","WHY THE","STEP ","YEAR ","COMPOUND INTEREST")) or purpose in {"hook","title"}:
            return "headline", "display", "write"
        if typ in {"equation","number"} or any(ch in text for ch in "=÷×^%₹$€£"):
            return "technical_value", "technical", "write"
        if obj.get("underline") or obj.get("emphasis"):
            return "emphasis", "handwriting", "highlight"
        return "annotation", "handwriting", "write"
    if typ in {"arrow","line"}: return "relationship", "handwriting", "connect"
    if typ in {"chart","line_chart","bar_chart","pie_chart","trend"}: return "evidence_visual", "technical", "grow"
    if typ in {"highlight"}: return "attention_cue", "handwriting", "highlight"
    if typ in {"round_rect","rect"}: return "container", "display", "draw"
    if typ in {"person","money","coin","bank","wallet","house","calculator","question","lightbulb","warning","check","cross","magnifier","book","robot","brain","database","server","cloud","gpu","api","document","lock","folder","spark","shield","target","stack","cpu","filter","link","calendar"}:
        return "semantic_icon", "handwriting", "draw"
    if typ in {"pipeline","timeline","table","group"}: return "structure", "display", "build"
    return "supporting_visual", "handwriting", "draw"


def _scene_archetype(scene: dict[str, Any]) -> str:
    p=str(scene.get("purpose", "")).lower()
    if p in ARCHETYPES: return ARCHETYPES[p]
    types={str(o.get("type")) for o in scene.get("objects", [])}
    if "summary_board" in types: return "summary"
    if "chart" in types or "trend" in types: return "graph_evolution"
    if "arrow" in types and len(types)>=3: return "transformation"
    if "round_rect" in types and len(types)>=3: return "system_map"
    return "editorial_explainer"


def _assign_camera(scene: dict[str, Any], scene_index: int = 1) -> None:
    if scene.get("camera", {}).get("enabled") is True: return
    objects=scene.get("objects", [])
    if not objects: return
    # Camera is a premium motion layer. Keep it to roughly every third beat so
    # long videos remain practical to render while still gaining focal movement.
    if scene_index % 3 != 1 and str(scene.get("purpose", "")).lower() not in {"hook", "graph", "growth_or_risk"}:
        scene.setdefault("camera", {})["enabled"] = False
        return
    focus=next((o for o in objects if o.get("semantic_role") in {"headline","technical_value","evidence_visual"}), objects[0])
    fid=focus.get("id")
    if not fid:
        scene.setdefault("camera", {})["enabled"] = False
        return
    # Subtle, deterministic camera movement only. It is intentionally disabled
    # for dense summary boards where readability is more important than motion.
    if any(o.get("type")=="summary_board" for o in objects):
        scene.setdefault("camera", {})["enabled"]=False
        return
    scene["camera"]={"enabled":True,"start_zoom":1.0,"end_zoom":1.025,"target":fid,"pan_x":0,"pan_y":0}



def _fit_text_inside_containers(scene: dict[str, Any]) -> None:
    containers=[o for o in scene.get("objects",[]) if o.get("type") in {"round_rect","rect"}]
    for obj in scene.get("objects",[]):
        if obj.get("type") not in {"text","equation","number"}:
            if obj.get("type") in {"round_rect","rect"}: obj.setdefault("hand_follow", False)
            continue
        x=float(obj.get("x",0)); y=float(obj.get("y",0)); text=str(obj.get("text",obj.get("value","")))
        size=float(obj.get("size",46)); scale=float(obj.get("scale",1))
        parent=None
        for c in containers:
            cx=float(c.get("x",0)); cy=float(c.get("y",0)); cx2=float(c.get("x2",cx+200)); cy2=float(c.get("y2",cy+100))
            if cx+12 <= x <= cx2-12 and cy+12 <= y <= cy2-12:
                if parent is None or (cx2-cx)*(cy2-cy) < parent[0]: parent=((cx2-cx)*(cy2-cy),c)
        if parent:
            c=parent[1]; pad=28.0; avail=max(80.0,float(c.get("x2",0))-float(c.get("x",0))-2*pad)
            est=max(20.0,len(text)*size*0.52*scale)
            if est>avail:
                size=max(20.0,size*(avail/est)*0.90)
                obj["size"]=round(size,1)
            obj["parent"]=c.get("id"); obj["composition"]="parent_child"

def apply_visual_design(project: dict[str, Any], topic: str = "") -> dict[str, Any]:
    out=deepcopy(project)
    pack_name=infer_style_pack(topic,out)
    pack=STYLE_PACKS[pack_name]
    meta=out.setdefault("meta", {})
    meta["design_system"]="4.5"
    meta["style_pack"]=pack_name
    meta["style_pack_label"]=pack["label"]
    meta["design_contract"]="semantic_roles+visual_archetypes+semantic_animation+typography_roles+camera_targets+visual_utility"
    meta["font_policy"]="display_headlines+handwriting_annotations+technical_math"
    for si,scene in enumerate(out.get("scenes", []),1):
        scene["visual_archetype"]=_scene_archetype(scene)
        scene.setdefault("design_intent", "Explain the narrated idea with one primary visual relationship.")
        for obj in scene.get("objects", []):
            role,font_role,motion=_role_for_object(obj,scene)
            obj.setdefault("semantic_role", role)
            obj.setdefault("teaching_job", "support_narration" if role not in {"headline","technical_value","evidence_visual","relationship"} else role)
            obj.setdefault("font_role", font_role)
            obj.setdefault("motion", motion)
            obj.setdefault("attention", "primary" if role in {"headline","technical_value","evidence_visual"} else "secondary")
            obj.setdefault("importance", 1.0 if role in {"headline","technical_value","evidence_visual"} else 0.6)
            obj.setdefault("authored", True)
            obj.setdefault("generated_by", "director")
            obj.setdefault("repair_priority", "authored")
            if obj.get("type") in {"text","equation","number"}:
                if obj.get("font_role")=="display": obj.setdefault("letter_spacing", 0)
                obj.setdefault("line_role", "title" if role=="headline" else "body")
            # Style defaults are explicit but do not overwrite authored colors.
            if obj.get("type") in {"arrow","line","highlight"}:
                obj.setdefault("color", pack["primary"])
        _fit_text_inside_containers(scene)
        scene = choreograph_scene(scene)
        _assign_camera(scene, si)
    return out


def design_advisory(project: dict[str, Any], width=1280, height=720) -> dict[str, Any]:
    """Non-blocking design QA. It answers 'does this look intentional?'"""
    issues=[]; utility=[]
    for si,scene in enumerate(project.get("scenes", []),1):
        objs=scene.get("objects",[])
        meaningful=[o for o in objs if o.get("type") not in {"space"}]
        if len(meaningful)>8:
            issues.append({"severity":"advisory","code":"SCENE_DENSITY_HIGH","scene":si,"message":"More than eight meaningful objects; consider decomposing the beat."})
        if len(meaningful)<2 and str(scene.get("purpose","")) not in {"summary","recap"}:
            issues.append({"severity":"advisory","code":"SCENE_DENSITY_LOW","scene":si,"message":"Scene may need a stronger visual idea or a deliberate pause."})
        for o in meaningful:
            role=o.get("semantic_role")
            if not role:
                issues.append({"severity":"advisory","code":"MISSING_SEMANTIC_ROLE","scene":si,"object_id":o.get("id"),"message":"Visual element has no semantic role."})
            if o.get("type") in {"arrow","line"} and not o.get("relationship") and not o.get("semantic_role"):
                issues.append({"severity":"advisory","code":"ORPHAN_RELATIONSHIP","scene":si,"object_id":o.get("id"),"message":"Connector lacks an explicit relationship."})
        utility.append({"scene":si,"meaningful_objects":len(meaningful),"visual_archetype":scene.get("visual_archetype"),"design_intent":scene.get("design_intent")})
    # Consecutive grammar repetition is a design smell, not a render failure.
    archetypes=[str(sc.get("visual_archetype","")) for sc in project.get("scenes",[]) if str(sc.get("purpose","")).lower() not in {"summary","recap"}]
    run=1
    for i in range(1,len(archetypes)):
        if archetypes[i] and archetypes[i]==archetypes[i-1]: run+=1
        else: run=1
        if run>=3:
            issues.append({"severity":"advisory","code":"VISUAL_GRAMMAR_REPETITION","scene":i+1,"message":"Three or more consecutive scenes use the same visual grammar; consider a deliberate grammar change."})
            break
    return {"ok":not any(i["severity"]=="error" for i in issues),"issues":issues,"scene_utility":utility,"contract":"advisory_design_qa"}

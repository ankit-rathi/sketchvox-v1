"""External asset provenance and deterministic suitability policy."""
from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Any
@dataclass(frozen=True)
class AssetSource:
    name:str; repository:str; kind:str; license_status:str; license_url:str|None=None; intended_usage:str='reference'; notes:str=''
SOURCES={
 'react_doodle_icons':AssetSource('react-doodle-icons','https://github.com/svatsa159/react-doodle-icons','doodle-icons','repository-declared-MIT; underlying-artwork-provenance-review-required','https://github.com/svatsa159/react-doodle-icons/blob/master/LICENSE','doodle-icon-reference-or-reviewed-vendoring','Repository license and artwork provenance are separate checks.'),
 'doodle_font':AssetSource('Doodle','https://github.com/AaronRandall/Doodle','font','needs-verification',None,'font-reference-after-license-verification','Do not vendor until an explicit license is verified.'),
 'simple_icons':AssetSource('Simple Icons','https://github.com/simple-icons/simple-icons','brand-icons','project-CC0; individual-icon-license-and-trademark-review-required','https://github.com/simple-icons/simple-icons/blob/develop/DISCLAIMER.md','brand-identity-assets','Per-icon metadata and brand/trademark guidance remain relevant.'),
}
def source_manifest()->dict[str,Any]: return {k:asdict(v) for k,v in SOURCES.items()}
def suitability_score(asset:dict[str,Any],request:dict[str,Any])->float:
    tags=set(map(str.lower,asset.get('tags',[]))); wanted=set(map(str.lower,request.get('semantic_tags',[]))); score=.45*(len(tags&wanted)/max(1,len(wanted))); score+=.20 if asset.get('style')==request.get('style') else 0; score+=.20 if asset.get('animation_capabilities') else 0; score+=.15 if asset.get('license_eligible',False) else 0; return round(min(1.0,score),4)

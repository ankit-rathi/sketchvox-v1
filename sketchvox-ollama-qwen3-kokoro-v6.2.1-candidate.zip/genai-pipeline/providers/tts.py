from __future__ import annotations
from abc import ABC, abstractmethod

class TTSProvider(ABC):
    @abstractmethod
    def synthesize(self,text:str,out_path:str,language:str='english')->str: ...

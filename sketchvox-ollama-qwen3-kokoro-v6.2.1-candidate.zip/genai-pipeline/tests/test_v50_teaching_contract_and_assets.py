from whiteboard_engine.asset_catalog import SOURCES, suitability_score
from whiteboard_engine.deterministic_director import build_plan
from whiteboard_engine.teaching_ir import build_teaching_contract, validate_contract

def test_narration_and_display_copy_are_separate():
    doc=build_plan('Explain P/E ratio to a beginner investor')
    contract=build_teaching_contract('P/E ratio',doc)
    assert contract['separation']=='narration != display_copy != visual != semantic_claim'
    assert validate_contract(contract)==[]
    summary=doc['scenes'][-1]['objects'][0]
    assert summary['cards'][0]['phrase']=='P ÷ E'
    assert '₹100 price' in summary['cards'][1]['support']

def test_external_sources_are_explicitly_provenanced():
    assert 'react_doodle_icons' in SOURCES and 'doodle_font' in SOURCES
    assert SOURCES['doodle_font'].license_status=='needs-verification'

def test_asset_suitability_is_deterministic():
    asset={'tags':['finance','money'],'style':'modern_doodle','animation_capabilities':['draw'],'license_eligible':True}
    req={'semantic_tags':['finance','money'],'style':'modern_doodle'}
    assert suitability_score(asset,req)==1.0


def test_summary_duration_is_capped_when_fitting_long_budget():
    from whiteboard_engine.timing import fit_project_duration
    project={"scenes":[{"duration":5,"objects":[{"type":"text","start":0,"duration":1}]},{"duration":6,"objects":[{"type":"summary_board","start":0,"duration":5}]}]}
    out=fit_project_duration(project,60)
    assert out["scenes"][-1]["duration"] <= 10.0
    assert sum(float(s["duration"]) for s in out["scenes"]) >= 59.9

#!/usr/bin/env python3
"""Render a SketchVox project with actual scene voiceover timing.

Examples:
  python render_narrated.py --topic rag --provider local
  python render_narrated.py --topic compound --provider elevenlabs

For production voiceover set ELEVENLABS_API_KEY + ELEVENLABS_VOICE_ID,
or GEMINI_API_KEY when using --provider gemini. Kokoro is the default local neural voice.
"""
from __future__ import annotations
import argparse, json, sys
from pathlib import Path

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from whiteboard_engine.deterministic_director import build_plan
from whiteboard_engine.renderer_worldclass import render_worldclass
from whiteboard_engine.voiceover import build_scene_voiceover, retime_project_to_audio, concatenate_audio, mux_audio
from whiteboard_engine.qa import qa_report
from whiteboard_engine.scene_graph import normalize_project, validate_v2


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--topic',choices=['rag','compound','etf','moving-average'],default='rag')
    ap.add_argument('--provider',choices=['kokoro','local','espeak','elevenlabs','gemini'],default='kokoro')
    ap.add_argument('--out-dir',default='output/narrated')
    args=ap.parse_args()

    topic_map={
        'rag':'What is RAG in AI?',
        'compound':'What is compound interest?',
        'etf':'What is an ETF?',
        'moving-average':'What is a moving average?'
    }
    project=build_plan(topic_map[args.topic])
    out=Path(args.out_dir); out.mkdir(parents=True,exist_ok=True)
    voice_dir=out/'voice'
    paths,durations=build_scene_voiceover(project,voice_dir,provider=args.provider)
    synced=retime_project_to_audio(project,durations,tail_pad=0.0)
    normalized=normalize_project(synced)
    errors=validate_v2(normalized,1280,720)
    qa=qa_report(normalized,1280,720)
    if errors or not qa['ok']:
        raise SystemExit(f'QA failed before render: {errors or qa["issues"]}')
    project_path=out/f'{args.topic}-narrated-project.json'
    project_path.write_text(json.dumps(synced,indent=2,ensure_ascii=False),encoding='utf-8')
    silent=out/f'{args.topic}-narrated-silent.mp4'
    render_worldclass(synced,silent,{'qa_strict':True})
    audio=out/f'{args.topic}-voiceover.m4a'
    concatenate_audio(paths,audio,target_durations=[float(s['duration']) for s in synced['scenes']])
    final=out/f'sketchvox-{args.topic}-narrated.mp4'
    mux_audio(silent,audio,final)
    # Hard QA gate: final A/V duration must agree within one video frame.
    import subprocess
    vdur=float(subprocess.check_output(['ffprobe','-v','error','-show_entries','stream=duration','-select_streams','v:0','-of','default=nw=1:nk=1',str(final)],text=True).strip())
    adur=float(subprocess.check_output(['ffprobe','-v','error','-show_entries','stream=duration','-select_streams','a:0','-of','default=nw=1:nk=1',str(final)],text=True).strip())
    av_delta=abs(vdur-adur)
    if av_delta > (1/30 + 0.03):
        raise RuntimeError(f'A/V sync QA failed: video={vdur:.3f}s audio={adur:.3f}s delta={av_delta:.3f}s')
    report={
        'topic':args.topic,'provider':args.provider,
        'scene_audio_durations':durations,
        'video_duration':sum(float(s['duration']) for s in synced['scenes']),
        'audio_duration':sum(durations),'final_video_duration':vdur,'final_audio_duration':adur,'final_av_delta':av_delta,
        'qa_ok':qa['ok'],'qa_issues':qa['issues'],
        'project':str(project_path),'silent_video':str(silent),'audio':str(audio),'final':str(final)
    }
    (out/f'{args.topic}-narrated-report.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps(report,indent=2))

if __name__=='__main__': main()

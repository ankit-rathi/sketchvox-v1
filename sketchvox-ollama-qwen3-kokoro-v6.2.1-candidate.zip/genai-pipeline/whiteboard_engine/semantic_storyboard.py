"""Deterministic semantic storyboard compiler.

This is the guaranteed visual stage when a visual-director LLM call is slow or
unavailable.  It never invents lesson facts: all substantive teaching content
comes from the locked AnswerIR and TeachingPlan.
"""
from __future__ import annotations

from typing import Any

from .asset_resolver import resolve_scene_graph
from .content_guard import normalize_project_content
from .teaching_contract import build_summary_cards, bind_visual_story, normalize_contract
from .teaching_integrity import enforce_integrity
from .schema import validate_scene_graph


def _short(text: str, limit: int = 170) -> str:
    words = str(text or "").strip().split()
    if len(words) <= 28 and len(" ".join(words)) <= limit:
        return " ".join(words)
    out = ""
    for w in words:
        candidate = (out + " " + w).strip()
        if len(candidate) > limit:
            break
        out = candidate
    return out.rstrip(".,") + "."


def _display_topic(text: str) -> str:
    import re
    s=str(text or "").strip()
    s=re.sub(r"^\s*(explain|what is|what are|how does|how do|define)\s+", "", s, flags=re.I)
    s=re.sub(r"\s+to\s+(a|an)\s+class[- ]?\d+.*$", "", s, flags=re.I)
    s=re.sub(r"[?!.]+$", "", s).strip()
    return s[:58] or "THE CORE IDEA"


def _concept_icon(name: str) -> str:
    # Asset resolver accepts safe semantic names and supplies a deterministic
    # vector fallback when no reviewed native glyph exists.
    return name.strip()


def _base_scene(scene_id: str, purpose: str, duration: float, narration: str, teaches: list[str], objects: list[dict[str, Any]]) -> dict[str, Any]:
    return {
        "id": scene_id,
        "purpose": purpose,
        "duration": duration,
        "narration": narration,
        "teaches": teaches,
        "objects": objects,
        "clear_board": True,
        "transition": "wipe" if scene_id != "hook" else "none",
    }


def compile_semantic_storyboard(topic: str, answer_ir: dict[str, Any], teaching_plan: dict[str, Any], duration: float = 60, language: str = "english", diagnostics: dict[str, Any] | None = None) -> dict[str, Any]:
    ir = normalize_contract(answer_ir)
    concepts = ir.get("concepts", []) or []
    d = max(20.0, float(duration))
    # Reserve a readable recap. Remaining time is distributed across the
    # authoritative concept beats plus a compact hook/example/misconception.
    extra = 0
    if ir.get("useful_example"):
        extra += 1
    if ir.get("must_not_confuse_with"):
        extra += 1
    slots = 1 + len(concepts) + extra + 1
    per = max(3.2, (d - 9.0) / max(1, slots - 1))
    scenes: list[dict[str, Any]] = []

    scenes.append(_base_scene(
        "hook", "hook", max(3.2, min(5.0, per)),
        ir.get("canonical_question") or f"Let's understand {topic}.", [],
        [
            {"type": "question", "x": 150, "y": 275, "scale": 1.15, "semantic_role": "lesson_hook"},
            {"type": "text", "x": 310, "y": 240, "text": _display_topic(str(ir.get("canonical_question") or topic)), "size": 52, "bold": True, "semantic_role": "question", "max_width": 780},
        ],
    ))

    for i, c in enumerate(concepts, 1):
        cid = str(c.get("id"))
        name = str(c.get("name") or f"Concept {i}").strip()
        explanation = _short(c.get("explanation") or name)
        x_icon = 170
        scenes.append(_base_scene(
            f"concept-{i:02d}", "definition" if i == 1 else "mechanism", per,
            explanation,
            [cid],
            [
                {"type": "icon", "icon": _concept_icon(name), "semantic_role": "concept", "x": x_icon, "y": 300, "scale": 0.9},
                {"type": "text", "x": 320, "y": 190, "text": name[:52], "size": 42, "bold": True, "semantic_role": "concept_label"},
                {"type": "arrow", "x": 300, "y": 365, "x2": 1040, "y2": 365, "semantic_role": "explanation_flow"},
                {"type": "text", "x": 350, "y": 410, "text": explanation[:155], "size": 30, "semantic_role": "teaching_evidence"},
            ],
        ))

    example = ir.get("useful_example")
    if example:
        scenes.append(_base_scene(
            "example", "example", per,
            "Let's make the idea concrete. " + _short(example, 220), [],
            [
                {"type": "lightbulb", "x": 180, "y": 300, "scale": 0.9, "semantic_role": "example"},
                {"type": "text", "x": 330, "y": 220, "text": "A concrete example", "size": 42, "bold": True},
                {"type": "text", "x": 330, "y": 330, "text": _short(example, 190), "size": 30},
            ],
        ))

    distinctions = ir.get("must_not_confuse_with") or []
    if distinctions:
        contrast = ", ".join(str(x) for x in distinctions[:3])
        scenes.append(_base_scene(
            "distinction", "comparison", per,
            f"One important distinction: {contrast}.", [],
            [
                {"type": "warning", "x": 180, "y": 300, "scale": 0.9, "semantic_role": "misconception"},
                {"type": "text", "x": 330, "y": 220, "text": "Don't confuse it with", "size": 42, "bold": True},
                {"type": "cross", "x": 330, "y": 370, "scale": 0.65},
                {"type": "text", "x": 420, "y": 365, "text": contrast[:105], "size": 30},
            ],
        ))

    mental = _short(ir.get("final_mental_model") or ir.get("one_sentence_answer"), 220)
    scenes.append(_base_scene(
        "mental-model", "takeaway", max(4.0, per),
        "The mental model to keep is: " + mental,
        [],
        [
            {"type": "brain", "x": 180, "y": 300, "scale": 0.9, "semantic_role": "mental_model"},
            {"type": "text", "x": 340, "y": 225, "text": "Mental model", "size": 46, "bold": True},
            {"type": "text", "x": 340, "y": 335, "text": mental[:180], "size": 32},
        ],
    ))

    cards = build_summary_cards(ir)
    summary_duration = max(8.0, min(15.0, 3.0 + len(cards)))
    scenes.append({
        "id": "summary", "purpose": "summary", "duration": summary_duration,
        "narration": "Here are the key ideas from " + str(ir.get("topic") or topic) + ". " + " ".join(f"{c['name']}: {c.get('explanation','')}" for c in concepts),
        "clear_board": True, "transition": "wipe", "objects": [{
            "type": "summary_board", "x": 0, "y": 0, "width": 1280, "height": 720,
            "start": 0.1, "duration": summary_duration - 0.35,
            "title": f"{len(cards)} KEY TAKEAWAYS — {str(ir.get('topic') or topic).upper()}",
            "subtitle": "What to remember", "cards": cards,
            "reveal_seconds": max(3.5, 0.72 * len(cards) + 1.8),
        }],
    })

    doc = {
        "meta": {
            "title": topic, "language": language, "mode": "ollama_semantic_compiler",
            "director": "5.5.0-semantic-compiler", "model": "deterministic_from_locked_answer_ir",
            "answer_ir": ir, "teaching_plan": teaching_plan,
            "concept_count": len(cards), "summary_count": len(cards),
            "summary_contract": "one_final_summary_exactly_one_card_per_locked_concept_id",
            "generation": diagnostics or {}, "fallback": "semantic_compiler",
        },
        "scenes": scenes,
    }
    doc = bind_visual_story(doc, ir, teaching_plan)
    doc = enforce_integrity(topic, doc, ir)
    from .presentation import enforce_visual_first
    doc = enforce_visual_first(doc, topic)
    doc = normalize_project_content(resolve_scene_graph(doc), "INR")
    errors = validate_scene_graph(doc)
    if errors:
        raise ValueError("Semantic storyboard validation failed: " + "; ".join(errors))
    if not doc.get("meta", {}).get("coverage_gate", {}).get("ok"):
        raise ValueError("Semantic storyboard teaching gate failed: " + "; ".join(doc["meta"]["coverage_gate"]["errors"]))
    return doc

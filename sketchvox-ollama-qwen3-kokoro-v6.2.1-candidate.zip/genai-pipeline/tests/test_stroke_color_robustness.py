from PIL import Image

from whiteboard_engine.renderer_worldclass import draw_vector_object


def _cfg():
    return {"ink": "#202020", "accent": "#4F46E5"}


def test_color_string_in_stroke_does_not_crash_renderer():
    frame = Image.new("RGB", (320, 240), "#FFFDF7")
    obj = {"type": "line", "x": 40, "y": 120, "x2": 280, "y2": 120, "stroke": "#000000"}
    endpoint = draw_vector_object(frame, obj, 1.0, _cfg())
    assert endpoint == (280.0, 120.0)


def test_non_numeric_stroke_falls_back_to_default():
    frame = Image.new("RGB", (320, 240), "#FFFDF7")
    obj = {"type": "line", "x": 40, "y": 120, "x2": 280, "y2": 120, "stroke": "not-a-number"}
    endpoint = draw_vector_object(frame, obj, 1.0, _cfg())
    assert endpoint == (280.0, 120.0)

#!/usr/bin/env python3
"""SketchVox 4.3 closed-loop QA repair for an existing storyboard.

This is the deterministic build-test-fix entry point:
    render -> raster inspect -> diagnose -> repair -> render -> ...
No LLM regeneration is performed. The input storyboard remains the source of truth.
"""
from __future__ import annotations
import argparse, json, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from whiteboard_engine.renderer_worldclass import render_worldclass
from whiteboard_engine.scene_graph import normalize_project


def main(argv=None):
    ap = argparse.ArgumentParser(description="Render, validate and deterministically repair an existing SketchVox storyboard")
    ap.add_argument("storyboard", help="Existing storyboard JSON")
    ap.add_argument("--passes", type=int, default=12, help="Maximum closed-loop passes")
    ap.add_argument("--out-dir", default=None, help="Output directory (default: alongside storyboard)")
    ap.add_argument("--fps", type=int, default=30)
    ap.add_argument("--no-hand", action="store_true")
    ap.add_argument("--no-texture", action="store_true")
    args = ap.parse_args(argv)

    src = Path(args.storyboard).resolve()
    project = normalize_project(json.loads(src.read_text(encoding="utf-8")))
    out = Path(args.out_dir).resolve() if args.out_dir else src.parent
    out.mkdir(parents=True, exist_ok=True)

    stem = src.stem
    video = out / f"{stem}.repaired.mp4"

    print(f"[v4.3 QA LOOP] input={src}")
    print(f"[v4.3 QA LOOP] budget={max(1,args.passes)} passes")
    path, repaired, report = render_worldclass(
        project, video,
        {
            "width": 1280, "height": 720, "fps": args.fps,
            "hand": not args.no_hand, "texture": not args.no_texture,
            "qa_strict": True, "qa_standard_strict": True,
            "visual_qa": True, "visual_qa_repair": True,
            "visual_qa_passes": max(1, args.passes),
            "visual_qa_samples": 4, "return_details": True,
        },
    )

    repaired_storyboard = out / f"{stem}.repaired-storyboard.json"
    log = out / f"{stem}.qa-repair-log.json"
    visual = out / f"{stem}.visual-qa.json"

    repaired_storyboard.write_text(json.dumps(repaired, indent=2, ensure_ascii=False), encoding="utf-8")
    log_payload = {
        "version": "4.3.0",
        "input": str(src),
        "video": str(video),
        "passes_requested": max(1,args.passes),
        "passes_attempted": report.get("passes_attempted"),
        "pass_history": report.get("pass_history", []),
        "issue_signatures": report.get("issue_signatures", []),
        "repair_actions": report.get("repair_actions", []),
        "advisory_warnings": report.get("advisory_warnings", []),
        "ok": report.get("ok", False),
    }
    log.write_text(json.dumps(log_payload, indent=2, ensure_ascii=False), encoding="utf-8")
    visual.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")

    print(json.dumps({
        "ok": report.get("ok", False),
        "passes_attempted": report.get("passes_attempted"),
        "repairs": len(report.get("repair_actions", [])),
        "video": str(video),
        "storyboard": str(repaired_storyboard),
        "qa_log": str(log),
        "visual_qa": str(visual),
    }, indent=2))

    return 0 if report.get("ok", False) else 2


if __name__ == "__main__":
    raise SystemExit(main())

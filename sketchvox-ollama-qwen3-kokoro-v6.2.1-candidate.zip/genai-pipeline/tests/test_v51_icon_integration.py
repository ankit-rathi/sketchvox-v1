from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


def test_scene_graph_accepts_icon_object():
    from whiteboard_engine.schema import validate_scene_graph
    doc = {
        "scenes": [{
            "duration": 2,
            "narration": "BMR is the energy your body needs at rest.",
            "objects": [{"type": "icon", "icon": "brain", "semantic_role": "resting_body"}],
        }]
    }
    assert validate_scene_graph(doc) == []


def test_legacy_dsl_accepts_icon_object():
    from whiteboard_engine.dsl import validate_storyboard
    doc = {
        "scenes": [{
            "narration": "An icon represents the concept.",
            "objects": [{"type": "icon", "icon": "lightbulb"}],
        }]
    }
    assert validate_storyboard(doc) == []


def test_icon_renders_with_deterministic_fallback():
    from PIL import Image
    import numpy as np
    from whiteboard_engine.renderer_worldclass import draw_vector_object
    cfg={"ink":"#20242B","accent":"#4F46E5","positive":"#10B981","accent2":"#F59E0B","danger":"#EF4444","muted":"#64748B"}
    im=Image.new("RGBA",(500,300),(255,255,255,255))
    draw_vector_object(im,{"type":"icon","icon":"brain","x":180,"y":130,"scale":1.0},1,cfg)
    arr=np.asarray(im.convert("RGB"))
    assert int(np.sum(np.any(arr < 220, axis=2))) > 50


def test_icon_unknown_name_is_safe():
    from PIL import Image
    from whiteboard_engine.renderer_worldclass import draw_vector_object
    cfg={"ink":"#20242B","accent":"#4F46E5","positive":"#10B981","accent2":"#F59E0B","danger":"#EF4444","muted":"#64748B"}
    im=Image.new("RGBA",(500,300),(255,255,255,255))
    draw_vector_object(im,{"type":"icon","icon":"not-a-real-icon","x":180,"y":130},1,cfg)


def test_bmr_like_storyboard_with_icons_passes_validation():
    from whiteboard_engine.schema import validate_scene_graph
    doc={"meta":{"answer_contract":{"one_sentence_answer":"BMR is the energy the body needs at rest."}},"scenes":[
        {"duration":4,"narration":"BMR is the energy your body needs at rest.","objects":[{"type":"icon","icon":"brain"},{"type":"text","text":"ENERGY AT REST"}]},
        {"duration":5,"narration":"That energy supports vital functions such as breathing and circulation.","objects":[{"type":"icon","icon":"heart"},{"type":"text","text":"VITAL FUNCTIONS"}]},
        {"duration":4,"narration":"So think of BMR as your baseline energy budget.","objects":[{"type":"icon","icon":"result"},{"type":"text","text":"BASELINE ENERGY BUDGET"}]},
    ]}
    assert validate_scene_graph(doc) == []


def test_unknown_topic_hybrid_compiler_preserves_semantic_icon_and_narration():
    from whiteboard_engine.hybrid_director import compile_story
    raw={
      "meta": {
        "title":"What is BMR?",
        "concepts":[
          {"title":"ENERGY AT REST","takeaway":"BMR measures the energy your body needs while resting."},
          {"title":"VITAL FUNCTIONS","takeaway":"That energy supports vital functions while you rest."}
        ],
        "answer_contract":{"one_sentence_answer":"BMR is the energy your body needs at rest to keep vital functions running."}
      },
      "scenes":[
        {"purpose":"definition","narration":"BMR is the energy your body needs at rest to keep vital functions running.","teaching_claim":"BMR means energy used at rest.","objects":[{"type":"icon","icon":"brain"}]},
        {"purpose":"example","narration":"For example, your body spends energy keeping vital functions running even before exercise.","teaching_claim":"For example, resting energy supports vital functions.","objects":[{"type":"icon","icon":"heart"}]}
      ]
    }
    out=compile_story("What is BMR (Basal Metabolic Rate)?",raw)
    non_summary=[s for s in out["scenes"] if s.get("purpose")!="summary"]
    assert any("BMR is the energy your body needs" in s.get("narration","") for s in non_summary)
    assert any(o.get("type")=="icon" and o.get("icon")=="brain" for s in non_summary for o in s.get("objects",[]))


def test_compiled_semantic_icons_use_compiler_owned_safe_geometry():
    from whiteboard_engine.hybrid_director import compile_story
    raw={"meta":{"title":"What is BMR?","concepts":[{"title":"ENERGY AT REST","takeaway":"BMR measures energy at rest."},{"title":"VITAL FUNCTIONS","takeaway":"It supports vital functions."}],"answer_contract":{"one_sentence_answer":"BMR is the energy your body needs at rest."}},"scenes":[{"narration":"BMR is the energy your body needs at rest.","objects":[{"type":"icon","icon":"brain","x":10,"y":10}]}]}
    out=compile_story("What is BMR?",raw)
    icons=[o for s in out["scenes"] for o in s.get("objects",[]) if o.get("type")=="icon"]
    assert icons and 0 <= icons[0]["x"] <= 1280 and 0 <= icons[0]["y"] <= 720


def test_summary_missing_icons_are_deterministically_unique():
    from whiteboard_engine.storyboard import _repair_summary_contract
    doc={"meta":{"title":"What is BMR?","concepts":[{"title":"ENERGY AT REST","takeaway":"BMR measures energy at rest."},{"title":"VITAL FUNCTIONS","takeaway":"It supports vital functions."}]},"scenes":[{"purpose":"definition","duration":4,"narration":"BMR is energy at rest."}]}
    out=_repair_summary_contract(doc,"INR")
    icons=[c["icon"] for c in out["scenes"][-1]["objects"][0]["cards"]]
    assert len(icons)==2 and len(set(icons))==2

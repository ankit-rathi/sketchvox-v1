import json
from config import MODEL_NAME
from tools.utils import client, _save_to_run_folder

SYSTEM = """You are the Teaching Director for a reusable educational whiteboard animation engine.
Return ONLY valid JSON. The visual output must use simple deterministic drawing primitives rather than generated images.
Prioritize clarity, factual correctness, one idea per scene, and progressive drawing.
"""

SCHEMA = {
  "global_plan": {"title":"", "target_audience":"", "tone":"educational", "total_scenes":1},
  "scenes": [{
    "scene_number":1, "purpose":"hook", "narration":"", "duration":8,
    "objects":[{"type":"text","x":100,"y":100,"text":"", "size":48}],
    "emphasis":[]
  }]
}

def director_v2(user_instructions, research_material="", language="english"):
    prompt=f"""{SYSTEM}
Topic/instructions: {user_instructions}
Research/facts (use only what is supported): {research_material}
Language: {language}

Build a 30-90 second MVP unless the user explicitly asks for another duration. Use these object types only:
text, equation, arrow, line, rect, circle, person, money, bank, question, chart, group.
Coordinates are on a 1280x720 white canvas. Objects are drawn sequentially. Use chart values for numerical charts.
For finance/data/AI topics, prefer actual numbers/equations/charts over decorative art. Do not invent financial facts.

Return JSON matching this structure:
{json.dumps(SCHEMA)}
"""
    if not client:
        raise RuntimeError("No Gemini client configured")
    r=client.models.generate_content(model=MODEL_NAME, contents=prompt, config={"response_mime_type":"application/json"})
    data=json.loads(r.text)
    _save_to_run_folder(json.dumps(data,indent=2,ensure_ascii=False),"whiteboard_storyboard.json")
    return data

from whiteboard_engine.teaching_integrity import build_topic_understanding, evaluate_coverage


def _doc():
    return {
      "meta": {"answer_contract": {
        "canonical_question": "What is BMR?",
        "one_sentence_answer": "BMR is the energy your body needs at rest to keep vital functions running.",
        "must_explain": ["energy at rest", "vital functions"],
        "useful_example": "Compare resting energy with total daily activity.",
        "final_mental_model": "BMR is the body's baseline energy budget."
      }},
      "scenes": [
        {"purpose":"definition","narration":"BMR is the energy your body needs at rest to keep vital functions running.","teaching_claim":"It covers energy for breathing, circulation and other basic functions.","objects":[{"type":"text","text":"BMR = baseline energy at rest"}]},
        {"purpose":"example","narration":"For example, even before exercise, your body spends energy keeping organs working.","objects":[{"type":"text","text":"resting energy → vital functions"}]},
        {"purpose":"summary","objects":[{"type":"summary_board","cards":[{"title":"BASELINE ENERGY","support":"Energy needed at rest."},{"title":"VITAL FUNCTIONS","support":"Supports basic body functions."}]}]}
      ]}


def test_specific_answer_passes_gate():
    doc=_doc(); u=build_topic_understanding("What is BMR (Basal Metabolic Rate)?",doc)
    result=evaluate_coverage("What is BMR (Basal Metabolic Rate)?",doc,u)
    assert result["ok"]


def test_generic_bmr_story_fails_gate():
    doc={"meta":{"answer_contract":{"one_sentence_answer":"BMR is a measure of resting energy.","must_explain":["resting energy","vital functions"]}},"scenes":[
      {"purpose":"definition","narration":"Something goes in, a transformation happens, and a result comes out.","objects":[{"type":"text","text":"THE MECHANISM"}]},
      {"purpose":"summary","objects":[{"type":"summary_board","cards":[{"title":"THE QUESTION","support":"Understand the mechanism."},{"title":"THE RESULT","support":"Then the jargon becomes easier."}]}]}]}
    u=build_topic_understanding("What is BMR (Basal Metabolic Rate)?",doc)
    result=evaluate_coverage("What is BMR (Basal Metabolic Rate)?",doc,u)
    assert not result["ok"]
    assert result["errors"]


def test_missing_answer_contract_is_hard_failure():
    doc={"meta":{},"scenes":[]}
    u=build_topic_understanding("What is RAG?",doc)
    result=evaluate_coverage("What is RAG?",doc,u)
    assert not result["ok"]

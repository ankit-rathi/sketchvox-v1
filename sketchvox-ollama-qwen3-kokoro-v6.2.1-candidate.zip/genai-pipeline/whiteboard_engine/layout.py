"""Constraint-based deterministic layout for SketchVox.

The renderer, QA and layout compiler share the same geometry contract:
every drawable object is measured using the same font metrics and the same
object geometry, then placed inside a conservative safe canvas.

Layout is deterministic and content-preserving. It may wrap/reflow text,
reposition objects, and reduce secondary typography, but it never rewrites
teaching claims.
"""
from __future__ import annotations
from copy import deepcopy
from typing import Any
from PIL import ImageDraw, Image
from .scene_graph import object_bbox

SAFE=(72,58,72,62)  # left, top, right, bottom
MIN_FONT=20
TITLE_MIN_FONT=28
MAX_TEXT_LINES=4

def _move(obj:dict[str,Any], dx:float, dy:float) -> None:
    for k in ("x","x2"):
        if k in obj:
            obj[k]=round(float(obj[k])+dx,2)
    for k in ("y","y2"):
        if k in obj:
            obj[k]=round(float(obj[k])+dy,2)

def _is_text(obj:dict[str,Any]) -> bool:
    return obj.get("type") in {"text","equation","number"}

def _font_for(obj:dict[str,Any], size:int):
    from .assets import font
    return font(max(1,int(size)), bool(obj.get("bold",obj.get("type")=="equation")))

def _wrap(text:str, font_obj, max_width:float) -> list[str]:
    d=ImageDraw.Draw(Image.new("RGB",(4,4)))
    words=str(text).split()
    if not words: return [""]
    lines=[]; cur=""
    for word in words:
        trial=(cur+" "+word).strip()
        if d.textbbox((0,0),trial,font=font_obj)[2] <= max_width or not cur:
            cur=trial
        else:
            lines.append(cur); cur=word
    if cur: lines.append(cur)
    return lines

def _fit_text(obj:dict[str,Any], width:int, height:int) -> None:
    if not _is_text(obj): return
    text=str(obj.get("text",obj.get("value","")) or "").strip()
    if not text: return
    x=float(obj.get("x",0)); y=float(obj.get("y",0)); scale=max(.25,float(obj.get("scale",1)))
    size=float(obj.get("size",46)); role=str(obj.get("semantic_role",""))
    # Text is a semantic object, not a fixed-width raster line. Give it a
    # measured column and let the renderer use the exact same wrapping policy.
    avail=max(120.0, width-SAFE[2]-x)
    requested=float(obj.get("max_width",avail))
    max_width=max(80.0,min(requested,avail))
    min_size=TITLE_MIN_FONT if role in {"headline","question","concept_label"} or obj.get("bold") else MIN_FONT
    for _ in range(8):
        f=_font_for(obj,max(1,int(size*scale)))
        lines=_wrap(text,f,max_width)
        if len(lines)<=MAX_TEXT_LINES:
            break
        # Prefer wrapping to shrinking. Only shrink secondary/very long copy.
        if size <= min_size+0.1:
            break
        size=max(min_size,size*.92)
    obj["size"]=round(size,1)
    obj["max_width"]=round(max_width,1)
    obj["layout_lines"]=len(lines)
    obj["layout_line_height"]=round(float(obj.get("line_height",1.2))*float(obj["size"])*scale,1)
    obj["layout_wrapped"]=len(lines)>1

def _fit_connector(obj:dict[str,Any], width:int, height:int) -> None:
    if obj.get("type") not in {"arrow","line"}: return
    x=float(obj.get("x",0)); y=float(obj.get("y",0))
    x2=float(obj.get("x2",x+200)); y2=float(obj.get("y2",y))
    lo_x,hi_x=SAFE[0]+15,width-SAFE[2]-15; lo_y,hi_y=SAFE[1]+15,height-SAFE[3]-15
    # Clip both endpoints into the safe drawing rectangle rather than shifting
    # a connector as one giant object (which can preserve an unsafe endpoint).
    obj["x"]=round(min(hi_x,max(lo_x,x)),2); obj["x2"]=round(min(hi_x,max(lo_x,x2)),2)
    obj["y"]=round(min(hi_y,max(lo_y,y)),2); obj["y2"]=round(min(hi_y,max(lo_y,y2)),2)
    if abs(obj["x2"]-obj["x"])<24 and abs(obj["y2"]-obj["y"])<24:
        obj["x2"]=round(min(hi_x,obj["x"]+80),2)

def _fit_and_shift(obj:dict[str,Any], width:int, height:int) -> None:
    if obj.get("type") in {"arrow","line"}:
        _fit_connector(obj,width,height)
        return
    _fit_text(obj,width,height)
    for _ in range(3):
        b=object_bbox(obj)
        if not b: return
        dx=0.0; dy=0.0
        if b.x < SAFE[0]: dx=SAFE[0]-b.x
        elif b.x2 > width-SAFE[2]: dx=(width-SAFE[2])-b.x2
        if b.y < SAFE[1]: dy=SAFE[1]-b.y
        elif b.y2 > height-SAFE[3]: dy=(height-SAFE[3])-b.y2
        if abs(dx)<.1 and abs(dy)<.1: return
        _move(obj,dx,dy)
        if _is_text(obj): _fit_text(obj,width,height)

def _fit_inside_containers(objs:list[dict[str,Any]], width:int, height:int) -> None:
    containers=[o for o in objs if o.get("type") in {"round_rect","rect"} and o.get("id")]
    for obj in objs:
        if not _is_text(obj): continue
        candidates=[]
        b=object_bbox(obj)
        if not b: continue
        for c in containers:
            cb=object_bbox(c)
            if not cb: continue
            if cb.x+12 <= b.x <= cb.x2-12 and cb.y+12 <= b.y <= cb.y2-12:
                candidates.append((cb.w*cb.h,c))
        if not candidates: continue
        c=min(candidates,key=lambda x:x[0])[1]
        cb=object_bbox(c)
        obj["parent"]=c.get("id")
        pad=28.0
        # Refit text width to the parent's inner column, then reposition inside.
        obj["max_width"]=max(80.0,cb.x2-cb.x-2*pad)
        _fit_text(obj,width,height)
        b=object_bbox(obj)
        dx=0.0; dy=0.0
        if b.x < cb.x+pad: dx=cb.x+pad-b.x
        if b.x2+dx > cb.x2-pad: dx += cb.x2-pad-(b.x2+dx)
        if b.y < cb.y+pad: dy=cb.y+pad-b.y
        if b.y2+dy > cb.y2-pad: dy += cb.y2-pad-(b.y2+dy)
        _move(obj,dx,dy)
        obj["composition"]="parent_child"

def _priority(obj:dict[str,Any]) -> int:
    role=str(obj.get("semantic_role",""))
    if role in {"headline","question","concept_label","technical_value","evidence_visual"}: return 0
    if role in {"relationship","attention_cue"}: return 1
    if role in {"semantic_icon","concept"}: return 2
    return 3

def _resolve_collisions(objs:list[dict[str,Any]], width:int, height:int, gap:float=18) -> None:
    # Only move lower-priority objects. Connectors are allowed to cross content;
    # moving them can change meaning, so they are exempt from collision solving.
    placed=[]
    for obj in sorted(objs,key=lambda o:(_priority(o),float(o.get("z",0)),float(o.get("start",0)))):
        if obj.get("type") in {"space","summary_board","arrow","line","highlight"}:
            continue
        # Semantic captions are deliberately anchored to their doodle by the
        # presentation compiler. Moving them independently destroys the visual
        # relationship the viewer is meant to read. They still receive the
        # normal safe-canvas proof below.
        if obj.get("semantic_role") in {"annotation","section_label"}:
            placed.append(obj)
            continue
        b=object_bbox(obj)
        if not b: continue
        for prev in placed:
            if (
                (obj.get("parent") and obj.get("parent") == prev.get("id"))
                or (prev.get("parent") and prev.get("parent") == obj.get("id"))
            ):
                continue
            pb=object_bbox(prev)
            if not pb or not b.intersects(pb,gap): continue
            # Prefer moving the current object vertically; this preserves its
            # semantic x relationship (e.g. icon left, explanation right).
            dy=pb.y2+gap-b.y
            if dy>0 and b.y2+dy <= height-SAFE[3]:
                _move(obj,0,dy)
            else:
                dx=pb.x2+gap-b.x
                if dx>0 and b.x2+dx <= width-SAFE[2]:
                    _move(obj,dx,0)
            b=object_bbox(obj)
        placed.append(obj)
        _fit_and_shift(obj,width,height)

def auto_layout_scene(scene:dict, width:int=1280, height:int=720, gap:int=18) -> dict:
    """Always-on final layout proof for a scene.

    Explicit authored coordinates remain the starting point; layout is allowed
    to reflow them only when the measured geometry would be unsafe.
    """
    out=deepcopy(scene)
    objs=[o for o in out.get("objects",[]) if isinstance(o,dict)]
    if not objs: return out
    # Summary boards own their full-canvas surface and are validated separately.
    for obj in objs:
        if obj.get("type")=="summary_board": continue
        _fit_and_shift(obj,width,height)
    _fit_inside_containers(objs,width,height)
    _resolve_collisions(objs,width,height,gap)
    # Resize compound primitives that are intrinsically wider/taller than the
    # safe canvas. Moving cannot solve these; scale their authored dimensions
    # while preserving their semantic structure.
    for obj in objs:
        if obj.get("type")=="summary_board":
            continue
        t=obj.get("type")
        b=object_bbox(obj)
        if not b: continue
        maxw=width-SAFE[0]-SAFE[2]; maxh=height-SAFE[1]-SAFE[3]
        if t in {"chart","line_chart","bar_chart","pie_chart"} and (b.w>maxw or b.h>maxh):
            factor=min(maxw/max(1,b.w), maxh/max(1,b.h))
            obj["width"]=round(float(obj.get("width",700))*factor,1)
            obj["height"]=round(float(obj.get("height",350))*factor,1)
        elif t=="pipeline" and b.w>maxw:
            items=max(1,len(obj.get("items") or []))
            obj["box_width"]=round(max(80.0,(maxw-(items-1)*20)/items),1)
        elif t=="table" and b.w>maxw:
            cols=max([len(r) for r in (obj.get("rows") or [])],default=1)
            obj["cell_width"]=round(max(70.0,maxw/cols),1)
        elif t in {"token_strip"} and b.w>maxw:
            obj["scale"]=round(max(.45,float(obj.get("scale",1))*maxw/b.w),3)
        elif t in {"circle","ellipse","starburst","highlight_ring","icon","doodle_icon","person"} and (b.w>maxw or b.h>maxh):
            factor=min(maxw/max(1,b.w), maxh/max(1,b.h))
            obj["scale"]=round(max(.35,float(obj.get("scale",1))*factor),3)
        _fit_and_shift(obj,width,height)

    # Final proof pass: if a pathological object still cannot fit, reduce text
    # or place its origin inside the safe region. Never leave invalid geometry.
    for obj in objs:
        if obj.get("type")=="summary_board": continue
        _fit_and_shift(obj,width,height)
        b=object_bbox(obj)
        if b and (b.x<SAFE[0]-0.1 or b.y<SAFE[1]-0.1 or b.x2>width-SAFE[2]+0.1 or b.y2>height-SAFE[3]+0.1):
            if _is_text(obj):
                # Last resort: make body text compact while preserving all words.
                obj["size"]=max(MIN_FONT,float(obj.get("size",MIN_FONT))*.82)
                _fit_text(obj,width,height)
                _fit_and_shift(obj,width,height)
            else:
                _move(obj,max(0,SAFE[0]-b.x)+min(0,(width-SAFE[2])-b.x2),
                           max(0,SAFE[1]-b.y)+min(0,(height-SAFE[3])-b.y2))
    out.setdefault("layout",{})["enabled"]=True
    out["layout"]["engine"]="constraint-v1"
    out["layout"]["safe_margin"]=list(SAFE)
    out["layout"]["proof"]=all(
        (lambda b: b is None or (b.x>=SAFE[0]-0.1 and b.y>=SAFE[1]-0.1 and b.x2<=width-SAFE[2]+0.1 and b.y2<=height-SAFE[3]+0.1))(object_bbox(o))
        for o in objs if o.get("type")!="summary_board"
    )
    return out

def auto_layout_project(project:dict, width:int=1280,height:int=720)->dict:
    out=deepcopy(project)
    out["scenes"]=[auto_layout_scene(s,width,height) for s in out.get("scenes",[])]
    return out

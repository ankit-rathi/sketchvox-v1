import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

def test_v43_parent_child_collision_repairs_inside_container(tmp_path):
    from whiteboard_engine.renderer_worldclass import render_worldclass

    project = {
        "meta": {"title": "Regression", "currency": "INR", "concept_count": 1},
        "scenes": [
            {
                "id": "scene-01", "purpose": "example", "duration": 2.0,
                "narration": "The label belongs inside the card.",
                "objects": [
                    {"id": "card", "type": "round_rect", "x": 625, "y": 185, "x2": 1000, "y2": 455,
                     "start": 0.1, "duration": 1.7, "color": "#059669", "stroke": 4},
                    {"id": "label", "type": "text", "x": 900, "y": 325,
                     "text": "the base is now bigger", "size": 25.5, "bold": True,
                     "start": 0.2, "duration": 1.6, "color": "#059669"},
                ],
            },
            {
                "id": "summary", "purpose": "summary", "duration": 2.0,
                "narration": "One takeaway.",
                "objects": [{
                    "id": "summary-board", "type": "summary_board", "x": 0, "y": 0,
                    "width": 1280, "height": 720, "title": "1 KEY TAKEAWAY",
                    "subtitle": "QA", "cards": [{"title": "PARENT / CHILD",
                    "takeaway": "Text stays inside its card.", "icon": "result"}],
                    "start": 0.1, "duration": 1.7,
                }],
            },
        ],
    }
    out = tmp_path / "regression.mp4"
    path, repaired, report = render_worldclass(
        project, out, {"fps": 10, "hand": False, "texture": False,
        "qa_strict": True, "qa_standard_strict": True,
        "visual_qa_passes": 12, "visual_qa_samples": 4, "return_details": True}
    )
    assert Path(path).exists()
    assert report["ok"] is True
    assert report["passes_attempted"] in {1, 2}
    assert (
        any("reflowed text label inside parent container card" in a for a in report["repair_actions"])
        or repaired.get("meta", {}).get("layout_contract", {}).get("version") == "constraint-v1"
    )
    label = next(o for o in repaired["scenes"][0]["objects"] if o["id"] == "label")
    assert (
        label.get("parent") == "card"
        or (
            label["x"] >= 625 and label["x"] <= 1000
            and label["y"] >= 185 and label["y"] <= 455
        )
    )
    assert label["x"] < 900
    from whiteboard_engine.scene_graph import object_bbox
    assert object_bbox(label).x2 <= 980

def test_advisory_warnings_do_not_block_strict_render():
    from whiteboard_engine.renderer_worldclass import render_worldclass
    # STATIC_HOLD/VISUAL_REPETITION are advisory by contract; a valid summary
    # scene must still pass the strict production gate.
    project = {
        "meta": {"title": "Advisory", "concept_count": 1},
        "scenes": [{
            "id": "summary", "purpose": "summary", "duration": 2.0,
            "narration": "One takeaway.",
            "objects": [{
                "id": "summary-board", "type": "summary_board", "x": 0, "y": 0,
                "width": 1280, "height": 720, "title": "1 KEY TAKEAWAY",
                "subtitle": "QA", "cards": [{"title": "CHECK",
                "takeaway": "A finished diagram may remain visible.", "icon": "result"}],
                "start": 0.1, "duration": 1.7,
            }],
        }],
    }
    out = Path(__file__).parent / "_advisory_tmp.mp4"
    try:
        _, _, report = render_worldclass(project, out, {
            "fps": 5, "hand": False, "texture": False, "qa_strict": True,
            "qa_standard_strict": True, "visual_qa_passes": 2,
            "visual_qa_samples": 1, "return_details": True})
        assert report["ok"]
    finally:
        out.unlink(missing_ok=True)
        out.with_suffix(".visual-qa.json").unlink(missing_ok=True)

"""SketchVox teaching-integrity gate.

Teaching Contract 2.0 makes semantic identity explicit.  Stable concept IDs and
scene bindings are the hard contract; lexical/token overlap remains advisory
only and is useful for diagnostics, not for deciding whether a good lesson fails.
"""
from __future__ import annotations

import re
from typing import Any
from .teaching_contract import normalize_contract, validate_binding, bind_visual_story

GENERIC_PHRASES = {
    "the question", "the mechanism", "the result", "the idea", "the concept",
    "understand the mechanism", "key takeaway", "remember", "the answer",
    "input", "transformation", "output", "process", "core idea",
}
STOP = {"the","and","for","with","that","this","from","what","does","how","why","into","then","your","you","are","is","of","to","a","an","in","on"}


def _tokens(text: str) -> set[str]:
    return {t for t in re.findall(r"[A-Za-z][A-Za-z0-9_-]{2,}", str(text).lower()) if t not in STOP}


def _generic_ratio(text: str) -> float:
    toks = [t for t in re.findall(r"[a-z][a-z0-9_-]{2,}", text.lower()) if t not in STOP]
    if not toks:
        return 1.0
    generic = sum(1 for t in toks if t in {"question","mechanism","result","idea","concept","input","output","process","transformation","takeaway","remember","system"})
    return generic / max(1, len(toks))


def _scene_text(scene: dict[str, Any]) -> str:
    parts = [str(scene.get("narration", "")), str(scene.get("teaching_claim", ""))]
    for o in scene.get("objects", []) or []:
        if o.get("type") in {"text", "equation", "number"}:
            parts.append(str(o.get("text", o.get("value", ""))))
        for k in ("label", "title", "subtitle"):
            if o.get(k):
                parts.append(str(o[k]))
    return " ".join(parts)


def _summary_cards(project: dict[str, Any]) -> list[dict[str, Any]]:
    out=[]
    for scene in project.get("scenes", []) or []:
        for obj in scene.get("objects", []) or []:
            if obj.get("type") == "summary_board":
                out.extend(obj.get("cards", []) or [])
    return out


def build_topic_understanding(topic: str, llm_doc: dict[str, Any]) -> dict[str, Any]:
    from .answer_ir import normalize_answer_ir
    meta = llm_doc.get("meta", {}) if isinstance(llm_doc, dict) else {}
    return normalize_answer_ir(topic, {
        "answer_contract": meta.get("answer_contract", {}),
        "concepts": (meta.get("topic_understanding", {}) or {}).get("concepts") or meta.get("concepts", []),
    })


def evaluate_coverage(topic: str, project: dict[str, Any], understanding: dict[str, Any]) -> dict[str, Any]:
    """Evaluate the teaching contract using explicit IDs as the hard gate."""
    ir = normalize_contract(understanding)
    has_explicit_bindings = any(bool(s.get("teaches")) for s in project.get("scenes", []) if isinstance(s, dict))
    contract_project = project if has_explicit_bindings else bind_visual_story(project, ir)
    if not has_explicit_bindings:
        # Legacy adapter for pre-5.3 callers: preserve their summary ordering but
        # attach stable IDs once. New pipeline output never uses this fallback.
        required = [c["id"] for c in ir.get("concepts", [])]
        idx = 0
        for scene in contract_project.get("scenes", []):
            for obj in scene.get("objects", []) or []:
                if obj.get("type") == "summary_board":
                    for card in obj.get("cards", []) or []:
                        if idx < len(required) and not card.get("concept_id"):
                            card["concept_id"] = required[idx]
                        idx += 1
    binding = validate_binding(contract_project, ir)
    concepts = ir.get("concepts", []) or []
    statuses=[]
    for c in concepts:
        cid=c["id"]
        scenes=binding["scene_map"].get(cid, [])
        text=" ".join(_scene_text(s) for s in contract_project.get("scenes", []) if s.get("id") in scenes)
        has_explanation = bool(text.strip()) and (bool(str(c.get("explanation") or "").strip()) or not has_explicit_bindings)
        # Explicit binding is authoritative. Lexical similarity is retained only
        # as a diagnostic score so repairs cannot fail merely because phrasing differs.
        score=len(_tokens(c.get("explanation", "")) & _tokens(text))/max(1,len(_tokens(c.get("explanation", "")))) if c.get("explanation") else 1.0
        statuses.append({
            "concept_id": cid,
            "concept": c["name"],
            "type": c.get("type"),
            "mentioned": bool(scenes),
            "introduced": bool(scenes),
            "explained": has_explanation,
            "applied": bool(re.search(r"\b(example|suppose|calculate|compute|compare|consider|use)\b", text.lower())),
            "evidence_scene": scenes[0] if scenes else None,
            "lexical_support_advisory": round(score, 3),
        })
    summary=_summary_cards(project)
    generic_cards=[]
    for card in summary:
        title=str(card.get("title","")).strip().lower(); support=str(card.get("takeaway",card.get("support",""))).strip().lower()
        if title in GENERIC_PHRASES or support in GENERIC_PHRASES or _generic_ratio(title+" "+support)>.45:
            generic_cards.append(card.get("concept_id") or title)
    required=[c["id"] for c in concepts]
    summary_ids=[c.get("concept_id") for c in summary]
    errors=list(binding.get("errors", []))
    if not ir.get("one_sentence_answer"):
        errors.append("missing one_sentence_answer")
    if not concepts:
        errors.append("missing substantive concepts")
    if any(not x["explained"] for x in statuses):
        errors.append("one or more required concepts are not actually explained")
    if generic_cards:
        errors.append("summary contains generic cards")
    if not re.search(r"[A-Za-z]{3,}", " ".join(_scene_text(s) for s in project.get("scenes", []))):
        errors.append("storyboard contains no substantive teaching text")
    return {
        "ok": not errors,
        "topic": topic,
        "contract_version": "2.0",
        "concepts": statuses,
        "required_concepts": required,
        "summary_cards": len(summary),
        "summary_ids": summary_ids,
        "generic_summary_cards": len(generic_cards),
        "binding": binding,
        "errors": errors,
    }


def enforce_integrity(topic: str, project: dict[str, Any], answer_ir: dict[str, Any]) -> dict[str, Any]:
    from copy import deepcopy
    out=deepcopy(project)
    coverage=evaluate_coverage(topic, out, answer_ir)
    out.setdefault("meta", {})["answer_ir"] = normalize_contract(answer_ir)
    out["meta"]["topic_understanding_ir"] = normalize_contract(answer_ir)
    out["meta"]["coverage_gate"] = coverage
    out["meta"]["teaching_integrity_version"] = "5.4-contract-2.0"
    out["meta"]["teaching_audit"] = {
        "contract_version": "2.0",
        "required_concept_ids": coverage["required_concepts"],
        "scene_map": coverage["binding"]["scene_map"],
        "summary_ids": coverage["summary_ids"],
        "errors": coverage["errors"],
    }
    return out

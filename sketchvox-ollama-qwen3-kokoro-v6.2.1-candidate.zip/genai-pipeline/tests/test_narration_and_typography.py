from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from PIL import Image, ImageDraw
from whiteboard_engine.renderer_worldclass import _font, _text_metrics, draw_handwritten_text, _rupee_font, _draw_rupee_glyph
from whiteboard_engine.voiceover import retime_project_to_audio


def test_bundled_comic_neue_is_primary_font():
    f = _font(32, False, True)
    assert "ComicNeue" in str(getattr(f, 'path', ''))


def test_rupee_width_and_text_metrics_are_stable():
    a = _text_metrics("₹10,000", 48, True)[0]
    b = _text_metrics("₹10,000", 48, True)[0]
    assert a == b and a > 100


def test_bundled_rupee_font_exists_and_is_not_the_old_hand_built_shape():
    f = _rupee_font(48)
    assert f is not None
    assert "NotoSans" in str(getattr(f, 'path', ''))


def test_rupee_renders_as_one_connected_symbol():
    img = Image.new("RGBA", (180, 100), "white")
    d = ImageDraw.Draw(img)
    _draw_rupee_glyph(d, 20, 15, 56, "#222222", 2)
    # There should be visible ink in the expected glyph box, and the glyph
    # should not exceed its own advance width by a large amount.
    crop = img.crop((10, 5, 100, 95))
    assert crop.getbbox() is not None


def test_progressive_text_uses_single_baseline():
    img = Image.new("RGBA", (900, 160), "white")
    cfg = {"ink": "#262626", "accent": "#2563D8"}
    end = draw_handwritten_text(img, {"text": "₹10,000 at 10%", "x": 30, "y": 40, "size": 48, "bold": True}, 1.0, cfg)
    assert end[0] > 300
    assert img.getbbox() is not None


def test_local_tts_normalizes_finance_symbols():
    from whiteboard_engine.voiceover import _normalize_for_local_tts
    text = _normalize_for_local_tts("Invest ₹10,000 at 10%: it becomes ₹11,000 × 1.1.")
    assert "rupees" in text and "percent" in text and "times" in text
    assert "₹" not in text and "%" not in text and "×" not in text


def test_scene_retime_matches_actual_audio_duration():
    project = {"scenes": [{"duration": 10, "narration": "hello", "objects": [
        {"type": "text", "x": 10, "y": 10, "text": "A", "start": 2, "duration": 4}
    ]}]}
    out = retime_project_to_audio(project, [5.0])
    scene = out["scenes"][0]
    assert scene["duration"] == 5.0
    assert abs(scene["objects"][0]["start"] - 1.0) < 1e-6
    assert abs(scene["objects"][0]["duration"] - 2.0) < 1e-6

def test_rupee_glyph_matches_rendered_golden_fixture():
    from hashlib import sha256
    from pathlib import Path
    fixture = Path(__file__).parent / "fixtures" / "rupee_glyph.png"
    img = Image.new("RGBA", (180, 100), (255, 255, 255, 255))
    d = ImageDraw.Draw(img)
    _draw_rupee_glyph(d, 20, 15, 56, "#222222", 2)
    assert sha256(img.tobytes()).hexdigest() == sha256(Image.open(fixture).convert("RGBA").tobytes()).hexdigest()


def test_summary_takeaway_count_matches_cards():
    from whiteboard_engine.deterministic_director import build_plan
    expected={
        'What is RAG in AI?':3,
        'What is compound interest?':3,
        'What is an ETF?':3,
        'What is a moving average?':4,
    }
    for prompt,count in expected.items():
        project=build_plan(prompt)
        summary=next(s for s in project['scenes'] if s['id']=='summary')
        board=next(o for o in summary['objects'] if o.get('type')=='summary_board')
        assert len(board['cards']) == count
        assert board['title'].startswith(f'{count} KEY TAKEAWAYS')
        assert f'Here are {count} ' in summary['narration']


def test_summary_layout_adapts_to_card_count():
    from whiteboard_engine.renderer_worldclass import _summary_layout
    for n in (1,2,3,4,5):
        positions,w,h=_summary_layout(n,1280,720)
        assert len(positions)==n
        assert all(x >= 0 and y >= 0 and x+w <= 1280 and y+h <= 720 for x,y in positions)
        assert len(set(positions)) == n


def test_gemini_summary_contract_preserves_concept_count():
    from whiteboard_engine.storyboard import _repair_summary_contract
    doc = {
        "meta": {"title": "Test Topic", "concepts": [
            {"title": "ONE", "takeaway": "First"},
            {"title": "TWO", "takeaway": "Second"},
            {"title": "THREE", "takeaway": "Third"},
            {"title": "FOUR", "takeaway": "Fourth"},
            {"title": "FIVE", "takeaway": "Fifth"},
            {"title": "SIX", "takeaway": "Sixth"},
        ]},
        "scenes": [
            {"purpose": "hook", "duration": 3, "narration": "Hook", "objects": []},
            {"purpose": "concept", "duration": 4, "narration": "One", "objects": []},
            {"purpose": "concept", "duration": 4, "narration": "Two", "objects": []},
            {"purpose": "concept", "duration": 4, "narration": "Three", "objects": []},
            {"purpose": "concept", "duration": 4, "narration": "Four", "objects": []},
            {"purpose": "concept", "duration": 4, "narration": "Five", "objects": []},
            {"purpose": "concept", "duration": 4, "narration": "Six", "objects": []},
        ],
    }
    out = _repair_summary_contract(doc)
    summary = out["scenes"][-1]
    board = next(o for o in summary["objects"] if o["type"] == "summary_board")
    assert len(board["cards"]) == 6
    assert out["meta"]["concept_count"] == 6
    assert "6 key takeaways" in summary["narration"].lower()


def test_local_provider_defaults_and_kokoro_dispatch(monkeypatch, tmp_path):
    from whiteboard_engine import storyboard
    from whiteboard_engine.voiceover import synthesize

    monkeypatch.setenv("SKETCHVOX_CACHE_DIR", str(tmp_path / "cache"))
    monkeypatch.setenv("SKETCHVOX_LLM_PROVIDER", "offline")
    project = storyboard.generate("What is an ETF?")
    assert project["meta"]["mode"] == "offline_template"
    assert len(project["scenes"]) >= 3

    # The new provider name must be accepted by the dispatcher; actual Kokoro
    # inference is environment-dependent and is covered by the install guide.
    assert callable(synthesize)

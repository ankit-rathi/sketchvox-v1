from pathlib import Path
import json
from whiteboard_engine.deterministic_director import build_plan
from whiteboard_engine.scene_graph import normalize_project, validate_v2, object_bbox
from whiteboard_engine.visual_grammar import classify_topic
from whiteboard_engine.layout import auto_layout_scene
from whiteboard_engine.timing import estimate_speech_seconds
from whiteboard_engine.qa import qa_report

def test_scene_graph_ids_and_validation():
    doc=normalize_project(build_plan("What is an ETF?"))
    assert not validate_v2(doc)
    ids=[o["id"] for s in doc["scenes"] for o in s["objects"]]
    assert len(ids)==len(set(ids))

def test_grammar_classification():
    assert classify_topic("What is an ETF?") == "finance"
    assert classify_topic("What is RAG in AI?") == "ai"
    assert classify_topic("SQL JOIN") == "data"
    assert classify_topic("Why does inflation happen?") == "cause_effect"

def test_layout_resolves_overlap_and_edges():
    scene={"duration":5,"layout":{"enabled":True},"objects":[
        {"type":"text","text":"AAAA","size":60,"x":-10,"y":10,"start":0,"duration":2},
        {"type":"text","text":"BBBB","size":60,"x":0,"y":10,"start":0,"duration":2},
    ]}
    out=auto_layout_scene(scene)
    assert object_bbox(out["objects"][0]).x >= 0
    assert not object_bbox(out["objects"][0]).intersects(object_bbox(out["objects"][1]),4)

def test_timing_is_deterministic():
    a=estimate_speech_seconds("This is a short explanation.")
    b=estimate_speech_seconds("This is a short explanation.")
    assert a==b and a>=2

def test_qa_catches_empty_scene():
    report=qa_report({"scenes":[{"duration":3,"narration":"hello","objects":[]}]})
    assert not report["ok"]
    assert any(i["code"]=="EMPTY_SCENE" for i in report["issues"])

def test_smoke_corpus_all_plans_validate():
    corpus=json.loads(open(Path(__file__).resolve().parents[1] / "examples" / "phase1_smoke_corpus.json",encoding="utf-8").read())
    for topic in corpus:
        doc=normalize_project(build_plan(topic))
        assert not validate_v2(doc), topic

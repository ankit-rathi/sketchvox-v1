"""SketchVox v5.4 AnswerIR: authoritative content contract before teaching/visual design."""
from __future__ import annotations
import re
from copy import deepcopy
from typing import Any

from .teaching_contract import normalize_contract

GENERIC = {
    "the question", "the mechanism", "the result", "the idea", "the concept",
    "input", "output", "process", "transformation", "core idea", "key takeaway",
}


def _text(v: Any) -> str:
    return str(v or "").strip()


def _tokens(text: str) -> set[str]:
    return {x for x in re.findall(r"[A-Za-z][A-Za-z0-9_-]{2,}", text.lower()) if x not in {
        "the", "and", "for", "with", "that", "this", "from", "what", "does", "how", "why", "into", "then", "your", "you", "are", "is", "of", "to", "a", "an", "in", "on"
    }}


def _as_list(value: Any, limit: int = 8) -> list[str]:
    if not isinstance(value, list):
        return []
    out=[]
    for item in value:
        if isinstance(item, dict):
            item=item.get("name") or item.get("concept") or item.get("text") or item.get("title") or item.get("explanation")
        s=_text(item)
        if s: out.append(s)
    return out[:limit]


def normalize_answer_ir(topic: str, raw: dict[str, Any]) -> dict[str, Any]:
    """Normalize a model answer into the locked content contract.

    This function intentionally does not invent missing facts. Missing required
    fields remain missing and are rejected by validate_answer_ir().
    """
    if not isinstance(raw, dict):
        raw={}
    ac=raw.get("answer_contract") or raw.get("answer") or {}
    if not isinstance(ac, dict): ac={}
    concepts=raw.get("concepts") or raw.get("must_explain") or []
    if not isinstance(concepts, list): concepts=[]
    normalized=[]
    for i,c in enumerate(concepts[:8]):
        if isinstance(c, str):
            normalized.append({"id": f"concept_{i+1}", "name": c.strip(), "explanation": ""})
        elif isinstance(c, dict):
            normalized.append({
                "id": _text(c.get("id")) or f"concept_{i+1}",
                "name": _text(c.get("name") or c.get("title") or c.get("concept")),
                "explanation": _text(c.get("explanation") or c.get("takeaway") or c.get("support")),
                "why_it_matters": _text(c.get("why_it_matters")),
                "prerequisites": _as_list(c.get("prerequisites"), 4),
            })
    answer={
        "canonical_question": _text(ac.get("canonical_question")) or _text(raw.get("canonical_question")),
        "one_sentence_answer": _text(ac.get("one_sentence_answer")) or _text(raw.get("one_sentence_answer")),
        "must_explain": _as_list(ac.get("must_explain") or raw.get("must_explain"), 8),
        "useful_example": ac.get("useful_example") or raw.get("useful_example") or "",
        "must_not_confuse_with": _as_list(ac.get("must_not_confuse_with") or raw.get("must_not_confuse_with"), 6),
        "final_mental_model": _text(ac.get("final_mental_model")) or _text(raw.get("final_mental_model")),
    }
    # Concept explanations are authoritative when supplied; derive must_explain
    # from named concepts only if the model omitted the parallel field.
    if not answer["must_explain"]:
        answer["must_explain"]=[c["name"] for c in normalized if c["name"]]
    if not normalized:
        normalized=[{"id":f"concept_{i+1}","name":name,"explanation":""} for i,name in enumerate(answer["must_explain"])]
    return normalize_contract({
        "version": "5.4",
        "topic": topic,
        "canonical_question": answer["canonical_question"] or f"What is {topic}?",
        "one_sentence_answer": answer["one_sentence_answer"],
        "must_explain": answer["must_explain"],
        "useful_example": answer["useful_example"],
        "must_not_confuse_with": answer["must_not_confuse_with"],
        "final_mental_model": answer["final_mental_model"],
        "concepts": normalized,
    })


def validate_answer_ir(ir: dict[str, Any], topic: str | None = None) -> list[str]:
    errors=[]
    if not isinstance(ir, dict): return ["AnswerIR is not an object"]
    if topic and _tokens(topic) and not (_tokens(topic) & _tokens(ir.get("canonical_question", "")+" "+ir.get("one_sentence_answer", ""))):
        errors.append("answer does not reference the requested topic")
    if not _text(ir.get("one_sentence_answer")):
        errors.append("missing one_sentence_answer")
    must=ir.get("must_explain") or []
    if not isinstance(must, list) or not must:
        errors.append("missing must_explain concepts")
    if len(must) > 8: errors.append("too many must_explain concepts")
    if len(must) < 2: errors.append("at least 2 must_explain concepts are required")
    if not _text(ir.get("final_mental_model")):
        errors.append("missing final_mental_model")
    concepts=ir.get("concepts") or []
    if not isinstance(concepts,list) or not concepts:
        errors.append("missing substantive concepts")
    else:
        ids=[str(c.get("id", "")) for c in concepts if isinstance(c,dict)]
        if len(ids) != len(set(ids)) or any(not x.startswith("c_") for x in ids):
            errors.append("concept IDs must be unique stable c_* identifiers")
        if len(concepts) < 2 or len(concepts) > 6:
            errors.append("concepts must contain 2-6 substantive concepts")
        for i, c in enumerate(concepts, 1):
            if not isinstance(c, dict) or not _text(c.get("name")):
                errors.append(f"concept {i} is missing a name")
            if not isinstance(c, dict) or not _text(c.get("explanation")):
                errors.append(f"concept {i} is missing an explanation")
    generic=[]
    for c in concepts:
        name=_text(c.get("name") if isinstance(c,dict) else c).lower()
        if name in GENERIC or name.startswith("concept "):
            generic.append(name)
    if generic: errors.append("generic concepts are not allowed: "+", ".join(generic))
    if concepts and len(concepts) != len(must):
        errors.append("concepts and must_explain must have the same substantive count")
    return errors


def lock_answer_ir(topic: str, raw: dict[str, Any]) -> dict[str, Any]:
    ir=normalize_answer_ir(topic, raw)
    errors=validate_answer_ir(ir, topic)
    if errors:
        raise ValueError("AnswerIR validation failed: " + "; ".join(errors))
    return deepcopy(normalize_contract(ir))

OFFLINE_ANSWER_IR = {
    "bmr": {"one_sentence_answer":"BMR is the amount of energy your body needs at rest to keep essential functions running.","must_explain":["baseline energy at rest","essential body functions","BMR is not total daily energy expenditure"],"final_mental_model":"BMR is your body's baseline energy budget at rest.","concepts":[("Baseline energy at rest","The baseline energy the body needs while resting."),("Essential body functions","That baseline supports essential processes such as breathing and circulation."),("BMR is not total daily energy expenditure","Activity and digestion add energy needs beyond BMR.")]},
    "pe_ratio": {"one_sentence_answer":"The P/E ratio compares a company's share price with its earnings per share.","must_explain":["share price","earnings per share","price divided by earnings"],"final_mental_model":"P/E asks how much investors are paying for each unit of earnings.","concepts":[("Share price","The market price of one share."),("Earnings per share","The company's earnings allocated per share."),("Price divided by earnings","P/E is share price divided by earnings per share.")]},
    "compound_interest": {"one_sentence_answer":"Compound interest grows because each period's return becomes part of the base that can earn future returns.","must_explain":["starting base","return added to the base","return on return"],"final_mental_model":"A growing base creates growing gains at the same rate.","concepts":[("Starting base","The first return is earned on the original amount."),("Return added to the base","The earned return becomes part of the next period's balance."),("Return on return","Future returns can be earned on earlier returns too.")]},
    "moving_average": {"one_sentence_answer":"A moving average smooths a sequence by repeatedly averaging a fixed-size window of recent values.","must_explain":["fixed-size window","average recent values","window moves through the data"],"final_mental_model":"Move the window, average what is inside it, and use the new value to reveal the smoother trend.","concepts":[("Fixed-size window","Choose how many recent observations belong in each calculation."),("Average recent values","Add the values in the window and divide by the number of observations."),("Window moves through the data","Shift the window forward and calculate the next average.")]},
    "etf": {"one_sentence_answer":"An ETF is a fund whose basket of assets can be bought and sold as shares on an exchange.","must_explain":["basket of assets","one ETF share represents exposure to the basket","traded on an exchange"],"final_mental_model":"Think of an ETF as a tradable wrapper around a basket of investments.","concepts":[("Basket of assets","An ETF can hold many underlying investments in one fund."),("One share represents basket exposure","Buying an ETF share gives exposure to the fund's underlying basket."),("Traded on an exchange","ETF shares can trade during market hours like other exchange-listed securities.")]},
    "rag": {"one_sentence_answer":"RAG retrieves relevant external information and supplies it to a language model before the model generates an answer.","must_explain":["retrieve relevant information","augment the prompt with context","generate from supplied context"],"final_mental_model":"Retrieve the right evidence first, then generate from that evidence.","concepts":[("Retrieve relevant information","Find the passages that matter to the question."),("Augment with context","Place the retrieved evidence alongside the question for the model."),("Generate from supplied context","The model uses the supplied context when composing the answer.")]},
    "chatgpt": {"one_sentence_answer":"A language model generates text by predicting the next token from patterns learned during training and the context provided at inference time.","must_explain":["tokens and context","learned patterns","next-token generation"],"final_mental_model":"Context goes in, the model repeatedly predicts the next token, and the sequence becomes the response.","concepts":[("Tokens and context","Text is represented as tokens and the current context is provided to the model."),("Learned patterns","Training teaches the model statistical patterns in language and other data."),("Next-token generation","The model predicts one next token at a time to build the response.")]},
}


def offline_answer_ir(topic: str) -> dict[str, Any] | None:
    from .hybrid_director import _benchmark
    kind=_benchmark(topic)
    data=OFFLINE_ANSWER_IR.get(kind or "")
    if not data: return None
    concepts=[{"id":f"concept_{i+1}","name":name,"explanation":explanation} for i,(name,explanation) in enumerate(data["concepts"])]
    return lock_answer_ir(topic, {"canonical_question":topic,"one_sentence_answer":data["one_sentence_answer"],"must_explain":data["must_explain"],"useful_example":"","must_not_confuse_with":[],"final_mental_model":data["final_mental_model"],"concepts":concepts})

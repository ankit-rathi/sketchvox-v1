"""Provider-routed teaching director with local Ollama/Qwen3 as the default."""
from __future__ import annotations

import json
import os
import time
from typing import Any

from .schema import validate_scene_graph
from .asset_resolver import resolve_scene_graph
from .content_guard import detect_currency, normalize_project_content, sanitize_color
from .teaching_providers import generate_ollama, generate_gemini, _load_cache, _save_cache
from .design_system import apply_visual_design
from .presentation import enforce_visual_first
from .teaching_plan import build_teaching_contract
from .teaching_ir import build_teaching_contract as build_teaching_ir_contract
from .teaching_integrity import enforce_integrity, evaluate_coverage
from .answer_ir import lock_answer_ir, validate_answer_ir, offline_answer_ir
from .teaching_planner import build_teaching_plan, validate_teaching_plan
from .teaching_contract import build_summary_cards, normalize_contract

DIRECTOR_VERSION = "6.2.1-answer-contract"

SYSTEM = '''You are SketchVox, a world-class visual teaching director for short educational doodle videos.
Return ONLY JSON matching the supplied schema.

Teaching rules:
- Before designing scenes, answer the user's actual question in one sentence.
- Build an explicit answer contract: canonical_question, one_sentence_answer, must_explain, useful_example, must_not_confuse_with, final_mental_model.
- Content is for a viewer, not for the model: use plain language, define necessary jargon once, and prefer one precise idea over several vague claims.
- Keep on-screen copy concise: headlines/labels should usually be <= 8 words; explanatory screen copy should usually be <= 22 words. Put nuance and complete reasoning in narration.
- Extract 2-6 topic-specific concepts from the answer; never use generic placeholders such as THE QUESTION, THE MECHANISM, THE RESULT as the lesson concepts.
- Every must_explain concept must be introduced and explained, not merely named. A label appearing on screen is NOT evidence of explanation.
- Use concrete examples when they improve understanding, but never invent unsupported numerical facts.
- Include at least one scene where the answer is applied, calculated, compared, demonstrated, or made concrete when the topic permits it.
- End with a topic-specific summary that lets a viewer reconstruct the answer after pausing the final board.
- If the question is a definition, explicitly state what the thing IS, what it MEASURES/DOES, and why the viewer should care.
- Start with a hook/problem, then build the mental model step-by-step, then finish with a summary.
- For finance, investing, data, mathematics and technical topics, preserve exact numbers and formulas supplied by the user/research.
- Currency is a global invariant: use exactly one currency throughout the entire video. Never switch between $, Rs, ₹, €, or £ in the same lesson. If no currency is specified, use INR/₹ for illustrative finance examples.
- Never output malformed color values such as "None", "No", "null", or prose; colors must be 6-digit hex.
- Never place a new amount directly on top of an earlier amount. Use arrows, separate regions, or a cleared board.
- Prefer deterministic vector primitives over generated images. Use supported object types only.
- Supported object types: text,equation,line,arrow,rect,round_rect,circle,ellipse,person,money,coin,bank,wallet,house,calculator,question,lightbulb,warning,check,cross,magnifier,book,robot,brain,database,server,cloud,gpu,api,table,chart,bar_chart,pie_chart,number,timeline,pipeline,group,highlight,document,lock,folder,space,icon,doodle_icon,summary_board. For icon, provide a semantic icon name in `icon` (or `asset`) and optional `semantic_role`; it is a first-class semantic icon and always has a deterministic vector fallback. For doodle_icon, use only a reviewed asset name from the external doodle catalog and include a semantic role; otherwise use a deterministic vector fallback.
- Keep coordinates inside a 1280x720 canvas. Keep visual density readable.
- Narration must describe what is actually shown in the scene.
- Every scene must have a duration, narration and objects.
- The final scene must have purpose="summary" and exactly one summary_board object. Its cards must correspond one-to-one with the substantive concepts.
- Use short card titles and concise takeaways. Card icon values can be: retrieve,augment,generate,mental,capital,year1,year2,curve,coin,window,average,move,result,rule. If none fits, use rule.
'''

ANSWER_SYSTEM = """You are SketchVox's Answer Architect. Return ONLY JSON matching the supplied AnswerIR schema.\n\nTeaching rules:\n- Answer the user's actual question in one sentence.\n- Extract 2-6 substantive, topic-specific concepts and explain each one.\n- Include a useful concrete example when appropriate.\n- Include important distinctions or misconceptions when useful.\n- End with a memorable mental model.\n- Never use generic placeholders such as THE QUESTION, THE MECHANISM, THE RESULT, INPUT, OUTPUT, PROCESS, or CORE IDEA as substantive concepts.\n- Use only facts supported by the supplied research; when research is empty, use ordinary factual knowledge but do not invent numerical claims.\n- Do not design scenes, choose coordinates, or discuss visual object types.\n"""

ANSWER_IR_SCHEMA: dict[str, Any] = {
    "type": "object", "additionalProperties": True,
    "required": ["canonical_question", "one_sentence_answer", "must_explain", "useful_example", "must_not_confuse_with", "final_mental_model", "concepts"],
    "properties": {
        "canonical_question": {"type": "string"},
        "one_sentence_answer": {"type": "string"},
        "must_explain": {"type": "array", "minItems": 2, "maxItems": 8, "items": {"type": "string"}},
        "useful_example": {"type": ["string", "object"]},
        "must_not_confuse_with": {"type": "array", "items": {"type": "string"}},
        "final_mental_model": {"type": "string"},
        "concepts": {
            "type": "array", "minItems": 2, "maxItems": 6,
            "items": {
                "type": "object", "additionalProperties": True,
                "required": ["name", "explanation"],
                "properties": {
                    "name": {"type": "string", "minLength": 1},
                    "explanation": {"type": "string", "minLength": 1}
                }
            }
        }
    }
}

SCENE_GRAPH_SCHEMA: dict[str, Any] = {
    "type": "object",
    "additionalProperties": False,
    "required": ["meta", "scenes"],
    "properties": {
        "meta": {"type": "object", "additionalProperties": True},
        "scenes": {
            "type": "array",
            "minItems": 3,
            "maxItems": 12,
            "items": {
                "type": "object",
                "additionalProperties": True,
                "required": ["duration", "narration", "objects"],
                "properties": {
                    "scene_number": {"type": "integer"},
                    "id": {"type": "string"},
                    "purpose": {"type": "string"},
                    "duration": {"type": "number", "minimum": 0.5},
                    "narration": {"type": "string"},
                    "objects": {"type": "array", "items": {"type": "object", "additionalProperties": True}},
                },
            },
        },
    },
}


def fallback(topic, language="english", duration=60):
    # A useful no-key fallback, not pretending to be factual research.
    d = float(duration)
    per = max(4, min(10, d / 6))
    return {
        "meta": {"title": topic, "language": language, "mode": "offline_template"},
        "scenes": [
            {"scene_number": 1, "purpose": "hook", "duration": per, "narration": f"Let's understand {topic} in a simple way.", "objects": [{"type": "question", "x": 250, "y": 260, "scale": 1.2}, {"type": "text", "x": 430, "y": 250, "text": topic, "size": 54, "bold": True}]},
            {"scene_number": 2, "purpose": "definition", "duration": per, "narration": f"First, let's define the core idea behind {topic}.", "objects": [{"type": "person", "x": 220, "y": 260}, {"type": "arrow", "x": 330, "y": 330, "x2": 540, "y2": 330}, {"type": "text", "x": 570, "y": 300, "text": "Core idea", "size": 48, "bold": True}]},
            {"scene_number": 3, "purpose": "example", "duration": per, "narration": "Now let's make it concrete with a simple example.", "objects": [{"type": "calculator", "x": 250, "y": 260}, {"type": "arrow", "x": 410, "y": 340, "x2": 650, "y2": 340}, {"type": "number", "x": 700, "y": 280, "value": "Example", "size": 58}]},
            {"scene_number": 4, "purpose": "mechanism", "duration": per, "narration": "The mechanism is easier to remember as a simple flow.", "objects": [{"type": "pipeline", "x": 100, "y": 300, "items": ["Input", "Process", "Output"], "box_width": 220}]},
            {"scene_number": 5, "purpose": "mistake", "duration": per, "narration": "A common mistake is to focus on one detail and miss the bigger picture.", "objects": [{"type": "warning", "x": 270, "y": 320}, {"type": "cross", "x": 500, "y": 330}, {"type": "check", "x": 760, "y": 330}]},
            {"scene_number": 6, "purpose": "takeaway", "duration": per, "narration": f"The key takeaway is to think about {topic} as a system, not an isolated fact.", "objects": [{"type": "lightbulb", "x": 260, "y": 320}, {"type": "text", "x": 390, "y": 285, "text": "Key takeaway", "size": 52, "bold": True}]},
        ],
    }


def _provider_error_message(provider: str, exc: Exception) -> str:
    text = str(exc).replace("\n", " ").strip()
    if "429" in text or "RESOURCE_EXHAUSTED" in text or "quota" in text.lower():
        return f"{provider} quota/rate limit reached: {text}"
    if "401" in text or "403" in text or "API key" in text.lower():
        return f"{provider} authentication/permission error: {text}"
    return f"{provider} request failed: {text}"


def generate(topic, research="", language="english", duration=60, api_key=None, model=None,
             strict=False, max_retries=2, provider=None):
    """Generate a validated scene graph.

    The default is local Ollama + Qwen3. Gemini remains an optional cloud
    provider. Successful provider results are cached locally so renderer
    iteration does not repeatedly consume model calls.
    """
    provider = (provider or os.getenv("SKETCHVOX_LLM_PROVIDER", "ollama")).lower()
    currency=detect_currency(topic, research, os.getenv("SKETCHVOX_CURRENCY", "auto"))
    if provider in {"local", "ollama", "qwen", "qwen3"}:
        provider = "ollama"
        model = model or os.getenv("SKETCHVOX_OLLAMA_MODEL", "qwen3:8b")
    elif provider == "gemini":
        model = model or os.getenv("SKETCHVOX_GEMINI_MODEL", "gemini-3.8-flash")
    elif provider in {"offline", "deterministic", "template"}:
        from .deterministic_director import build_plan
        from .hybrid_director import _benchmark
        # Offline mode is a regression renderer, not a generic teaching brain.
        # Never silently produce a polished but semantically empty template for
        # an unknown topic; require a real teaching model instead.
        if not _benchmark(topic):
            raise ValueError("Offline mode is restricted to known regression benchmarks; use Ollama/Qwen3 for a new topic so the Teaching Integrity gate can build a topic-specific Answer Contract.")
        doc=build_plan(topic)
        doc=_repair_summary_contract(doc, currency=currency)
        doc=normalize_project_content(doc, currency)
        # Offline is an explicit regression path: derive a locked AnswerIR from
        # the deterministic exemplar, then run exactly the same teaching gate.
        summary_cards=[]; definition_text=""
        for sc in doc.get("scenes", []):
            if str(sc.get("purpose", "")).lower() == "definition": definition_text=str(sc.get("narration", ""))
            elif not definition_text and sc.get("narration"): definition_text=str(sc.get("narration", ""))
            for obj in sc.get("objects", []):
                if obj.get("type") == "summary_board": summary_cards=obj.get("cards", [])
        answer_ir=offline_answer_ir(topic)
        if answer_ir is None:
            summary_cards=[]; definition_text=""
            for sc in doc.get("scenes", []):
                if str(sc.get("purpose", "")).lower() == "definition": definition_text=str(sc.get("narration", ""))
                elif not definition_text and sc.get("narration"): definition_text=str(sc.get("narration", ""))
                for obj in sc.get("objects", []):
                    if obj.get("type") == "summary_board": summary_cards=obj.get("cards", [])
            answer_raw={"canonical_question": topic, "one_sentence_answer": definition_text,
                        "must_explain":[str(c.get("title", "")) for c in summary_cards if c.get("title")],
                        "useful_example":"", "must_not_confuse_with":[],
                        "final_mental_model":str((summary_cards[-1] if summary_cards else {}).get("takeaway", definition_text)),
                        "concepts":[{"id":f"concept_{i+1}","name":str(c.get("title", "")),"explanation":str(c.get("takeaway", ""))} for i,c in enumerate(summary_cards) if c.get("title")]}
            answer_ir=lock_answer_ir(topic, answer_raw)
        teaching_plan=build_teaching_plan(answer_ir)
        from .hybrid_director import compile_story
        doc = compile_story(topic, doc, answer_ir=answer_ir, teaching_plan=teaching_plan)
        doc["meta"]["answer_ir"]=answer_ir; doc["meta"]["teaching_plan"]=teaching_plan
        doc=_repair_summary_contract(doc, currency=currency, answer_ir=answer_ir)
        doc=enforce_integrity(topic, doc, answer_ir)
        if not doc["meta"]["coverage_gate"]["ok"]:
            raise ValueError("Teaching coverage gate failed: " + "; ".join(doc["meta"]["coverage_gate"]["errors"]))
        doc["meta"]["mode"]="offline_template"; doc["meta"]["model"]="offline"; doc["meta"]["director"]=DIRECTOR_VERSION
        doc=apply_visual_design(doc, topic)
        doc=enforce_visual_first(doc, topic)
        doc["meta"]["teaching_contract"]=build_teaching_contract(topic,doc)
        doc["meta"]["teaching_ir"]=build_teaching_ir_contract(topic,doc)
        return doc
    symbol={"INR":"₹","USD":"$","EUR":"€","GBP":"£"}[currency]

    answer_prompt = (
        f"User question/topic: {topic}\nLanguage: {language}\nResearch material (use only supported facts; empty means no external research was supplied):\n{research}\n\n"
        "Act as the Answer Architect, not a visual designer. Build a factual, topic-specific AnswerIR before any storyboard exists. "
        "Answer the actual question in one sentence. Extract 2-6 substantive concepts. For each concept, explain what it means. "
        "Include a useful concrete example when appropriate, one important distinction/misconception when useful, and a memorable final mental model. "
        "Never use generic concepts such as THE QUESTION, THE MECHANISM, THE RESULT, INPUT, OUTPUT, PROCESS, or CORE IDEA as substantive concepts. "
        "Do not invent numerical facts that are not supported by the research. Return only the requested JSON schema."
    )
    answer_cached = _load_cache(provider + "_answer", model, answer_prompt)
    answer_started = time.monotonic()
    if answer_cached:
        try:
            answer_ir = lock_answer_ir(topic, answer_cached.get("answer_ir", answer_cached))
        except ValueError:
            # A cache entry created by an older AnswerIR contract may be structurally
            # valid JSON but semantically incomplete (for example, concept names with
            # no explanations). Treat it as a stale cache miss rather than allowing a
            # malformed AnswerIR to reach the visual stage.
            answer_cached = None
    if not answer_cached:
        if provider == "ollama":
            answer_timeout = int(os.getenv("SKETCHVOX_ANSWER_TIMEOUT", os.getenv("SKETCHVOX_OLLAMA_TIMEOUT", "180")))
            answer_raw = generate_ollama(answer_prompt, model=model, schema=ANSWER_IR_SCHEMA, system=ANSWER_SYSTEM, timeout=answer_timeout, validate_scene=False, stage="answer_architect")
        else:
            answer_raw = generate_gemini(answer_prompt, model=model, schema=ANSWER_IR_SCHEMA, system=ANSWER_SYSTEM, api_key=api_key, max_retries=max_retries, validate_scene=False)
        answer_ir = lock_answer_ir(topic, answer_raw)
        answer_ir.setdefault("_diagnostics", {})["answer_architect_seconds"] = round(time.monotonic() - answer_started, 3)
        _save_cache(provider + "_answer", model, answer_prompt, {"answer_ir": answer_ir})

    teaching_plan = build_teaching_plan(answer_ir)
    plan_errors = validate_teaching_plan(teaching_plan, answer_ir)
    if plan_errors:
        raise ValueError("Teaching plan validation failed: " + "; ".join(plan_errors))

    prompt = (
        f"Topic: {topic}\nLanguage: {language}\nTarget duration: {duration}s\nCurrency: {currency} ({symbol})\n\n"
        "LOCKED ANSWER IR — this is authoritative and MUST NOT be changed by the visual director:\n" + json.dumps(answer_ir, ensure_ascii=False, indent=2) + "\n\n"
        "LOCKED TEACHING PLAN:\n" + json.dumps(teaching_plan, ensure_ascii=False, indent=2) + "\n\n"
        "Design only the visual teaching storyboard. Every required concept must be explicitly explained in narration/teaching_claim and represented visually. "
        "Do not invent or rename substantive concepts. Do not create a generic summary. The final summary must be compiled from the locked AnswerIR concepts. "
        "Use short display copy and concrete visual relationships. Return only the scene graph JSON schema."
    )
    cached = _load_cache(provider, model, SYSTEM + "\n" + prompt)
    if cached:
        raw_doc = cached
        from .hybrid_director import compile_story
        compiled = compile_story(topic, raw_doc, answer_ir=answer_ir, teaching_plan=teaching_plan)
        compiled = _repair_summary_contract(compiled, currency=currency, answer_ir=answer_ir)
        compiled = enforce_integrity(topic, compiled, answer_ir)
        if not compiled.get("meta", {}).get("coverage_gate", {}).get("ok", False):
            raise ValueError("Teaching coverage gate failed: " + "; ".join(compiled["meta"]["coverage_gate"].get("errors", [])))
        compiled = normalize_project_content(compiled, currency)
        compiled.setdefault("meta", {})["mode"] = "ollama_hybrid_cached"
        compiled["meta"]["model"] = model
        compiled["meta"]["answer_ir"] = answer_ir
        compiled["meta"]["teaching_plan"] = teaching_plan
        compiled = apply_visual_design(compiled, topic)
        compiled = enforce_visual_first(compiled, topic)
        compiled["meta"]["teaching_contract"] = build_teaching_contract(topic, compiled)
        compiled["meta"]["teaching_ir"] = build_teaching_ir_contract(topic, compiled)
        return compiled

    visual_started = time.monotonic()
    try:
        if provider == "ollama":
            visual_timeout = int(os.getenv("SKETCHVOX_VISUAL_TIMEOUT", os.getenv("SKETCHVOX_OLLAMA_TIMEOUT", "300")))
            raw_doc = generate_ollama(prompt, model=model, schema=SCENE_GRAPH_SCHEMA, system=SYSTEM,
                                      timeout=visual_timeout, stage="visual_director")
        else:
            raw_doc = generate_gemini(prompt, model=model, schema=SCENE_GRAPH_SCHEMA, system=SYSTEM,
                                      api_key=api_key, max_retries=max_retries)
        from .hybrid_director import compile_story
        doc = compile_story(topic, raw_doc, answer_ir=answer_ir, teaching_plan=teaching_plan)
        doc = _repair_summary_contract(doc, currency=currency, answer_ir=answer_ir)
        doc = enforce_integrity(topic, doc, answer_ir)
        if not doc.get("meta", {}).get("coverage_gate", {}).get("ok", False):
            raise ValueError("Teaching coverage gate failed: " + "; ".join(doc["meta"]["coverage_gate"].get("errors", [])))
        doc = _repair_summary_contract(doc, currency=currency, answer_ir=answer_ir)
        doc = normalize_project_content(doc, currency)
        errs = validate_scene_graph(doc)
        if errs:
            raise ValueError("Scene graph validation failed: " + "; ".join(errs))
        doc.setdefault("meta", {})["mode"] = provider
        doc["meta"]["model"] = model
        doc=apply_visual_design(doc, topic)
        doc=enforce_visual_first(doc, topic)
        doc["meta"]["teaching_contract"]=build_teaching_contract(topic,doc)
        doc["meta"]["teaching_ir"]=build_teaching_ir_contract(topic,doc)
        doc["meta"]["answer_ir"]=answer_ir
        doc["meta"]["teaching_plan"]=teaching_plan
        doc["meta"].setdefault("generation", {})["visual_director_seconds"] = round(time.monotonic() - visual_started, 3)
        _save_cache(provider, model, SYSTEM + "\n" + prompt, doc)
        return doc
    except Exception as exc:
        # AnswerIR is authoritative and failures in that stage remain hard
        # failures. Once AnswerIR + TeachingPlan are locked, a visual-director
        # timeout is recoverable: compile a topic-specific semantic storyboard
        # from the locked teaching contract instead of falling back to generic
        # filler. `strict=True` remains available for diagnostics/benchmarks.
        if strict:
            raise RuntimeError(_provider_error_message(provider, exc)) from exc
        if provider == "ollama":
            from .semantic_storyboard import compile_semantic_storyboard
            diagnostics = {
                "stage": "visual_director", "provider": provider, "model": model,
                "error": _provider_error_message(provider, exc),
                "fallback": "semantic_compiler", "answer_ir": "available",
                "teaching_plan": "available",
                "elapsed_seconds": round(time.monotonic() - visual_started, 3),
            }
            doc = compile_semantic_storyboard(topic, answer_ir, teaching_plan, duration=duration, language=language, diagnostics=diagnostics)
            doc.setdefault("meta", {})["provider_error"] = diagnostics["error"]
            return doc
        doc = fallback(topic, language, duration)
        doc.setdefault("meta", {})["provider_error"] = _provider_error_message(provider, exc)
        return doc

def _scene_is_summary(scene: dict[str, Any]) -> bool:
    purpose=str(scene.get("purpose", "")).lower()
    return purpose in {"summary", "recap", "takeaway", "final_summary"} or any(o.get("type")=="summary_board" for o in scene.get("objects", []))


def _visible_text(scene: dict[str, Any]) -> str:
    parts=[]
    for o in scene.get("objects", []):
        if o.get("type") in {"text","equation","number"}:
            v=o.get("text",o.get("value",o.get("label","")))
            if v: parts.append(str(v).lower())
        elif o.get("type")=="money" and o.get("label"):
            parts.append(str(o["label"]).lower())
    return " ".join(parts)


def _token_set(text: str) -> set[str]:
    return {x for x in __import__('re').findall(r"[a-z0-9₹$€£]{3,}", text.lower()) if x not in {"the","and","for","with","from","this","that"}}


def _is_generic_title(title: str) -> bool:
    t=title.strip().lower()
    return t in {"concept","rule","idea","step","takeaway","summary","concept 1","concept 2","concept 3","concept 4","concept 5","concept 6"} or t.startswith("concept ")


def _derive_concept(scene: dict[str, Any], index: int) -> dict[str, Any]:
    explicit=str(scene.get("concept",scene.get("title",""))).strip()
    title=explicit if explicit and not _is_generic_title(explicit) else ""
    if not title:
        for o in scene.get("objects",[]):
            if o.get("type") in {"text","equation","number"}:
                v=str(o.get("text",o.get("value",""))).strip()
                if v and len(v)<=42 and not _is_generic_title(v) and not v.lower().startswith(("what is","let's","remember","the idea","the mechanism")):
                    title=v
                    break
    if not title:
        title=str(scene.get("purpose",f"Concept {index+1}")).replace("_"," ").strip().title()
    narration=str(scene.get("takeaway",scene.get("narration",""))).strip()
    # Keep cards concise; the summary is a memory aid, not a transcript.
    words=narration.split()
    if len(words)>22: narration=" ".join(words[:22]).rstrip(".,")+"."
    return {"title":title[:44].upper(),"takeaway":narration[:180],"icon":"rule"}


def _repair_summary_contract(doc: dict[str, Any], currency: str = "INR", answer_ir: dict[str, Any] | None = None) -> dict[str, Any]:
    """Compile model output into one clean teaching story and one final recap."""
    scenes=list(doc.get("scenes") or [])
    preserved_cards=[]
    for candidate in scenes:
        if _scene_is_summary(candidate):
            for obj in candidate.get("objects", []):
                if obj.get("type")=="summary_board" and isinstance(obj.get("cards"), list):
                    preserved_cards.extend(obj.get("cards", []))
                    break
    hooks=[]
    substantive=[]
    seen=[]
    for scene in scenes:
        if _scene_is_summary(scene):
            continue
        if (str(scene.get("purpose", "")).lower() == "hook" or str(scene.get("id", "")).lower() == "hook") and scene.get("substantive") is not True and scene.get("teaches_new_concept") is not True:
            hooks.append(scene)
            continue
        txt=_visible_text(scene)
        toks=_token_set(txt)
        duplicate=False
        for prev in seen:
            if toks and prev and len(toks & prev)/max(1,len(toks|prev)) >= 0.82:
                duplicate=True; break
        if duplicate:
            continue
        seen.append(toks)
        substantive.append(scene)
    # Keep a hook plus at most six actual teaching beats. If a model produces
    # more, the earliest non-duplicate beats are retained rather than forcing a
    # seven/eight-card recap.
    substantive=substantive[:6]
    if not substantive:
        substantive=[{"id":"hook","purpose":"hook","duration":5.0,"narration":"Let’s understand the idea step by step.","objects":[]}]

    meta=doc.setdefault("meta", {})
    meta["currency"]=currency
    meta["currency_symbol"]={"INR":"₹","USD":"$","EUR":"€","GBP":"£"}[currency]
    if answer_ir:
        # Teaching Contract 2.0 path: never infer semantic identity from scene
        # labels, counts, or token overlap. Preserve every explicitly bound
        # teaching scene and rebuild the summary directly from locked concepts.
        ir = normalize_contract(answer_ir)
        teaching = [s for s in scenes if not _scene_is_summary(s)]
        if not teaching:
            raise ValueError("AnswerIR teaching contract produced no substantive scenes")
        cards = build_summary_cards(ir)
        summary={
            "id":"summary", "purpose":"summary",
            "duration":max(8.0, min(18.0, 3.0 + len(cards))),
            "narration":"Here are the key ideas from " + str(ir.get("topic") or meta.get("title") or "this topic") + ". " + " ".join(c["name"] + ": " + str(c.get("explanation") or "") for c in ir.get("concepts", [])),
            "clear_board":True, "transition":"wipe", "objects":[{
                "type":"summary_board","x":0,"y":0,"width":1280,"height":720,"start":0.1,
                "duration":max(0.5, max(8.0, min(18.0, 3.0 + len(cards)))-0.35),
                "title":f"{len(cards)} KEY TAKEAWAYS — {str(ir.get('topic') or meta.get('title','SKETCHVOX')).upper()}",
                "subtitle":"What to remember","cards":cards,
                "reveal_seconds":max(3.5,0.72*len(cards)+1.8)
            }]
        }
        for i,scene in enumerate(teaching):
            scene.setdefault("id",f"scene-{i+1:02d}")
            if i>0 and scene.get("board_mode") != "continue": scene["clear_board"]=True
            scene.setdefault("transition","none" if i==0 else "wipe")
        doc["scenes"]=teaching+[summary]
        meta["concepts"]=[{"concept_id":c["concept_id"],"title":c["title"],"takeaway":c["takeaway"]} for c in cards]
        meta["concept_count"]=len(cards)
        meta["summary_count"]=len(cards)
        meta["summary_contract"]="one_final_summary_exactly_one_card_per_locked_concept_id"
        return doc
    # A high-quality director may already have authored a deliberate recap (the
    # deterministic exemplars do). Preserve that semantic contract instead of
    # truncating it to the number of non-hook scenes. A hook, mechanism and
    # takeaway scene can legitimately teach three concepts; the recap should not
    # suddenly become two cards just because one scene was classified as a hook.
    concepts=[]
    if answer_ir:
        for c in answer_ir.get("concepts", []):
            if isinstance(c, dict) and str(c.get("name", "")).strip():
                concepts.append({"title": c["name"], "takeaway": c.get("explanation", ""), "support": c.get("why_it_matters", "")})
    supplied=meta.get("concepts")
    if not concepts and isinstance(supplied,list):
        for c in supplied:
            if isinstance(c,str): c={"title":c}
            if not isinstance(c,dict): continue
            title=str(c.get("title","" )).strip()
            if title and not _is_generic_title(title): concepts.append(c)
    preserved_valid=[dict(c) for c in preserved_cards if isinstance(c,dict) and str(c.get("title","")).strip() and not _is_generic_title(str(c.get("title","")))]
    if not concepts and len(preserved_valid) >= 2:
        concepts=preserved_valid[:6]
    if len(concepts) < 2 and not answer_ir:
        concepts=[_derive_concept(scene,i) for i,scene in enumerate(substantive[:6])]
    if len(concepts) < 2 and answer_ir:
        raise ValueError("AnswerIR did not provide enough substantive concepts for the summary")
    if len(concepts) > 6:
        concepts=concepts[:6]
    cards=[]
    used_icons=set()
    icon_defaults=["question","mechanism","result","mental","curve","retrieve"]
    for i,c in enumerate(concepts):
        # Cards are a semantic concept contract, not a one-to-one count of scene
        # objects. A single concept may be demonstrated across multiple scenes.
        base=_derive_concept(substantive[min(i,len(substantive)-1)],i) if substantive else {"title":f"Concept {i+1}","takeaway":"Remember the mechanism shown in this step."}
        title=str(c.get("title",base["title"])).strip() or base["title"]
        takeaway=str(c.get("takeaway","")).strip() or base["takeaway"]
        phrase=str(c.get("phrase","")).strip()
        support=str(c.get("support","")).strip()
        requested_icon=str(c.get("icon","")).strip().lower()
        if not requested_icon or requested_icon in used_icons:
            requested_icon=icon_defaults[i % len(icon_defaults)]
            while requested_icon in used_icons:
                requested_icon=icon_defaults[len(used_icons) % len(icon_defaults)]
        used_icons.add(requested_icon)
        card={"title":title[:44].upper(),"takeaway":takeaway[:180] or "Remember the mechanism shown in this step.","icon":requested_icon,"color":sanitize_color(c.get("color")) if c.get("color") else None}
        if phrase: card["phrase"]=phrase[:60]
        if support: card["support"]=support[:120]
        cards.append(card)
    # Remove empty color keys so the renderer never sees a model placeholder.
    for card in cards:
        if not card.get("color"): card.pop("color",None)

    # Make the board the only summary scene, always at the end.
    summary={
        "id":"summary", "purpose":"summary", "duration":max(8.0, min(18.0, 2.8+1.0*len(cards))),
        "narration":_summary_narration(str(meta.get("title", "this topic")), cards),
        "clear_board":True, "transition":"wipe", "objects":[]
    }
    summary["objects"]=[{
        "type":"summary_board","x":0,"y":0,"width":1280,"height":720,"start":0.1,
        "duration":max(0.5,summary["duration"]-0.35),
        "title":f"{len(cards)} {'KEY TAKEAWAY' if len(cards)==1 else 'KEY TAKEAWAYS'} — {str(meta.get('title','SKETCHVOX')).upper()}",
        "subtitle":"What to remember","cards":cards,
        "reveal_seconds":max(3.5,0.72*len(cards)+1.8)
    }]
    for i,scene in enumerate(substantive):
        scene.setdefault("id",f"scene-{i+1:02d}")
        if i>0 and scene.get("board_mode") != "continue": scene["clear_board"]=True
        scene.setdefault("transition","none" if i==0 else "wipe")
        # A readable story beat is safer than an LLM's accidental 0-second pile.
        if len(scene.get("objects",[]))>1 and not scene.get("simultaneous"):
            scene.setdefault("layout",{})["enabled"]=False
    story_scenes=hooks+substantive
    for i,scene in enumerate(story_scenes):
        scene.setdefault("id",f"scene-{i+1:02d}")
        scene.setdefault("transition","none" if i==0 else "wipe")
        if i>0 and scene.get("board_mode") != "continue": scene["clear_board"]=True
    doc["scenes"]=story_scenes+[summary]
    meta["concepts"]=[{k:v for k,v in c.items() if v not in (None,"")} for c in cards]
    meta["concept_count"]=len(cards)
    meta["summary_count"]=len(cards)
    meta["summary_contract"]="one_final_summary_exactly_one_card_per_declared_concept"
    return normalize_project_content(doc, currency)


def _summary_narration(title: str, cards: list[dict[str, Any]]) -> str:
    label="key takeaway" if len(cards)==1 else "key takeaways"
    parts=[f"Here are {len(cards)} {label} from {title}."]
    for i,card in enumerate(cards,1):
        parts.append(f"Number {i}, {card.get('title','').lower()}: {card.get('support') or card.get('takeaway','')}")
    return " ".join(parts)

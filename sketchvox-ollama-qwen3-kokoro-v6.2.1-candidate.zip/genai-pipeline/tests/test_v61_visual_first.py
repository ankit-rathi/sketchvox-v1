from whiteboard_engine.presentation import enforce_visual_first, _icons_for, _phrase
from whiteboard_engine.semantic_storyboard import compile_semantic_storyboard
from whiteboard_engine.teaching_contract import build_summary_cards
from whiteboard_engine.scene_graph import object_bbox, normalize_project
from whiteboard_engine.layout import SAFE


def _ir():
    return {
        "topic": "Explain photosynthesis to a class-10 student",
        "canonical_question": "Explain photosynthesis to a class-10 student",
        "one_sentence_answer": "Plants use light energy to turn water and carbon dioxide into food and release oxygen.",
        "concepts": [
            {"id":"c_chlorophyll","name":"Chlorophyll","type":"DEFINITION","explanation":"Chlorophyll is a green pigment that absorbs sunlight in plant cells."},
            {"id":"c_light","name":"Light-dependent reactions","type":"MECHANISM","explanation":"These reactions use sunlight to split water and produce oxygen and energy."},
            {"id":"c_calvin","name":"Calvin cycle","type":"MECHANISM","explanation":"The cycle uses stored energy to convert carbon dioxide into sugars."},
            {"id":"c_glucose","name":"Glucose production","type":"DEFINITION","explanation":"Glucose is the sugar produced by photosynthesis and stores chemical energy."},
            {"id":"c_oxygen","name":"Oxygen release","type":"RELATIONSHIP","explanation":"Oxygen is released from the leaf into the atmosphere."},
        ],
        "useful_example":"A sunflower uses sunlight, water and carbon dioxide to make sugar and release oxygen.",
        "must_not_confuse_with":["cellular respiration"],
        "final_mental_model":"A green factory: sunlight powers the conversion of water and air into food and oxygen.",
    }


def test_display_phrases_are_short_and_not_sentences():
    p=_phrase(_ir()["concepts"][0]["explanation"], "Chlorophyll")
    assert len(p) <= 44
    assert p.lower() != _ir()["concepts"][0]["explanation"].lower()
    assert _icons_for("Chlorophyll", _ir()["concepts"][0]["explanation"])


def test_visual_first_rebuilds_text_heavy_scene_with_related_icons():
    project={"meta":{"answer_ir":_ir()},"scenes":[{
        "id":"s1","purpose":"definition","teaches":["c_chlorophyll"],"duration":5,
        "narration":_ir()["concepts"][0]["explanation"],
        "objects":[
            {"type":"text","x":100,"y":100,"text":"Chlorophyll is a green pigment found in the chloroplasts of plant cells. It absorbs sunlight.","size":32},
            {"type":"text","x":100,"y":300,"text":"More explanatory commentary that belongs in narration rather than on the board.","size":30},
        ]
    }]}
    out=enforce_visual_first(project,"photosynthesis")
    types=[o["type"] for o in out["scenes"][0]["objects"]]
    assert types.count("icon") >= 2
    assert not any(len(str(o.get("text","")))>58 for o in out["scenes"][0]["objects"] if o.get("type")=="text")
    assert out["scenes"][0]["presentation_mode"]=="visual_first"


def test_semantic_compiler_produces_visual_first_concept_beats():
    out=compile_semantic_storyboard("Explain photosynthesis to a class-10 student", _ir(), {"beats":[]}, duration=45)
    teaching=[s for s in out["scenes"] if s.get("teaches")]
    assert len(teaching) >= 5
    for scene in teaching:
        icons=[o for o in scene["objects"] if o.get("type")=="icon"]
        texts=[o for o in scene["objects"] if o.get("type")=="text"]
        assert len(icons) >= 2
        assert all(len(str(o.get("text",""))) <= 58 for o in texts)
        assert all((object_bbox(o) is None or (object_bbox(o).x>=SAFE[0]-1 and object_bbox(o).x2<=1208+1)) for o in scene["objects"])


def test_summary_cards_use_phrase_and_semantic_icon_not_explanation_as_display_copy():
    cards=build_summary_cards(_ir())
    assert len(cards)==5
    for c in cards:
        assert c.get("phrase")
        assert c.get("icon")
        assert len(c["phrase"])<=44
        assert len(c["support"])<=52


def test_relationship_scenes_have_explicit_connectors_and_compact_phrases():
    out=compile_semantic_storyboard("Explain photosynthesis to a class-10 student", _ir(), {"beats":[]}, duration=45)
    teaching=[s for s in out["scenes"] if s.get("teaches")]
    for scene in teaching:
        icons=[o for o in scene["objects"] if o.get("type")=="icon"]
        arrows=[o for o in scene["objects"] if o.get("type")=="arrow"]
        assert len(icons) >= 2
        assert len(arrows) >= 1
        phrases=[o for o in scene["objects"] if o.get("semantic_role")=="emphasis"]
        assert all(len(str(o.get("text",""))) <= 34 for o in phrases)


def test_visual_labels_use_renderer_safe_ascii_chemistry_marks():
    out=compile_semantic_storyboard("Explain photosynthesis to a class-10 student", _ir(), {"beats":[]}, duration=45)
    all_text=" ".join(str(o.get("text","")) for s in out["scenes"] for o in s.get("objects",[]) if o.get("type")=="text")
    assert "₂" not in all_text
    assert "CO2" in all_text or "O2" in all_text

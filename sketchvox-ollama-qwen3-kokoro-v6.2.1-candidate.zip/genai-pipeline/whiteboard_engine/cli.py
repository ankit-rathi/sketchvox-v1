from __future__ import annotations
import argparse, json, os
try:
    from dotenv import load_dotenv
    load_dotenv(Path(__file__).resolve().parents[1] / '.env')
except Exception:
    pass
from pathlib import Path
from .schema import ProjectConfig, validate_scene_graph
from .storyboard import generate
from .renderer import render_project, mux_audio
from .export import write_project_json, write_srt, convert_format

def main():
    ap=argparse.ArgumentParser(description='AI Doodle Studio — deterministic educational whiteboard generator')
    ap.add_argument('--prompt'); ap.add_argument('--storyboard'); ap.add_argument('--research-file')
    ap.add_argument('--out',default='output/doodle_project'); ap.add_argument('--duration',type=int,default=60)
    ap.add_argument('--language',default='english'); ap.add_argument('--format',choices=['16:9','9:16','1:1'],default='16:9')
    ap.add_argument('--fps',type=int,choices=[24,30,60],default=30); ap.add_argument('--no-hand',action='store_true')
    ap.add_argument('--audio',help='Optional narration/music WAV/MP3 to mux into the final video')
    ap.add_argument('--model',default=None); ap.add_argument('--strict-gemini',action='store_true'); args=ap.parse_args()
    out=Path(args.out); out.mkdir(parents=True,exist_ok=True)
    if args.storyboard: project=json.loads(Path(args.storyboard).read_text(encoding='utf-8'))
    elif args.prompt:
        research=Path(args.research_file).read_text(encoding='utf-8') if args.research_file else ''
        project=generate(args.prompt,research=research,language=args.language,duration=args.duration,model=args.model,strict=args.strict_gemini)
    else: ap.error('use --prompt or --storyboard')
    errs=validate_scene_graph(project)
    if errs: print('\n'.join(errs)); raise SystemExit(2)
    write_project_json(project,out/'storyboard.json')
    sizes={'16:9':(1280,720),'9:16':(720,1280),'1:1':(1080,1080)}; w,h=sizes[args.format]
    cfg=ProjectConfig(width=w,height=h,fps=args.fps,format=args.format,hand=not args.no_hand)
    silent,scenes=render_project(project,out,cfg)
    durations=[float(s.get('duration',5)) for s in project['scenes']]
    write_srt(durations,project['scenes'],out/'subtitles.srt')
    final=silent
    if args.audio:
        final=str(out/'whiteboard_final.mp4'); mux_audio(silent,args.audio,final)
    if args.format!='16:9': convert_format(final,out/f'whiteboard_{args.format.replace(":","x")}.mp4',w,h)
    print(f'Project: {out.resolve()}'); print(f'Video: {Path(final).resolve()}')

if __name__=='__main__': main()

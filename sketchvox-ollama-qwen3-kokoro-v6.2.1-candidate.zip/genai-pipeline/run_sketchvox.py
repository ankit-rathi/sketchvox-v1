"""Offline SketchVox CLI: prompt -> deterministic teaching plan -> MP4."""
from __future__ import annotations
import argparse
from pathlib import Path
from whiteboard_engine.deterministic_director import build_plan
from whiteboard_engine.renderer_worldclass import render_worldclass

def main():
    ap=argparse.ArgumentParser(description="SketchVox offline visual explainer")
    ap.add_argument("prompt", help="Concept/question to explain")
    ap.add_argument("--out", default="output/sketchvox_explainer.mp4")
    ap.add_argument("--no-hand", action="store_true")
    args=ap.parse_args()
    project=build_plan(args.prompt)
    out=Path(args.out); out.parent.mkdir(parents=True,exist_ok=True)
    print(render_worldclass(project,out,{"hand":not args.no_hand}))

if __name__=="__main__": main()

"""AI Doodle Studio whiteboard engine."""
from .schema import ProjectConfig, validate_scene_graph
from .storyboard import generate

#!/usr/bin/env python3
"""Prompt -> Gemini teaching director -> Gemini TTS -> deterministic SketchVox MP4.

This is the recommended end-to-end Gemini integration for arbitrary topics.
The free/offline renderer remains the correctness layer.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

try:
    from dotenv import load_dotenv
    load_dotenv(ROOT / ".env")
except Exception:
    pass

from whiteboard_engine.storyboard import generate
from whiteboard_engine.voiceover import build_scene_voiceover, retime_project_to_audio, concatenate_audio, mux_audio
from whiteboard_engine.renderer_worldclass import render_worldclass
from whiteboard_engine.scene_graph import normalize_project, validate_v2
from whiteboard_engine.qa import qa_report


def main():
    ap = argparse.ArgumentParser(description="SketchVox: Gemini teaching + TTS + deterministic doodle renderer")
    ap.add_argument("prompt", help="Topic/question to explain")
    ap.add_argument("--research-file", help="Optional UTF-8 research/source notes to ground the lesson")
    ap.add_argument("--language", default="english")
    ap.add_argument("--duration", type=int, default=60)
    ap.add_argument("--model", default=None, help="Gemini director model; default from SKETCHVOX_GEMINI_MODEL")
    ap.add_argument("--voice-model", default=None, help="Gemini TTS model; default from SKETCHVOX_TTS_MODEL")
    ap.add_argument("--voice", default=None, help="Gemini prebuilt/voice-design/replication voice ID")
    ap.add_argument("--style", default=None, help="TTS delivery style")
    ap.add_argument("--out-dir", default="output/gemini")
    ap.add_argument("--no-voice", action="store_true", help="Generate the Gemini storyboard only")
    ap.add_argument("--strict", action="store_true", help="Fail instead of silently using the offline fallback")
    ap.add_argument("--no-hand", action="store_true")
    ap.add_argument("--no-texture", action="store_true")
    args = ap.parse_args()

    if args.strict and not (os.getenv("GEMINI_API_KEY") or os.getenv("GOOGLE_API_KEY")):
        raise SystemExit("GEMINI_API_KEY is not set. Add it to genai-pipeline/.env")

    research = Path(args.research_file).read_text(encoding="utf-8") if args.research_file else ""
    print(f"[1/5] Gemini teaching director: {args.prompt}")
    project = generate(args.prompt, research=research, language=args.language, duration=args.duration,
                       model=args.model, strict=args.strict)
    project = normalize_project(project)
    print(f"      mode={project.get('meta', {}).get('mode')} model={project.get('meta', {}).get('model', 'offline')}")
    print(f"      scenes={len(project.get('scenes', []))} concepts={project.get('meta', {}).get('concept_count', 'n/a')}")

    out = Path(args.out_dir)
    out.mkdir(parents=True, exist_ok=True)
    project_path = out / "storyboard.json"
    project_path.write_text(json.dumps(project, indent=2, ensure_ascii=False), encoding="utf-8")

    if args.no_voice:
        errors = validate_v2(project)
        qa = qa_report(project)
        if errors or not qa["ok"]:
            raise SystemExit(f"QA failed: {errors or qa['issues']}")
        silent = out / "sketchvox-silent.mp4"
        render_worldclass(project, silent, {"hand": not args.no_hand, "texture": not args.no_texture, "qa_strict": True})
        print(f"[done] {silent}")
        return

    print("[2/5] Gemini TTS: synthesizing one audio track per scene")
    old_tts = os.getenv("SKETCHVOX_TTS_MODEL")
    if args.voice_model:
        os.environ["SKETCHVOX_TTS_MODEL"] = args.voice_model
    voice_dir = out / "voice"
    try:
        paths, durations = build_scene_voiceover(project, voice_dir, provider="gemini",
                                                 voice_name=args.voice, language=args.language, style=args.style)
    finally:
        if old_tts is not None:
            os.environ["SKETCHVOX_TTS_MODEL"] = old_tts
        elif args.voice_model:
            os.environ.pop("SKETCHVOX_TTS_MODEL", None)

    print("[3/5] Retiming visuals to the actual Gemini narration")
    synced = retime_project_to_audio(project, durations, fps=30)
    synced = normalize_project(synced)
    errors = validate_v2(synced)
    qa = qa_report(synced)
    if errors or not qa["ok"]:
        raise SystemExit(f"QA failed before render: {errors or qa['issues']}")
    synced_path = out / "storyboard-synced.json"
    synced_path.write_text(json.dumps(synced, indent=2, ensure_ascii=False), encoding="utf-8")

    print("[4/5] Deterministic whiteboard render")
    silent = out / "sketchvox-silent.mp4"
    render_worldclass(synced, silent, {"hand": not args.no_hand, "texture": not args.no_texture, "qa_strict": True})

    print("[5/5] Muxing audio + final QA")
    audio = out / "gemini-voiceover.m4a"
    concatenate_audio(paths, audio, target_durations=[float(s["duration"]) for s in synced["scenes"]])
    final = out / "sketchvox-gemini.mp4"
    mux_audio(silent, audio, final)

    import subprocess
    vdur = float(subprocess.check_output(["ffprobe", "-v", "error", "-show_entries", "stream=duration", "-select_streams", "v:0", "-of", "default=nw=1:nk=1", str(final)], text=True).strip())
    adur = float(subprocess.check_output(["ffprobe", "-v", "error", "-show_entries", "stream=duration", "-select_streams", "a:0", "-of", "default=nw=1:nk=1", str(final)], text=True).strip())
    delta = abs(vdur - adur)
    if delta > (1 / 30 + 0.03):
        raise SystemExit(f"A/V sync QA failed: video={vdur:.3f}s audio={adur:.3f}s delta={delta:.3f}s")
    report = {
        "prompt": args.prompt,
        "model": project.get("meta", {}).get("model", "offline"),
        "tts_model": os.getenv("SKETCHVOX_TTS_MODEL", "gemini-3.8-flash-tts"),
        "concept_count": project.get("meta", {}).get("concept_count"),
        "scene_audio_durations": durations,
        "final_video_duration": vdur,
        "final_audio_duration": adur,
        "final_av_delta": delta,
        "qa_ok": qa["ok"],
        "final": str(final),
    }
    (out / "report.json").write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()

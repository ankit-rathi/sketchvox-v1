"""SketchVox teaching planner compatibility facade.

Teaching Contract 2.0 lives in teaching_contract.py.  This module keeps the
older public API stable while returning stable concept IDs and first-class beats.
"""
from __future__ import annotations
from typing import Any
from .teaching_contract import build_teaching_contract, normalize_contract


def build_teaching_plan(answer_ir: dict[str, Any]) -> dict[str, Any]:
    return build_teaching_contract(normalize_contract(answer_ir))


def validate_teaching_plan(plan: dict[str, Any], answer_ir: dict[str, Any]) -> list[str]:
    ir = normalize_contract(answer_ir)
    required = [c["id"] for c in ir.get("concepts", [])]
    beats = plan.get("beats", []) or []
    beat_ids = []
    covered = []
    errors = []
    for beat in beats:
        bid = str(beat.get("beat_id") or beat.get("id") or "")
        if not bid:
            errors.append("teaching beat missing beat_id")
        elif bid in beat_ids:
            errors.append(f"duplicate teaching beat: {bid}")
        beat_ids.append(bid)
        for cid in beat.get("concept_ids", []) or []:
            if cid not in required:
                errors.append(f"teaching beat references unknown concept: {cid}")
            else:
                covered.append(cid)
    missing = [cid for cid in required if cid not in covered]
    if missing:
        errors.append("missing teaching beats for concepts: " + ", ".join(missing))
    if not plan.get("final_mental_model"):
        errors.append("missing final mental model")
    return errors

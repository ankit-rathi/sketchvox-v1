"""Teaching/visual grammar primitives used by the deterministic director."""
from __future__ import annotations
import re

GRAMMARS={
 "definition":["hook","definition","example","takeaway"],
 "process":["problem","step_1","step_2","step_3","result","takeaway"],
 "comparison":["hook","left","right","contrast","takeaway"],
 "cause_effect":["cause","mechanism","effect","takeaway"],
 "math":["intuition","numbers","equation","graph","takeaway"],
 "finance":["hook","money_flow","calculation","growth_or_risk","takeaway"],
 "data":["input","transform","model_or_analysis","output","takeaway"],
 "ai":["problem","data_or_prompt","model","result","takeaway"],
}

def classify_topic(prompt:str)->str:
    p=(prompt or "").lower()
    if any(x in p for x in ["compare","difference between","vs ","versus"]): return "comparison"
    if any(x in p for x in ["why does","causes","cause and effect","because"]): return "cause_effect"
    if any(x in p for x in ["equation","calculate","formula","probability","regression","gradient","interest"]): return "math"
    if any(x in p for x in ["stock","etf","bond","inflation","return","portfolio","finance","tax","loan","invest"]): return "finance"
    if any(x in p for x in ["sql","database","dataset","data pipeline","regression","csv","api"]): return "data"
    if any(x in p for x in ["ai","machine learning","neural network","transformer","rag","embedding","attention","llm"]): return "ai"
    if re.search(r"\bwhat is\b|\bdefine\b|\bmeaning of\b",p): return "definition"
    return "process"

def grammar_for(prompt:str): return GRAMMARS[classify_topic(prompt)]

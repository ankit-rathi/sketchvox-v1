import json
from pathlib import Path

from whiteboard_engine.answer_ir import lock_answer_ir, validate_answer_ir
from whiteboard_engine.teaching_planner import build_teaching_plan, validate_teaching_plan
from whiteboard_engine.teaching_integrity import evaluate_coverage
from whiteboard_engine.hybrid_director import compile_story


def bmr_answer():
    return lock_answer_ir("What is BMR (Basal Metabolic Rate)?", {
        "canonical_question": "What is BMR?",
        "one_sentence_answer": "BMR is the amount of energy your body needs at rest to keep essential functions running.",
        "must_explain": ["baseline energy at rest", "essential body functions", "BMR is not total daily energy expenditure"],
        "useful_example": "Think of BMR as the baseline energy budget before everyday activity and digestion add to your energy use.",
        "must_not_confuse_with": ["total daily energy expenditure"],
        "final_mental_model": "BMR is your body's baseline energy budget at rest.",
        "concepts": [
            {"id":"definition","name":"Baseline energy at rest","explanation":"The baseline energy the body needs while resting."},
            {"id":"functions","name":"Essential body functions","explanation":"That baseline supports essential processes such as breathing and circulation."},
            {"id":"distinction","name":"BMR is not total daily energy expenditure","explanation":"Activity and digestion add energy needs beyond BMR."},
        ]
    })


def test_answer_ir_rejects_generic_placeholder_concepts():
    errors = validate_answer_ir(lock_answer_ir("What is BMR?", {
        "canonical_question":"What is BMR?",
        "one_sentence_answer":"BMR is energy needed at rest.",
        "must_explain":["THE MECHANISM","THE RESULT"],
        "final_mental_model":"BMR is a baseline energy need.",
        "concepts":[{"name":"THE MECHANISM"},{"name":"THE RESULT"}],
    }) if False else {
        "version":"5.2","topic":"BMR","canonical_question":"What is BMR?","one_sentence_answer":"BMR is energy needed at rest.","must_explain":["THE MECHANISM","THE RESULT"],"final_mental_model":"BMR is a baseline energy need.","concepts":[{"name":"THE MECHANISM"},{"name":"THE RESULT"}]}, "BMR")
    assert any("generic concepts" in e for e in errors)


def test_bmr_answer_to_teaching_plan_preserves_all_required_concepts():
    answer = bmr_answer()
    plan = build_teaching_plan(answer)
    assert not validate_teaching_plan(plan, answer)
    names = {b["concept"] for b in plan["beats"]}
    assert {c["name"] for c in answer["concepts"]} <= names


def test_summary_is_compiled_from_locked_answer_ir_not_scene_labels():
    answer = bmr_answer()
    raw = {"meta":{"title":"Qwen BMR draft","concepts":[{"title":"THE QUESTION"},{"title":"THE MECHANISM"},{"title":"THE RESULT"}]},"scenes":[
        {"purpose":"definition","narration":answer["one_sentence_answer"],"teaching_claim":answer["one_sentence_answer"],"objects":[{"type":"icon","icon":"body"}]},
        {"purpose":"example","narration":"Activity and digestion add energy needs beyond the baseline.","teaching_claim":"BMR is not total daily energy expenditure.","objects":[]},
    ]}
    out = compile_story("What is BMR (Basal Metabolic Rate)?", raw, answer_ir=answer, teaching_plan=build_teaching_plan(answer))
    from whiteboard_engine.storyboard import _repair_summary_contract
    out = _repair_summary_contract(out, answer_ir=answer)
    board = next(o for s in out["scenes"] for o in s.get("objects",[]) if o.get("type")=="summary_board")
    assert [c["title"] for c in board["cards"]] == [c["name"].upper() for c in answer["concepts"]]
    assert not any(c["title"] in {"THE QUESTION","THE MECHANISM","THE RESULT"} for c in board["cards"])
    gate=evaluate_coverage("What is BMR (Basal Metabolic Rate)?", out, answer)
    assert gate["ok"], gate

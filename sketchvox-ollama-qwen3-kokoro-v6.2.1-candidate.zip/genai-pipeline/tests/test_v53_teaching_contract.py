from whiteboard_engine.answer_ir import lock_answer_ir
from whiteboard_engine.teaching_contract import bind_visual_story, build_summary_cards, validate_binding
from whiteboard_engine.teaching_planner import build_teaching_plan, validate_teaching_plan
from whiteboard_engine.teaching_integrity import evaluate_coverage
from whiteboard_engine.hybrid_director import compile_story


def answer(topic, concepts):
    return lock_answer_ir(topic, {
        "canonical_question": topic,
        "one_sentence_answer": f"{topic} can be understood through the concepts below.",
        "must_explain": [c["name"] for c in concepts],
        "useful_example": "Use a concrete example to make the idea tangible.",
        "must_not_confuse_with": [],
        "final_mental_model": "Connect the concepts into one mental model.",
        "concepts": concepts,
    })


def test_model_ids_are_not_authoritative_and_stable_ids_are_deterministic():
    a = answer("Photosynthesis", [
        {"id": "whatever-qwen-invented", "name": "Light energy", "explanation": "Light supplies energy for the process."},
        {"id": "another-random-id", "name": "Sugar production", "explanation": "The process stores captured energy in sugars."},
    ])
    assert [c["id"] for c in a["concepts"]] == ["c_light_energy", "c_sugar_production"]


def test_one_to_many_scene_support_is_allowed_but_summary_is_exactly_one_per_concept():
    a = answer("RAG", [
        {"name": "Retrieve evidence", "explanation": "Find relevant passages."},
        {"name": "Use context", "explanation": "Supply those passages alongside the question."},
    ])
    p = {"meta": {}, "scenes": [
        {"id": "retrieve", "purpose": "step", "duration": 5, "narration": "Find relevant passages.", "teaches": [a["concepts"][0]["id"]], "objects": [{"type": "database", "x": 200, "y": 250}]},
        {"id": "retrieve-detail", "purpose": "detail", "duration": 5, "narration": "The same evidence can be examined before answering.", "teaches": [a["concepts"][0]["id"]], "objects": [{"type": "document", "x": 500, "y": 250}]},
        {"id": "augment", "purpose": "step", "duration": 5, "narration": "Supply those passages alongside the question.", "teaches": [a["concepts"][1]["id"]], "objects": [{"type": "round_rect", "x": 200, "y": 200, "x2": 900, "y2": 420}]},
        {"id": "summary", "purpose": "summary", "duration": 8, "narration": "Summary", "objects": [{"type": "summary_board", "cards": build_summary_cards(a)}]},
    ]}
    b = validate_binding(p, a)
    assert b["ok"], b
    assert len(b["scene_map"][a["concepts"][0]["id"]]) == 2
    assert b["summary_ids"] == [c["id"] for c in a["concepts"]]


def test_explicit_binding_beats_token_overlap():
    a = answer("Newton's second law", [
        {"name": "Force causes acceleration", "explanation": "Net force changes an object's acceleration."},
        {"name": "Mass changes the response", "explanation": "For the same force, more mass means less acceleration."},
    ])
    p = {"meta": {}, "scenes": [
        {"id": "s1", "purpose": "explain", "duration": 5, "narration": "A push changes how an object moves.", "teaches": [a["concepts"][0]["id"]], "objects": [{"type": "arrow", "x": 200, "y": 300, "x2": 600, "y2": 300}]},
        {"id": "s2", "purpose": "compare", "duration": 5, "narration": "A heavier object responds differently to the same push.", "teaches": [a["concepts"][1]["id"]], "objects": [{"type": "circle", "x": 700, "y": 300, "r": 80}]},
        {"id": "summary", "purpose": "summary", "duration": 8, "narration": "Summary", "objects": [{"type": "summary_board", "cards": build_summary_cards(a)}]},
    ]}
    gate = evaluate_coverage("Newton's second law", p, a)
    assert gate["ok"], gate


def test_heterogeneous_topics_compile_through_same_contract():
    topics = [
        ("Photosynthesis", [("light energy", "Light supplies energy for the process."), ("sugar production", "The process stores captured energy in sugars.")]),
        ("Supply and demand", [("buyers", "Buyers create demand for a good."), ("sellers", "Sellers create supply."), ("market price", "Price coordinates the two sides.")]),
        ("Gradient descent", [("loss", "Loss measures how far the model is from the target."), ("gradient", "The gradient indicates which direction changes the loss."), ("step", "The update moves parameters in the reducing direction.")]),
        ("DNA replication", [("template", "One strand provides a template."), ("copying", "New DNA is assembled from the template."), ("result", "The result is two DNA molecules.")]),
        ("Bayes' theorem", [("prior", "The prior represents belief before new evidence."), ("likelihood", "The likelihood measures how compatible evidence is with a hypothesis."), ("posterior", "The posterior updates belief after evidence.")]),
        ("Opportunity cost", [("choice", "Choosing one option means giving up alternatives."), ("next best alternative", "Opportunity cost is the value of the next best alternative forgone.")]),
    ]
    for topic, pairs in topics:
        a = answer(topic, [{"name": n, "explanation": e} for n, e in pairs])
        plan = build_teaching_plan(a)
        assert not validate_teaching_plan(plan, a)
        raw = {"meta": {"title": topic}, "scenes": [
            {"id": f"raw-{i}", "purpose": "teaching", "duration": 5, "narration": e, "objects": [{"type": "text", "x": 90, "y": 80, "text": n, "size": 34}]}
            for i, (n, e) in enumerate(pairs)
        ]}
        out = compile_story(topic, raw, answer_ir=a, teaching_plan=plan)
        gate = evaluate_coverage(topic, out, a)
        assert gate["ok"], (topic, gate)
        assert [c["concept_id"] for c in next(o for s in out["scenes"] for o in s["objects"] if o.get("type") == "summary_board")["cards"]] == [c["id"] for c in a["concepts"]]

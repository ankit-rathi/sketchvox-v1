"""Offline SketchVox Teaching Director.

The director is deliberately story-first: it creates a hook, a misconception or
problem, a mechanism, a demonstration, and a takeaway. It uses deterministic
facts for built-in exemplars so the renderer can be used without a paid model.
"""
from __future__ import annotations
import re
from .visual_grammar import classify_topic, grammar_for

BLUE="#2563D8"; GREEN="#2F8F63"; ORANGE="#E09A2D"; RED="#C94C4C"

def build_plan(prompt:str)->dict:
    topic=(prompt or "").strip(); low=topic.lower(); kind=classify_topic(topic); title=topic[:72] or "Concept"
    if re.search(r"\bchatgpt\b", low) or "how chatgpt works" in low or "how does chatgpt work" in low:
        return chatgpt_plan()
    if re.search(r"\brag\b", low) or "retrieval augmented" in low or "retrieval-augmented" in low:
        return rag_plan()
    if ("bmr" in low) or ("basal metabolic rate" in low):
        return bmr_plan()
    if "compound" in low and "interest" in low:
        return compound_interest_plan()
    if "etf" in low:
        return etf_plan()
    if re.search(r"\bp/?e\b", low) or "price earnings" in low or "price-to-earnings" in low:
        return pe_ratio_plan()
    if "moving average" in low:
        return moving_average_plan()
    return generic_plan(title,kind)

def generic_plan(title,kind):
    scenes=[
      {"id":"hook","duration":4.5,"narration":f"Let's make {title} intuitive.","objects":[
        {"id":"hook-title","type":"text","x":90,"y":85,"text":title,"size":52,"bold":True,"start":0.2,"duration":1.2,"color":"#242424"},
        {"type":"question","x":620,"y":250,"scale":1.0,"start":1.7,"duration":0.9,"color":BLUE},
        {"type":"text","x":500,"y":430,"text":"What is really happening?","size":34,"start":2.6,"duration":1.0,"color":BLUE,"underline":True}
      ],"camera":{"enabled":True,"start_zoom":1.0,"end_zoom":1.04,"target":"hook-title"}},
      {"id":"mechanism","duration":6,"narration":"Start with the mechanism: something goes in, a transformation happens, and a result comes out.","clear_board":True,"transition":"wipe","objects":[
        {"type":"text","x":85,"y":75,"text":"THE MECHANISM","size":40,"bold":True,"start":0.15,"duration":0.8},
        {"type":"circle","x":250,"y":285,"r":62,"start":0.8,"duration":0.8},
        {"type":"arrow","x":315,"y":285,"x2":545,"y2":285,"start":1.8,"duration":0.65,"color":BLUE},
        {"type":"circle","x":650,"y":285,"r":62,"start":2.7,"duration":0.8,"color":BLUE},
        {"type":"arrow","x":715,"y":285,"x2":945,"y2":285,"start":3.7,"duration":0.65,"color":BLUE},
        {"type":"circle","x":1050,"y":285,"r":62,"start":4.35,"duration":0.75},
        {"type":"text","x":210,"y":410,"text":"input","size":30,"start":4.1,"duration":0.45},
        {"type":"text","x":570,"y":410,"text":"transformation","size":30,"start":4.45,"duration":0.6,"color":BLUE},
        {"type":"text","x":995,"y":410,"text":"result","size":30,"start":5.0,"duration":0.45}
      ]},
      {"id":"takeaway","duration":5,"narration":f"The useful mental model is to remember the mechanism behind {title}.","clear_board":True,"transition":"wipe","objects":[
        {"type":"lightbulb","x":300,"y":275,"scale":1.0,"start":0.35,"duration":0.9,"color":ORANGE},
        {"type":"text","x":410,"y":225,"text":"Understand the mechanism.","size":44,"bold":True,"start":1.25,"duration":1.1},
        {"type":"check","x":520,"y":380,"scale":1.25,"start":2.7,"duration":0.7,"color":GREEN},
        {"type":"text","x":610,"y":360,"text":"Then the jargon becomes easier.","size":32,"start":3.2,"duration":0.8,"color":GREEN}
      ]}
    ]
    scenes.append(_summary_scene(title,"The three ideas to keep from the explanation",[
        {"title":"THE QUESTION","takeaway":f"Start by asking what {title} is trying to explain.","icon":"question"},
        {"title":"THE MECHANISM","takeaway":"Follow the transformation from input to output.","icon":"mechanism","color":BLUE},
        {"title":"THE RESULT","takeaway":"Remember what the mechanism produces and why it matters.","icon":"result","color":GREEN}
    ]))
    return {"meta":{"title":title,"grammar":kind,"grammar_sequence":grammar_for(title),"story_version":"4.5"},"scenes":scenes}

def _summary_scene(title, subtitle, cards, duration=None):
    # The summary board is itself narrated. A single sentence is not enough to
    # justify five cards, and it caused the old board to linger after the voice
    # had finished. Build a concise spoken recap from the same card content.
    count=len(cards)
    label="key takeaway" if count == 1 else "key takeaways"
    intro=f"Here are {count} {label} from {title}."
    parts=[]
    for i,card in enumerate(cards,1):
        parts.append(f"Number {i}, {card.get('title','').lower()}: {card.get('takeaway','')}")
    narration=" ".join([intro]+parts)
    # This is only the silent-render fallback. A real voiceover pass replaces it
    # with measured scene audio duration and proportionally retimes the board.
    if duration is None:
        duration=max(6.5, min(10.0, 0.20*len(narration.split())+3.0))
    return {"id":"summary","duration":round(duration,2),"narration":narration,"clear_board":True,"transition":"wipe","objects":[
        {"type":"summary_board","x":0,"y":0,"width":1280,"height":720,"start":0.1,"duration":max(0.5,duration-0.35),
         "title":f"{len(cards)} KEY TAKEAWAYS — {title.upper()}","subtitle":subtitle,"cards":cards,"reveal_seconds":max(3.5, 1.25*len(cards)+1.5)}
    ]}



def chatgpt_plan():
    """Mechanism-first visual grammar for explaining ChatGPT to beginners.

    The lesson intentionally describes the observable high-level mechanism rather
    than claiming a literal internal trace of a proprietary model.
    """
    scenes=[
      {"id":"question","purpose":"hook","duration":5.0,"narration":"You type a question. What happens between your message and the answer you see?","objects":[
        {"type":"text","x":88,"y":72,"text":"HOW CHATGPT WORKS","size":44,"bold":True,"start":0.1,"duration":0.8},
        {"type":"person","x":130,"y":255,"scale":0.75,"start":0.75,"duration":0.8},
        {"type":"round_rect","x":310,"y":190,"x2":720,"y2":405,"start":1.45,"duration":0.8,"color":"#4F46E5","stroke":4,"hand_follow":False},
        {"type":"text","x":350,"y":255,"text":"Explain compound interest","size":26,"start":2.25,"duration":0.9},
        {"type":"arrow","x":735,"y":300,"x2":930,"y2":300,"start":3.3,"duration":0.6,"color":"#4F46E5"},
        {"type":"robot","x":1010,"y":285,"scale":0.9,"start":3.95,"duration":0.8,"color":"#4F46E5"}
      ]},
      {"id":"tokens","purpose":"step_1","duration":5.5,"narration":"First, the text is represented as tokens, small pieces the model can process as numerical representations.","clear_board":True,"transition":"wipe","objects":[
        {"type":"text","x":85,"y":70,"text":"1 — REPRESENT THE TEXT","size":40,"bold":True,"start":0.1,"duration":0.8},
        {"type":"speech_bubble","x":120,"y":205,"width":420,"height":160,"text":"What happens next?","size":34,"start":0.9,"duration":0.8,"color":"#4F46E5"},
        {"type":"arrow","x":585,"y":285,"x2":710,"y2":285,"start":2.15,"duration":0.5,"color":"#4F46E5"},
        {"type":"token_strip","x":735,"y":215,"tokens":["WHAT","HAPPENS","NEXT"],"scale":0.92,"start":2.75,"duration":1.2,"token_colors":["#4F46E5","#059669","#D97706"]},
        {"type":"text","x":790,"y":350,"text":"TOKENS","size":34,"bold":True,"start":4.35,"duration":0.55,"color":"#059669"}
      ]},
      {"id":"context","purpose":"step_2","duration":5.5,"narration":"Next, the model considers the tokens in context, including the earlier parts of the conversation and the instructions it receives.","clear_board":True,"transition":"wipe","objects":[
        {"type":"text","x":85,"y":70,"text":"2 — USE CONTEXT","size":40,"bold":True,"start":0.1,"duration":0.8},
        {"type":"round_rect","x":120,"y":175,"x2":1125,"y2":455,"start":0.85,"duration":0.8,"color":"#4F46E5","stroke":4,"hand_follow":False},
        {"type":"text","x":165,"y":215,"text":"earlier conversation","size":32,"bold":True,"start":1.75,"duration":0.65,"color":"#4F46E5"},
        {"type":"text","x":165,"y":290,"text":"+ current question","size":32,"bold":True,"start":2.45,"duration":0.65,"color":"#059669"},
        {"type":"text","x":165,"y":365,"text":"+ instructions","size":32,"bold":True,"start":3.15,"duration":0.65,"color":"#D97706"},
        {"type":"arrow","x":700,"y":315,"x2":850,"y2":315,"start":3.9,"duration":0.55,"color":"#4F46E5"},
        {"type":"brain","x":960,"y":300,"scale":1.0,"start":4.55,"duration":0.75,"color":"#4F46E5"}
      ]},
      {"id":"predict","purpose":"step_3","duration":6.0,"narration":"Then the model predicts what token should come next, using patterns learned during training. It repeats this step to build the response token by token.","clear_board":True,"transition":"wipe","objects":[
        {"type":"text","x":85,"y":70,"text":"3 — PREDICT THE NEXT TOKEN","size":39,"bold":True,"start":0.1,"duration":0.8},
        {"type":"token_strip","x":120,"y":235,"tokens":["The","answer","is"],"scale":0.82,"start":0.9,"duration":1.0,"token_colors":["#4F46E5","#4F46E5","#4F46E5"]},
        {"type":"arrow","x":570,"y":270,"x2":730,"y2":270,"start":2.25,"duration":0.55,"color":"#059669"},
        {"type":"token_strip","x":770,"y":215,"tokens":["built","one","token","at","a","time"],"scale":0.62,"start":2.95,"duration":1.65,"token_colors":["#059669","#D97706","#4F46E5"]},
        {"type":"highlight_ring","x":1040,"y":365,"r":86,"start":4.85,"duration":0.55,"color":"#D97706","allow_overlap":True},
        {"type":"text","x":930,"y":485,"text":"REPEAT","size":32,"bold":True,"start":5.15,"duration":0.55,"color":"#059669"}
      ]},
      {"id":"answer","purpose":"result","duration":5.2,"narration":"Those generated tokens are decoded back into readable text, and the completed response is shown to you.","clear_board":True,"transition":"wipe","objects":[
        {"type":"text","x":85,"y":70,"text":"4 — SHOW THE RESPONSE","size":40,"bold":True,"start":0.1,"duration":0.8},
        {"type":"round_rect","x":130,"y":190,"x2":560,"y2":430,"start":0.9,"duration":0.8,"color":"#059669","stroke":4},
        {"type":"text","x":185,"y":250,"text":"tokens → text","size":34,"bold":True,"start":1.8,"duration":0.8,"color":"#059669"},
        {"type":"arrow","x":590,"y":315,"x2":760,"y2":315,"start":2.75,"duration":0.55,"color":"#4F46E5"},
        {"type":"document","x":865,"y":225,"scale":1.0,"start":3.45,"duration":0.8,"color":"#4F46E5"},
        {"type":"text","x":790,"y":465,"text":"the answer you read","size":32,"bold":True,"start":4.35,"duration":0.65,"color":"#4F46E5"}
      ]},
    ]
    scenes.append(_summary_scene("How ChatGPT works","A high-level mental model of the path from question to response",[
        {"title":"REPRESENT","phrase":"TEXT → TOKENS","support":"Turn text into model-readable pieces.","icon":"window"},
        {"title":"USE CONTEXT","phrase":"CONTEXT MATTERS","support":"Past messages + question + instructions.","icon":"context","color":BLUE},
        {"title":"PREDICT + REPEAT","phrase":"NEXT TOKEN → NEXT TOKEN","support":"Build the response step by step.","icon":"generate","color":GREEN},
        {"title":"SHOW TEXT","phrase":"TOKENS → TEXT","support":"Turn generated pieces into the answer you read.","icon":"result","color":GREEN}
    ]))
    return {"meta":{"title":"How ChatGPT works","grammar":"ai","story_version":"4.4"},"scenes":scenes}

def rag_plan():
    scenes=[
      {"id":"hook","duration":5.2,"narration":"An AI can be brilliant and still miss the answer when the information lives in your private documents.","objects":[
        {"type":"robot","x":245,"y":250,"scale":1.0,"start":0.2,"duration":0.9,"color":BLUE},
        {"type":"text","x":430,"y":105,"text":"The AI knows a lot…","size":46,"bold":True,"start":0.7,"duration":1.0},
        {"type":"text","x":350,"y":170,"text":"but not your private docs.","size":32,"bold":True,"start":1.55,"duration":1.0,"color":RED},
        {"type":"document","x":850,"y":250,"scale":1.05,"start":2.45,"duration":0.9},
        {"type":"lock","x":930,"y":305,"scale":0.65,"start":3.25,"duration":0.65,"color":RED},
        {"type":"text","x":780,"y":450,"text":"So where should it look?","size":34,"start":3.8,"duration":0.8,"color":BLUE}
      ]},
      {"id":"retrieve","duration":6,"narration":"First, RAG searches the knowledge base for passages that matter to the question.","clear_board":True,"transition":"wipe","objects":[
        {"type":"text","x":80,"y":70,"text":"STEP 1 — RETRIEVE","size":38,"bold":True,"start":0.15,"duration":0.8},
        {"type":"text","x":95,"y":155,"text":"What is our refund policy?","size":38,"start":0.9,"duration":1.0},
        {"type":"magnifier","x":380,"y":305,"scale":1.0,"start":1.95,"duration":0.8,"color":BLUE},
        {"type":"arrow","x":450,"y":305,"x2":630,"y2":305,"start":2.7,"duration":0.6,"color":BLUE},
        {"type":"database","x":735,"y":250,"scale":1.1,"start":3.35,"duration":0.9},
        {"type":"document","x":900,"y":385,"scale":0.65,"start":4.1,"duration":0.7,"color":GREEN},
        {"type":"document","x":985,"y":410,"scale":0.65,"start":4.4,"duration":0.7,"color":GREEN},
        {"type":"text","x":820,"y":555,"text":"relevant passages","size":30,"start":5.0,"duration":0.6,"color":GREEN}
      ]},
      {"id":"augment","duration":6,"narration":"Second, those passages are added to the question as context, so the model has evidence to use.","clear_board":True,"transition":"wipe","objects":[
        {"type":"text","x":80,"y":70,"text":"STEP 2 — AUGMENT","size":38,"bold":True,"start":0.15,"duration":0.8},
        {"type":"document","x":140,"y":215,"scale":0.9,"start":0.85,"duration":0.8},
        {"type":"document","x":140,"y":365,"scale":0.9,"start":1.55,"duration":0.8},
        {"type":"arrow","x":330,"y":305,"x2":520,"y2":305,"start":2.35,"duration":0.6,"color":BLUE},
        {"type":"round_rect","x":555,"y":185,"x2":1120,"y2":455,"start":3.0,"duration":0.9,"color":BLUE,"stroke":5},
        {"type":"text","x":585,"y":225,"text":"question + retrieved context","size":34,"bold":True,"start":3.65,"duration":0.9,"color":BLUE},
        {"type":"highlight","x":610,"y":315,"width":430,"height":58,"start":4.45,"duration":0.2},
        {"type":"text","x":625,"y":320,"text":"evidence the model can cite","size":30,"start":4.6,"duration":0.8,"color":GREEN}
      ]},
      {"id":"generate","duration":6,"narration":"Finally, the language model generates an answer using that retrieved context.","clear_board":True,"transition":"wipe","objects":[
        {"type":"text","x":80,"y":70,"text":"STEP 3 — GENERATE","size":38,"bold":True,"start":0.15,"duration":0.8},
        {"type":"round_rect","x":120,"y":190,"x2":460,"y2":470,"start":0.8,"duration":0.8,"color":"#242424"},
        {"type":"text","x":190,"y":270,"text":"CONTEXT","size":38,"bold":True,"start":1.55,"duration":0.7,"color":BLUE},
        {"type":"arrow","x":490,"y":330,"x2":700,"y2":330,"start":2.4,"duration":0.6,"color":BLUE},
        {"type":"robot","x":790,"y":310,"scale":1.0,"start":3.15,"duration":0.9,"color":BLUE},
        {"type":"arrow","x":870,"y":440,"x2":1020,"y2":440,"start":4.15,"duration":0.55,"color":GREEN},
        {"type":"text","x":900,"y":470,"text":"grounded answer","size":31,"bold":True,"start":4.65,"duration":0.7,"color":GREEN}
      ]},
      {"id":"mental-model","duration":5.2,"narration":"The mental model is simple: retrieve the right evidence, then generate from it.","clear_board":True,"transition":"wipe","objects":[
        {"type":"text","x":95,"y":75,"text":"THE MENTAL MODEL","size":42,"bold":True,"start":0.15,"duration":0.85},
        {"type":"database","x":170,"y":265,"scale":0.85,"start":1.0,"duration":0.8},
        {"type":"arrow","x":300,"y":300,"x2":475,"y2":300,"start":1.8,"duration":0.55,"color":BLUE},
        {"type":"text","x":490,"y":265,"text":"retrieve","size":40,"bold":True,"start":2.25,"duration":0.7,"color":BLUE},
        {"type":"arrow","x":665,"y":300,"x2":840,"y2":300,"start":2.95,"duration":0.55,"color":GREEN},
        {"type":"text","x":855,"y":265,"text":"generate","size":40,"bold":True,"start":3.4,"duration":0.7,"color":GREEN},
        {"type":"check","x":1040,"y":390,"scale":1.15,"start":4.1,"duration":0.7,"color":GREEN},
        {"type":"text","x":160,"y":500,"text":"Right evidence first. Better-grounded answers next.","size":34,"bold":True,"start":4.35,"duration":0.75}
      ]}
    ]
    scenes.append(_summary_scene("RAG","The three-step flow from private knowledge to a grounded answer",[
        {"title":"RETRIEVE","takeaway":"Find the passages that matter to the question.","icon":"retrieve"},
        {"title":"AUGMENT","takeaway":"Put the retrieved evidence beside the question.","icon":"augment","color":BLUE},
        {"title":"GENERATE","takeaway":"The model writes the answer using that supplied context.","icon":"generate","color":GREEN}
    ]))
    return {"meta":{"title":"RAG — retrieve before you generate","grammar":"ai","story_version":"3.0"},"scenes":scenes}



def bmr_plan():
    """Topic-specific visual exemplar for BMR; geometry is deterministic."""
    scenes=[
      {"id":"hook","purpose":"hook","duration":5.0,"narration":"Your body uses energy even when you are resting. BMR is the baseline amount needed to keep essential functions running.","objects":[
        {"type":"text","x":80,"y":72,"text":"WHAT IS BMR?","size":46,"bold":True,"start":0.1,"duration":0.7},
        {"type":"person","x":170,"y":250,"scale":1.0,"start":0.8,"duration":0.8},
        {"type":"arrow","x":330,"y":320,"x2":535,"y2":320,"start":1.8,"duration":0.6},
        {"type":"text","x":565,"y":245,"text":"energy at rest","size":40,"bold":True,"start":2.5,"duration":0.8},
        {"type":"lightbulb","x":1010,"y":270,"scale":0.9,"start":3.5,"duration":0.8}
      ]},
      {"id":"definition","purpose":"definition","duration":6.2,"narration":"Basal metabolic rate is the amount of energy your body needs at rest to keep essential functions running, such as breathing and circulation.","clear_board":True,"transition":"wipe","objects":[
        {"type":"text","x":80,"y":70,"text":"BMR = BASELINE ENERGY NEED","size":39,"bold":True,"start":0.1,"duration":0.7},
        {"type":"round_rect","x":95,"y":165,"x2":520,"y2":470,"start":0.9,"duration":0.7},
        {"type":"person","x":220,"y":240,"scale":0.9,"start":1.7,"duration":0.8},
        {"type":"text","x":150,"y":395,"text":"at rest","size":34,"bold":True,"start":2.5,"duration":0.6},
        {"type":"arrow","x":555,"y":320,"x2":720,"y2":320,"start":3.2,"duration":0.55},
        {"type":"round_rect","x":750,"y":165,"x2":1170,"y2":470,"start":3.7,"duration":0.7},
        {"type":"text","x":820,"y":205,"text":"ESSENTIAL FUNCTIONS","size":30,"bold":True,"start":4.45,"duration":0.6},
        {"type":"text","x":835,"y":285,"text":"breathing","size":31,"start":5.05,"duration":0.45},
        {"type":"text","x":835,"y":340,"text":"circulation","size":31,"start":5.35,"duration":0.45},
        {"type":"text","x":835,"y":395,"text":"basic body processes","size":29,"start":5.65,"duration":0.5}
      ]},
      {"id":"interpretation","purpose":"interpretation","duration":5.8,"narration":"BMR is a baseline, not your total daily calorie burn. Normal activity and digestion require additional energy beyond this baseline.","clear_board":True,"transition":"wipe","objects":[
        {"type":"text","x":80,"y":70,"text":"BMR IS NOT TOTAL DAILY BURN","size":38,"bold":True,"start":0.1,"duration":0.7},
        {"type":"round_rect","x":120,"y":190,"x2":510,"y2":470,"start":0.85,"duration":0.7},
        {"type":"text","x":185,"y":235,"text":"BMR","size":45,"bold":True,"start":1.65,"duration":0.65},
        {"type":"text","x":170,"y":325,"text":"baseline","size":34,"start":2.35,"duration":0.55},
        {"type":"arrow","x":540,"y":330,"x2":710,"y2":330,"start":2.95,"duration":0.55},
        {"type":"round_rect","x":750,"y":190,"x2":1160,"y2":470,"start":3.5,"duration":0.7},
        {"type":"text","x":800,"y":235,"text":"TOTAL DAILY ENERGY","size":31,"bold":True,"start":4.25,"duration":0.55},
        {"type":"text","x":825,"y":330,"text":"BMR + activity + digestion","size":28,"start":4.9,"duration":0.55}
      ]},
      {"id":"mental-model","purpose":"takeaway","duration":5.2,"narration":"Think of BMR as your body's baseline energy budget: what it needs at rest before the extra energy used by everyday life.","clear_board":True,"transition":"wipe","objects":[
        {"type":"text","x":90,"y":75,"text":"MENTAL MODEL","size":43,"bold":True,"start":0.1,"duration":0.7},
        {"type":"wallet","x":160,"y":245,"scale":1.0,"start":1.0,"duration":0.8},
        {"type":"arrow","x":300,"y":300,"x2":480,"y2":300,"start":1.8,"duration":0.55},
        {"type":"text","x":505,"y":245,"text":"BASELINE ENERGY BUDGET","size":39,"bold":True,"start":2.35,"duration":0.8},
        {"type":"text","x":520,"y":355,"text":"at rest → essential functions","size":31,"start":3.25,"duration":0.55},
        {"type":"check","x":1030,"y":430,"scale":0.9,"start":4.1,"duration":0.7}
      ]}
    ]
    scenes.append(_summary_scene("BMR","Baseline energy needed at rest, and what it is not",[
        {"title":"BASELINE ENERGY","takeaway":"BMR is the energy your body needs at rest for essential functions.","icon":"energy"},
        {"title":"ESSENTIAL FUNCTIONS","takeaway":"That baseline supports processes such as breathing and circulation.","icon":"body"},
        {"title":"NOT TOTAL DAILY BURN","takeaway":"BMR is only a baseline; everyday activity and digestion add energy needs.","icon":"compare"},
        {"title":"MENTAL MODEL","takeaway":"Think of BMR as your body's baseline energy budget.","icon":"mental"}
    ]))
    return {"meta":{"title":"What is BMR (Basal Metabolic Rate)?","grammar":"definition","story_version":"5.4","benchmark":"bmr"},"scenes":scenes}

def compound_interest_plan():
    """Polished finance exemplar: concrete transformations, comparison and curve."""
    scenes=[
      {"id":"hook","duration":5.2,"narration":"You invest ten thousand rupees. At ten percent a year, the first return is one thousand rupees.","objects":[
        {"type":"text","x":90,"y":76,"text":"COMPOUND INTEREST","size":42,"bold":True,"start":0.1,"duration":0.75,"color":"#20242B"},
        {"type":"person","x":120,"y":280,"scale":0.72,"start":0.65,"duration":0.75,"color":"#20242B"},
        {"type":"round_rect","x":300,"y":190,"x2":610,"y2":405,"start":1.15,"duration":0.8,"color":"#4F46E5","stroke":4},
        {"type":"money","x":355,"y":245,"scale":0.92,"start":1.55,"duration":0.9,"label":"₹10,000","color":"#20242B"},
        {"type":"text","x":680,"y":225,"text":"10% / YEAR","size":40,"bold":True,"start":2.35,"duration":0.75,"color":"#4F46E5"},
        {"type":"arrow","x":690,"y":355,"x2":905,"y2":355,"start":3.1,"duration":0.6,"color":"#4F46E5"},
        {"type":"coin","x":970,"y":320,"scale":0.8,"start":3.55,"duration":0.7,"color":"#D97706"},
        {"type":"text","x":1010,"y":415,"text":"₹1,000 return","size":30,"bold":True,"start":4.15,"duration":0.7,"color":"#D97706"}
      ]},
      {"id":"year1","duration":5.4,"narration":"In year one, ten percent of ten thousand is one thousand, so the balance becomes eleven thousand.","clear_board":True,"transition":"wipe","objects":[
        {"type":"text","x":88,"y":70,"text":"YEAR 1 — ADD THE RETURN","size":39,"bold":True,"start":0.1,"duration":0.7},
        {"type":"round_rect","x":90,"y":185,"x2":390,"y2":455,"start":0.8,"duration":0.75,"color":"#4F46E5","stroke":4},
        {"type":"text","x":155,"y":225,"text":"START","size":25,"bold":True,"start":1.55,"duration":0.45,"color":"#64748B"},
        {"type":"text","x":145,"y":285,"text":"₹10,000","size":48,"bold":True,"start":1.95,"duration":0.75,"color":"#20242B"},
        {"type":"arrow","x":415,"y":315,"x2":585,"y2":315,"start":2.65,"duration":0.55,"color":"#4F46E5"},
        {"type":"text","x":445,"y":250,"text":"+ ₹1,000","size":34,"bold":True,"start":3.05,"duration":0.6,"color":"#D97706"},
        {"type":"round_rect","x":625,"y":185,"x2":1000,"y2":455,"start":3.35,"duration":0.75,"color":"#059669","stroke":4},
        {"type":"text","x":690,"y":225,"text":"NEW BASE","size":25,"bold":True,"start":4.1,"duration":0.45,"color":"#64748B"},
        {"type":"money","x":705,"y":285,"scale":1.02,"start":4.45,"duration":0.75,"label":"₹11,000","color":"#059669"},
        {"type":"text","x":680,"y":485,"text":"the base is now bigger","size":26,"bold":True,"start":4.55,"duration":0.7,"color":"#059669"}
      ]},
      {"id":"year2","duration":5.4,"narration":"In year two, the same ten percent is applied to eleven thousand, not ten thousand. The return is now one thousand one hundred.","clear_board":True,"transition":"wipe","objects":[
        {"type":"text","x":88,"y":70,"text":"YEAR 2 — SAME RATE, BIGGER BASE","size":37,"bold":True,"start":0.1,"duration":0.7},
        {"type":"round_rect","x":90,"y":190,"x2":500,"y2":455,"start":0.8,"duration":0.75,"color":"#4F46E5","stroke":4},
        {"type":"text","x":145,"y":225,"text":"10% × ₹11,000","size":40,"bold":True,"start":1.6,"duration":0.8,"color":"#4F46E5"},
        {"type":"text","x":160,"y":305,"text":"= ₹1,100","size":46,"bold":True,"start":2.45,"duration":0.75,"color":"#D97706"},
        {"type":"arrow","x":530,"y":320,"x2":700,"y2":320,"start":3.1,"duration":0.55,"color":"#059669"},
        {"type":"round_rect","x":735,"y":190,"x2":1110,"y2":455,"start":3.45,"duration":0.75,"color":"#059669","stroke":4},
        {"type":"text","x":795,"y":230,"text":"NEW BALANCE","size":25,"bold":True,"start":4.15,"duration":0.45,"color":"#64748B"},
        {"type":"money","x":815,"y":285,"scale":0.98,"start":4.55,"duration":0.75,"label":"₹12,100","color":"#059669"},
        {"type":"text","x":170,"y":500,"text":"Return earns return.","size":34,"bold":True,"start":4.65,"duration":0.65,"color":"#059669","underline":True}
      ]},
      {"id":"curve","duration":6.0,"narration":"Repeat that process for many years. Each year starts from a larger base, so the gains get larger and the growth curve bends upward.","clear_board":True,"transition":"wipe","objects":[
        {"type":"text","x":88,"y":68,"text":"WHY THE CURVE BENDS","size":40,"bold":True,"start":0.1,"duration":0.7},
        {"type":"chart","x":105,"y":165,"width":820,"height":360,"values":[10000,11000,12100,13310,14641,16105,17716,19487,21436,23579,25937],"start":0.9,"duration":2.9,"accent":"#4F46E5","y_ticks":[10000,15000,20000,25000],"x_labels":["0","2","4","6","8","10"]},
        {"type":"trend","x":995,"y":235,"scale":1.0,"start":3.9,"duration":0.8,"color":"#4F46E5"},
        {"type":"text","x":985,"y":355,"text":"larger base","size":31,"bold":True,"start":4.65,"duration":0.6,"color":"#059669"},
        {"type":"text","x":985,"y":405,"text":"→ larger gain","size":31,"bold":True,"start":5.05,"duration":0.65,"color":"#D97706"}
      ]},
      {"id":"formula","duration":5.4,"narration":"The formula summarizes the same idea: your final amount depends on the starting principal, the rate, how often interest compounds, and time.","clear_board":True,"transition":"wipe","objects":[
        {"type":"text","x":88,"y":68,"text":"THE MENTAL MODEL","size":40,"bold":True,"start":0.1,"duration":0.7},
        {"type":"round_rect","x":115,"y":180,"x2":1160,"y2":355,"start":0.85,"duration":0.75,"color":"#4F46E5","stroke":4},
        {"type":"text","x":210,"y":230,"text":"A = P (1 + r / n) ^ (n t)","size":48,"bold":True,"start":1.7,"duration":1.1,"color":"#4F46E5"},
        {"type":"text","x":150,"y":420,"text":"P = starting money","size":28,"bold":True,"start":3.05,"duration":0.55,"color":"#20242B"},
        {"type":"text","x":430,"y":420,"text":"r = rate","size":28,"bold":True,"start":3.45,"duration":0.5,"color":"#059669"},
        {"type":"text","x":650,"y":420,"text":"n = compounding frequency","size":28,"bold":True,"start":3.85,"duration":0.6,"color":"#D97706"},
        {"type":"text","x":1040,"y":420,"text":"t = time","size":28,"bold":True,"start":4.25,"duration":0.5,"color":"#DB2777"},
        {"type":"check","x":585,"y":535,"scale":0.75,"start":4.75,"duration":0.55,"color":"#059669","allow_overlap":True},
        {"type":"text","x":625,"y":520,"text":"same mechanism, summarized","size":28,"start":4.82,"duration":0.48,"color":"#059669"}
      ]}
    ]
    scenes.append(_summary_scene("Compound Interest","The three ideas that explain why the curve bends upward",[
        {"title":"STARTING BASE","takeaway":"Your first return is earned on the original ₹10,000.","icon":"base"},
        {"title":"RETURN ON RETURN","takeaway":"The next return applies to ₹11,000, so the gain gets larger.","icon":"return_growth","color":"#059669"},
        {"title":"THE CURVE","takeaway":"A growing base creates growing gains at the same rate.","icon":"curve","color":"#4F46E5"}
    ]))
    return {"meta":{"title":"Why compound interest bends the curve","grammar":"finance","story_version":"4.5"},"scenes":scenes}



def pe_ratio_plan():
    """v5 golden visual benchmark: construction -> transformation -> comparison."""
    scenes=[
      {"id":"hook","purpose":"hook","visual_archetype":"comparison","duration":5.2,"narration":"Two companies can have the same share price and still have very different P/E ratios. Let’s see why.","teaching_claim":"Same price does not imply the same P/E because earnings can differ.","objects":[
        {"id":"pe-title","type":"text","x":82,"y":58,"text":"SAME PRICE ≠ SAME P/E","size":48,"bold":True,"start":0.15,"duration":0.95,"semantic_role":"headline"},
        {"id":"a-price","type":"money","x":190,"y":245,"scale":0.9,"label":"₹100","start":1.35,"duration":0.8,"color":BLUE},
        {"id":"b-price","type":"money","x":770,"y":245,"scale":0.9,"label":"₹100","start":2.15,"duration":0.8,"color":BLUE},
        {"id":"same-a","type":"text","x":210,"y":410,"text":"COMPANY A","size":30,"bold":True,"start":3.05,"duration":0.6,"color":BLUE},
        {"id":"same-b","type":"text","x":790,"y":410,"text":"COMPANY B","size":30,"bold":True,"start":3.55,"duration":0.6,"color":GREEN},
        {"id":"brace","type":"arrow","x":475,"y":300,"x2":685,"y2":300,"start":4.15,"duration":0.55,"color":ORANGE},
        {"id":"same-label","type":"text","x":505,"y":245,"text":"same price","size":27,"bold":True,"start":4.25,"duration":0.55,"color":ORANGE}]},
      {"id":"earnings","purpose":"transformation","visual_archetype":"comparison","duration":6.0,"narration":"Now look underneath the price. Company A earns ten rupees per share, while Company B earns five.","clear_board":True,"transition":"wipe","teaching_claim":"Different earnings create different denominators for P/E.","objects":[
        {"id":"earn-head","type":"text","x":82,"y":60,"text":"LOOK UNDER THE PRICE","size":42,"bold":True,"start":0.12,"duration":0.8},
        {"id":"a-box","type":"round_rect","x":110,"y":175,"x2":555,"y2":530,"start":0.7,"duration":0.8,"color":BLUE},
        {"id":"b-box","type":"round_rect","x":725,"y":175,"x2":1170,"y2":530,"start":0.9,"duration":0.8,"color":GREEN},
        {"id":"a-label","type":"text","x":205,"y":210,"text":"COMPANY A","size":34,"bold":True,"start":1.6,"duration":0.55,"color":BLUE},
        {"id":"b-label","type":"text","x":820,"y":210,"text":"COMPANY B","size":34,"bold":True,"start":1.8,"duration":0.55,"color":GREEN},
        {"id":"a-p","type":"money","x":165,"y":275,"scale":0.55,"label":"₹100","start":2.2,"duration":0.65,"color":BLUE},
        {"id":"a-div","type":"text","x":300,"y":315,"text":"÷","size":48,"bold":True,"start":2.85,"duration":0.4,"color":ORANGE},
        {"id":"a-e","type":"money","x":365,"y":275,"scale":0.45,"label":"₹10","start":3.2,"duration":0.65,"color":GREEN},
        {"id":"b-p","type":"money","x":780,"y":275,"scale":0.55,"label":"₹100","start":2.5,"duration":0.65,"color":BLUE},
        {"id":"b-div","type":"text","x":915,"y":315,"text":"÷","size":48,"bold":True,"start":3.15,"duration":0.4,"color":ORANGE},
        {"id":"b-e","type":"money","x":980,"y":275,"scale":0.45,"label":"₹5","start":3.5,"duration":0.65,"color":GREEN},
        {"id":"a-note","type":"text","x":190,"y":455,"text":"EARNS ₹10","size":28,"bold":True,"start":4.0,"duration":0.55,"color":GREEN},
        {"id":"b-note","type":"text","x":800,"y":455,"text":"EARNS ₹5","size":28,"bold":True,"start":4.3,"duration":0.55,"color":GREEN}]},
      {"id":"formula","purpose":"calculation","visual_archetype":"transformation","duration":6.0,"narration":"P/E is simply price divided by earnings. For Company A, one hundred divided by ten gives ten times. For Company B, one hundred divided by five gives twenty times.","clear_board":True,"transition":"wipe","teaching_claim":"P/E equals Price divided by Earnings; the denominator changes the multiple.","objects":[
        {"id":"formula-head","type":"text","x":82,"y":58,"text":"BUILD THE MULTIPLE","size":44,"bold":True,"start":0.12,"duration":0.75},
        {"id":"formula","type":"ratio","x":385,"y":165,"width":510,"top":"PRICE","bottom":"EARNINGS","result":"P/E","start":0.85,"duration":1.5,"color":BLUE,"result_color":ORANGE,"top_color":BLUE,"bottom_color":GREEN},
        {"id":"eq-a","type":"text","x":145,"y":425,"text":"₹100 ÷ ₹10 = 10×","size":39,"bold":True,"start":2.7,"duration":0.9,"color":BLUE},
        {"id":"eq-b","type":"text","x":720,"y":425,"text":"₹100 ÷ ₹5 = 20×","size":39,"bold":True,"start":3.75,"duration":0.9,"color":GREEN},
        {"id":"a-ring","type":"highlight_ring","x":390,"y":450,"r":145,"start":4.75,"duration":0.5,"color":BLUE,"allow_overlap":True},
        {"id":"b-ring","type":"highlight_ring","x":960,"y":450,"r":145,"start":5.05,"duration":0.5,"color":ORANGE,"allow_overlap":True}]},
      {"id":"compare","purpose":"comparison","visual_archetype":"comparison","duration":5.4,"narration":"So the same one-hundred-rupee price can mean a ten-times P/E or a twenty-times P/E, depending on earnings. That is why P/E is useful for comparison.","clear_board":True,"transition":"wipe","teaching_claim":"P/E makes price comparable relative to earnings.","objects":[
        {"id":"compare-head","type":"text","x":82,"y":58,"text":"THE DIFFERENCE IS THE DENOMINATOR","size":38,"bold":True,"start":0.12,"duration":0.8},
        {"id":"left","type":"text","x":150,"y":210,"text":"10×","size":88,"bold":True,"start":1.05,"duration":0.9,"color":BLUE},
        {"id":"right","type":"text","x":910,"y":210,"text":"20×","size":88,"bold":True,"start":1.45,"duration":0.9,"color":ORANGE},
        {"id":"same","type":"text","x":470,"y":220,"text":"vs","size":42,"bold":True,"start":1.95,"duration":0.5,"color":ORANGE},
        {"id":"left-sub","type":"text","x":120,"y":335,"text":"₹100 price ÷ ₹10 earnings","size":30,"start":2.35,"duration":0.7,"color":BLUE},
        {"id":"right-sub","type":"text","x":780,"y":335,"text":"₹100 price ÷ ₹5 earnings","size":30,"start":2.65,"duration":0.7,"color":ORANGE},
        {"id":"arrow","type":"arrow","x":515,"y":465,"x2":760,"y2":465,"start":3.55,"duration":0.6,"color":GREEN},
        {"id":"take","type":"text","x":325,"y":500,"text":"COMPARE PRICE RELATIVE TO EARNINGS","size":31,"bold":True,"start":4.0,"duration":0.7,"color":GREEN}]},
      {"id":"mental_model","purpose":"takeaway","visual_archetype":"formula","duration":4.8,"narration":"Remember three things: price is the numerator, earnings are the denominator, and P/E is a valuation lens rather than a complete investment decision.","clear_board":True,"transition":"wipe","teaching_claim":"P/E is a comparison lens, not a complete investment thesis.","objects":[
        {"id":"mm-head","type":"text","x":82,"y":58,"text":"REMEMBER THE LENS","size":44,"bold":True,"start":0.12,"duration":0.75},
        {"id":"mm-ratio","type":"ratio","x":330,"y":160,"width":500,"top":"PRICE","bottom":"EARNINGS","result":"P/E","start":0.85,"duration":1.45,"color":BLUE,"result_color":ORANGE},
        {"id":"mm1","type":"text","x":180,"y":440,"text":"1. PRICE","size":31,"bold":True,"start":2.55,"duration":0.55,"color":BLUE},
        {"id":"mm2","type":"text","x":500,"y":440,"text":"2. EARNINGS","size":31,"bold":True,"start":2.85,"duration":0.55,"color":GREEN},
        {"id":"mm3","type":"text","x":850,"y":440,"text":"3. COMPARE","size":31,"bold":True,"start":3.15,"duration":0.55,"color":ORANGE}]}]
    scenes.append(_summary_scene('P/E Ratio','A memory board: formula → example → interpretation',[
        {"title":"THE FORMULA","phrase":"P ÷ E","support":"Price divided by earnings per share.","icon":"ratio","color":BLUE},
        {"title":"THE EXAMPLE","phrase":"10× vs 20×","support":"Same ₹100 price, different earnings, different P/E.","icon":"compare","color":ORANGE},
        {"title":"THE LENS","phrase":"COMPARE","support":"P/E is one valuation lens, not the whole decision.","icon":"magnifier","color":GREEN}]))
    return {"meta":{"title":"P/E Ratio","grammar":"finance_comparison_transformation","story_version":"5.0","benchmark":"golden_pe_ratio"},"scenes":scenes}

def etf_plan():
    scenes=[
      {"id":"hook","duration":5,"narration":"Imagine buying one basket instead of picking every item one by one.","objects":[{"type":"wallet","x":150,"y":270,"scale":0.9,"start":0.2,"duration":0.8},{"type":"text","x":360,"y":120,"text":"ONE BASKET","size":46,"bold":True,"start":0.75,"duration":0.8},{"type":"coin","x":430,"y":310,"scale":0.7,"start":1.6,"duration":0.7},{"type":"coin","x":540,"y":300,"scale":0.7,"start":2.0,"duration":0.7},{"type":"coin","x":650,"y":315,"scale":0.7,"start":2.4,"duration":0.7},{"type":"text","x":800,"y":300,"text":"many holdings","size":36,"start":3.2,"duration":0.8,"color":BLUE}]},
      {"id":"mechanism","duration":6,"narration":"An ETF packages a collection of assets into a fund whose shares trade on an exchange.","clear_board":True,"transition":"wipe","objects":[{"type":"text","x":85,"y":70,"text":"THE IDEA","size":40,"bold":True,"start":0.15,"duration":0.7},{"type":"coin","x":180,"y":240,"scale":0.75,"start":0.9,"duration":0.6},{"type":"coin","x":290,"y":300,"scale":0.75,"start":1.2,"duration":0.6},{"type":"coin","x":400,"y":240,"scale":0.75,"start":1.5,"duration":0.6},{"type":"arrow","x":480,"y":285,"x2":650,"y2":285,"start":2.3,"duration":0.6,"color":BLUE},{"type":"round_rect","x":680,"y":180,"x2":1080,"y2":390,"start":3.0,"duration":0.9,"color":BLUE},{"type":"text","x":790,"y":245,"text":"ETF","size":60,"bold":True,"start":3.8,"duration":0.7,"color":BLUE},{"type":"text","x":745,"y":335,"text":"a tradable basket","size":34,"start":4.55,"duration":0.7}]},
      {"id":"takeaway","duration":5,"narration":"The mental model: one trade gives you exposure to a basket rather than a single asset.","clear_board":True,"transition":"wipe","objects":[{"type":"text","x":100,"y":75,"text":"REMEMBER","size":42,"bold":True,"start":0.15,"duration":0.7},{"type":"wallet","x":190,"y":250,"scale":0.9,"start":1.0,"duration":0.8},{"type":"arrow","x":335,"y":300,"x2":560,"y2":300,"start":1.9,"duration":0.55,"color":BLUE},{"type":"text","x":590,"y":245,"text":"one share","size":40,"bold":True,"start":2.55,"duration":0.7},{"type":"text","x":590,"y":315,"text":"→ many underlying assets","size":34,"start":3.25,"duration":0.8,"color":GREEN},{"type":"check","x":1030,"y":420,"scale":1.0,"start":4.25,"duration":0.6,"color":GREEN}]}
    ]
    scenes.append(_summary_scene("ETF","The three ideas behind the one-share-to-many-assets mental model",[
        {"title":"ONE BASKET","takeaway":"An ETF packages multiple holdings into one fund.","icon":"basket"},
        {"title":"ONE SHARE","takeaway":"Buying a share gives you exposure to that basket.","icon":"share","color":BLUE},
        {"title":"TRADABLE WRAPPER","takeaway":"The fund structure lets the basket trade as one security.","icon":"trade","color":GREEN}
    ]))
    return {"meta":{"title":"What is an ETF?","grammar":"finance","story_version":"3.0"},"scenes":scenes}

def moving_average_plan():
    scenes=[
      {"id":"hook","duration":5,"narration":"A moving average smooths noisy data so the underlying direction is easier to see.","objects":[{"type":"chart","x":120,"y":150,"width":900,"height":350,"values":[10,16,12,20,15,24,19,28,23,31,27],"start":0.4,"duration":2.4,"accent":BLUE,"x_labels":["1","2","3","4","5","6","7","8","9","10","11"]},{"type":"text","x":100,"y":70,"text":"RAW DATA IS NOISY","size":40,"bold":True,"start":0.1,"duration":0.8},{"type":"warning","x":1055,"y":220,"scale":0.72,"start":3.1,"duration":0.7,"color":ORANGE},{"type":"text","x":1030,"y":315,"text":"too jagged","size":28,"start":3.8,"duration":0.6}]},
      {"id":"mechanism","duration":6,"narration":"For a three-point moving average, take the current value and its neighbors, then average them.","clear_board":True,"transition":"wipe","objects":[{"type":"text","x":85,"y":70,"text":"3-POINT WINDOW","size":40,"bold":True,"start":0.15,"duration":0.8},{"type":"round_rect","x":170,"y":210,"x2":470,"y2":390,"start":0.9,"duration":0.8,"color":BLUE},{"type":"text","x":235,"y":260,"text":"12 + 20 + 15","size":36,"bold":True,"start":1.8,"duration":0.8},{"type":"text","x":255,"y":320,"text":"÷ 3 = 15.7","size":34,"bold":True,"start":2.65,"duration":0.8,"color":GREEN},{"type":"arrow","x":500,"y":300,"x2":710,"y2":300,"start":3.5,"duration":0.6,"color":BLUE},{"type":"chart","x":745,"y":190,"width":380,"height":240,"values":[12,15.7,16,19.7,19.3,22.7,23.7,27,27],"start":4.0,"duration":1.2,"accent":GREEN}]},
      {"id":"takeaway","duration":5,"narration":"The result is a smoother signal that makes the direction easier to read.","clear_board":True,"transition":"wipe","objects":[{"type":"text","x":90,"y":75,"text":"SMOOTHER SIGNAL","size":42,"bold":True,"start":0.15,"duration":0.8},{"type":"chart","x":130,"y":165,"width":880,"height":340,"values":[12.7,16.0,15.7,19.7,19.3,23.7,23.3,27.3,27.0],"start":1.0,"duration":1.6,"accent":GREEN},{"type":"check","x":1080,"y":245,"scale":0.9,"start":3.0,"duration":0.6,"color":GREEN},{"type":"text","x":1020,"y":330,"text":"direction is clearer","size":26,"bold":True,"start":3.55,"duration":0.7,"color":GREEN}]}
    ]
    scenes.append(_summary_scene("Moving Average","The four ideas behind smoothing a noisy series",[
        {"title":"RAW DATA","takeaway":"Real observations can jump around from point to point.","icon":"raw_data"},
        {"title":"THE WINDOW","takeaway":"Take a fixed number of nearby observations.","icon":"window","color":BLUE},
        {"title":"AVERAGE + MOVE","takeaway":"Average the window, then shift it forward and repeat.","icon":"average","color":GREEN},
        {"title":"THE RESULT","takeaway":"The signal is smoother, so direction is easier to read.","icon":"result","color":GREEN}
    ]))
    return {"meta":{"title":"Moving average in 45 seconds","grammar":"data","story_version":"3.0"},"scenes":scenes}


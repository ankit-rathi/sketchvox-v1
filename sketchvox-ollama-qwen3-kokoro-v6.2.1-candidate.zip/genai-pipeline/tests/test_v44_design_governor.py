import json
from pathlib import Path

from whiteboard_engine.design_system import apply_visual_design, design_advisory
from whiteboard_engine.repair_governor import issue_score, is_better, provenance_stamp
from whiteboard_engine.storyboard import fallback


def test_visual_design_assigns_roles_and_style_pack():
    doc=fallback("Explain compound interest", duration=30)
    out=apply_visual_design(doc, "Explain compound interest to a beginner")
    assert out["meta"]["design_system"] == "4.5"
    assert out["meta"]["style_pack"] == "finance_editorial"
    assert all(o.get("semantic_role") for s in out["scenes"] for o in s.get("objects", []))
    assert all(o.get("font_role") for s in out["scenes"] for o in s.get("objects", []))


def test_design_advisory_is_non_blocking():
    doc=fallback("Explain a process", duration=30)
    out=apply_visual_design(doc, "Explain a process")
    report=design_advisory(out)
    assert report["contract"] == "advisory_design_qa"
    assert report["ok"]


def test_repair_score_prioritizes_errors_then_warnings():
    assert issue_score({"issues": [{"severity":"error","code":"X"}]}) > issue_score({"issues": []})
    assert is_better((0,1,0),(1,0,0))
    assert not is_better((1,0,0),(1,0,0))


def test_repair_provenance_marks_generated_objects():
    project={"scenes":[{"objects":[{"id":"a","type":"arrow","generated_by":"visual_qa_repair"}]}]}
    out=provenance_stamp(project,"v44-r1")
    obj=out["scenes"][0]["objects"][0]
    assert obj["authored"] is False
    assert obj["repair_id"] == "v44-r1"
    assert obj["repair_priority"] == "generated"

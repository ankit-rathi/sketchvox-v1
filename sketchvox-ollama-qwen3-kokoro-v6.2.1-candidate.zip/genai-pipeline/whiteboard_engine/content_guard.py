"""Content integrity guards for SketchVox generated storyboards.

The model is allowed to choose the story, but it is not allowed to choose
rendering-critical invariants such as malformed colors, mixed currencies, or
placeholder text. This module keeps those decisions deterministic.
"""
from __future__ import annotations
import re
import unicodedata
from copy import deepcopy

CURRENCIES = {
    "INR": {"symbol": "₹", "name": "Indian rupees", "aliases": ("₹", "Rs", "Rs.", "INR", "rupee", "rupees")},
    "USD": {"symbol": "$", "name": "US dollars", "aliases": ("$", "USD", "US$", "dollar", "dollars")},
    "EUR": {"symbol": "€", "name": "euros", "aliases": ("€", "EUR", "euro", "euros")},
    "GBP": {"symbol": "£", "name": "British pounds", "aliases": ("£", "GBP", "pound", "pounds")},
}

_GENERIC_PLACEHOLDERS = {"undefined", "null", "none", "nan", "n/a", "na", "<none>"}
_HEX = re.compile(r"^#?(?:[0-9a-fA-F]{6}|[0-9a-fA-F]{3})$")


def sanitize_color(value, fallback="#262626") -> str:
    if isinstance(value, (tuple, list)) and len(value) in (3, 4):
        try:
            vals=[max(0,min(255,int(v))) for v in value[:3]]
            return "#%02X%02X%02X" % tuple(vals)
        except Exception:
            return fallback
    s=str(value or "").strip()
    if _HEX.match(s):
        if not s.startswith("#"): s="#"+s
        if len(s)==4:
            s="#"+"".join(ch*2 for ch in s[1:])
        return s.upper()
    return fallback


def clean_text(value) -> str:
    if value is None:
        return ""
    s=unicodedata.normalize("NFC", str(value))
    s=s.replace("\u200b", "").replace("\ufeff", "")
    s=s.replace("\ufffd", "")
    s=re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f]", "", s)
    s=re.sub(r"\s+", " ", s).strip()
    if s.lower() in _GENERIC_PLACEHOLDERS:
        return ""
    return s


def detect_currency(prompt: str, research: str = "", requested: str | None = None) -> str:
    req=(requested or "auto").upper()
    if req in CURRENCIES:
        return req
    text=f"{prompt}\n{research}"
    if re.search(r"₹|\bINR\b|\bRs\.?\b|\brupees?\b", text, re.I): return "INR"
    if re.search(r"\$|\bUSD\b|\bUS\$\b|\bdollars?\b", text, re.I): return "USD"
    if re.search(r"€|\bEUR\b|\beuros?\b", text, re.I): return "EUR"
    if re.search(r"£|\bGBP\b|\bpounds?\b", text, re.I): return "GBP"
    # SketchVox's default educational finance convention is INR. It is explicit
    # in the metadata so users can override it rather than receiving mixed units.
    return "INR"


def normalize_currency_text(text: str, currency: str) -> str:
    s=clean_text(text)
    if not s: return s
    cur=CURRENCIES[currency]
    # Normalize common textual/symbol forms to one symbol. Word boundaries keep
    # us from replacing unrelated words such as "pressure".
    if currency == "INR":
        s=re.sub(r"\b(?:INR|Rs\.?|rupees?|rupee)\b", "₹", s, flags=re.I)
        s=s.replace("$", "₹").replace("US$", "₹").replace("USD", "₹")
    elif currency == "USD":
        s=re.sub(r"\b(?:INR|Rs\.?|rupees?|rupee)\b", "$", s, flags=re.I)
        s=s.replace("₹", "$").replace("US$", "$").replace("USD", "$")
    elif currency == "EUR":
        s=re.sub(r"\b(?:INR|Rs\.?|rupees?|rupee|USD|US\$|dollars?|dollar)\b", "€", s, flags=re.I)
        s=s.replace("₹", "€").replace("$", "€")
    elif currency == "GBP":
        s=re.sub(r"\b(?:INR|Rs\.?|rupees?|rupee|USD|US\$|dollars?|dollar)\b", "£", s, flags=re.I)
        s=s.replace("₹", "£").replace("$", "£")
    return re.sub(r"\s+", " ", s).strip()


def _spoken_currency_text(text: str, currency: str) -> str:
    """Turn display currency notation into natural narration wording."""
    s=str(text or "")
    names={"INR":"rupees","USD":"dollars","EUR":"euros","GBP":"pounds"}
    name=names[currency]
    symbol=CURRENCIES[currency]["symbol"]
    # Compact notation: ₹100 -> 100 rupees; 100 ₹ -> 100 rupees.
    s=re.sub(re.escape(symbol)+r"\s*(\d[\d,]*(?:\.\d+)?)", r"\1 "+name, s)
    s=re.sub(r"(\d[\d,]*(?:\.\d+)?)\s*"+re.escape(symbol)+r"\b", r"\1 "+name, s)
    s=s.replace(symbol, " "+name+" ")
    s=re.sub(r"\s+([,.;:!?])", r"\1", s)
    return re.sub(r"\s+", " ", s).strip()


def normalize_project_content(project: dict, currency: str = "INR") -> dict:
    out=deepcopy(project)
    meta=out.setdefault("meta", {})
    meta["currency"]=currency
    meta["currency_symbol"]=CURRENCIES[currency]["symbol"]
    meta["currency_name"]=CURRENCIES[currency]["name"]
    if isinstance(meta.get("concepts"), list):
        for c in meta["concepts"]:
            if isinstance(c, dict):
                for key in ("title", "takeaway"):
                    if key in c: c[key]=normalize_currency_text(c.get(key, ""), currency)
    for scene in out.get("scenes", []):
        if "narration" in scene:
            scene["narration"]=_spoken_currency_text(normalize_currency_text(scene.get("narration", ""), currency), currency)
        for obj in scene.get("objects", []):
            for key in ("text", "value", "label", "title", "subtitle", "takeaway"):
                if key in obj:
                    obj[key]=normalize_currency_text(obj.get(key, ""), currency)
            if "color" in obj:
                obj["color"]=sanitize_color(obj.get("color"))
            if "accent" in obj:
                obj["accent"]=sanitize_color(obj.get("accent"), "#2563D8")
        for obj in scene.get("objects", []):
            if obj.get("type")=="summary_board":
                obj["title"]=normalize_currency_text(obj.get("title", ""), currency)
                obj["subtitle"]=normalize_currency_text(obj.get("subtitle", ""), currency)
                for card in obj.get("cards", []):
                    card["title"]=normalize_currency_text(card.get("title", ""), currency)
                    card["takeaway"]=normalize_currency_text(card.get("takeaway", ""), currency)
                    if "color" in card:
                        card["color"]=sanitize_color(card.get("color"))
    return out

"""Stable schema and validation for the AI Doodle Studio scene graph."""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any
import re

SUPPORTED_OBJECTS = {
    "text","equation","line","arrow","rect","round_rect","circle","ellipse",
    "person","money","coin","bank","wallet","house","calculator","question",
    "lightbulb","warning","check","cross","magnifier","book","robot","brain",
    "database","server","cloud","gpu","api","table","chart","bar_chart",
    "pie_chart","number","timeline","pipeline","group","image","space","document","lock","folder","spark","shield","target","trend","stack","cpu","filter","link","calendar","book","highlight","summary_board","token_strip","ratio","speech_bubble","flow_node","starburst","highlight_ring","icon",
}

@dataclass
class ProjectConfig:
    width: int = 1280
    height: int = 720
    fps: int = 30
    background: str = "#FFFDF7"
    ink: str = "#202020"
    accent: str = "#1F5EFF"
    hand: bool = True
    hand_asset: str | None = None
    style: str = "clean_whiteboard"
    format: str = "16:9"


def validate_scene_graph(doc: dict[str, Any]) -> list[str]:
    errors: list[str] = []
    if not isinstance(doc, dict):
        return ["project must be a JSON object"]
    if not isinstance(doc.get("scenes"), list) or not doc["scenes"]:
        return ["scenes must be a non-empty list"]
    for si, scene in enumerate(doc["scenes"], 1):
        if not isinstance(scene, dict):
            errors.append(f"scene {si}: must be an object"); continue
        if not scene.get("narration"):
            errors.append(f"scene {si}: missing narration")
        try:
            if float(scene.get("duration", 0)) <= 0:
                errors.append(f"scene {si}: duration must be > 0")
        except Exception:
            errors.append(f"scene {si}: invalid duration")
        objs = scene.get("objects", [])
        if not isinstance(objs, list):
            errors.append(f"scene {si}: objects must be a list"); continue
        for oi, obj in enumerate(objs, 1):
            if not isinstance(obj, dict):
                errors.append(f"scene {si}, object {oi}: must be an object"); continue
            typ = obj.get("type")
            if not isinstance(typ, str):
                errors.append(f"scene {si}, object {oi}: invalid semantic type {typ!r}")
            elif typ not in SUPPORTED_OBJECTS:
                # Domain vocabulary is intentionally open. The asset resolver
                # converts safe semantic types into deterministic renderer
                # primitives. Reject only malformed/non-string type values here.
                if not re.match(r"^[A-Za-z][A-Za-z0-9_ .:/+\-]{0,80}$", typ.strip()):
                    errors.append(f"scene {si}, object {oi}: invalid semantic type {typ!r}")
    return errors

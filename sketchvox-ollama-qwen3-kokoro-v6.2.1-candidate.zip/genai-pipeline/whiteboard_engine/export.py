"""Final delivery helpers: subtitles, metadata and format conversion."""
from __future__ import annotations
import json, subprocess
from pathlib import Path

def write_project_json(project,path): Path(path).write_text(json.dumps(project,indent=2,ensure_ascii=False),encoding='utf-8')

def convert_format(video,out_path,width,height):
    subprocess.run(['ffmpeg','-y','-i',video,'-vf',f'scale={width}:{height}:force_original_aspect_ratio=decrease,pad={width}:{height}:(ow-iw)/2:(oh-ih)/2','-c:v','libx264','-pix_fmt','yuv420p',str(out_path)],check=True,capture_output=True); return str(out_path)

def write_srt(scene_durations,scenes,path):
    lines=[]; t=0.0
    def ts(v):
        ms=int(round(v*1000)); h=ms//3600000; ms%=3600000; m=ms//60000; ms%=60000; s=ms//1000; ms%=1000; return f'{h:02d}:{m:02d}:{s:02d},{ms:03d}'
    for i,(dur,scene) in enumerate(zip(scene_durations,scenes),1):
        lines += [str(i),f'{ts(t)} --> {ts(t+dur)}',scene.get('narration',''),'']; t+=dur
    Path(path).write_text('\n'.join(lines),encoding='utf-8'); return str(path)

"""Provenance-aware external doodle asset resolver.

Reviewed SVG/PNG doodles can be placed in assets/external/doodles. The engine
never assumes an external asset is licensed merely because its repository is
open source; each imported file should have a sidecar entry in
assets/external/doodles/manifest.json.
"""
from __future__ import annotations
import json
import os
from pathlib import Path
from typing import Any

ROOT=Path(__file__).resolve().parents[1]
DOODLE_DIR=ROOT/"assets"/"external"/"doodles"
MANIFEST=DOODLE_DIR/"manifest.json"


def load_manifest() -> dict[str, Any]:
    if not MANIFEST.exists(): return {}
    try: return json.loads(MANIFEST.read_text(encoding="utf-8"))
    except Exception: return {}


def resolve(name: str, semantic_tags: list[str] | None = None) -> dict[str, Any] | None:
    manifest=load_manifest()
    entries=manifest.get("assets", {}) if isinstance(manifest,dict) else {}
    candidate=entries.get(name)
    if not candidate: return None
    rel=str(candidate.get("path", ""))
    path=DOODLE_DIR/rel
    if not path.exists(): return None
    if not bool(candidate.get("license_eligible",False)):
        return None
    return {**candidate,"name":name,"path":str(path)}


def available() -> list[str]:
    m=load_manifest(); return sorted((m.get("assets",{}) or {}).keys()) if isinstance(m,dict) else []

from __future__ import annotations
import os, requests
from .tts import TTSProvider

class ElevenLabsTTS(TTSProvider):
    """Optional direct ElevenLabs adapter. Install requests (already in base requirements)."""
    def __init__(self,api_key=None,voice_id=None,model_id='eleven_multilingual_v2'):
        self.api_key=api_key or os.getenv('ELEVENLABS_API_KEY'); self.voice_id=voice_id or os.getenv('ELEVENLABS_VOICE_ID'); self.model_id=model_id
    def synthesize(self,text,out_path,language='english'):
        if not self.api_key or not self.voice_id: raise RuntimeError('Set ELEVENLABS_API_KEY and ELEVENLABS_VOICE_ID')
        url=f'https://api.elevenlabs.io/v1/text-to-speech/{self.voice_id}'
        r=requests.post(url,headers={'xi-api-key':self.api_key,'Content-Type':'application/json'},json={'text':text,'model_id':self.model_id},timeout=120); r.raise_for_status(); open(out_path,'wb').write(r.content); return out_path

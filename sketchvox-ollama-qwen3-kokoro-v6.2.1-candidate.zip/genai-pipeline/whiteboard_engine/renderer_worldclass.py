"""SketchVox world-class deterministic whiteboard renderer (Phase 2 visual pass).

Design goals:
- Story-first pacing rather than slide-like scene dumps.
- One coherent handwriting face (bundled Comic Neue) for all Latin/numeric text.
- Custom vector glyphs for symbols the handwriting face does not contain (notably ₹),
  so currency symbols never switch to a visually unrelated fallback font.
- Character-aware text reveal so the hand can follow the actual writing endpoint.
- Semantic stroke icons with a slightly imperfect, hand-drawn line character.
- Exact hand-tip anchoring instead of a floating cursor.
- Better charts, callouts, emphasis strokes, and visual hierarchy.
- Deterministic output: no generative video service is required.
"""
from __future__ import annotations
import math, os, subprocess, tempfile, hashlib, json, sys
from functools import lru_cache
from pathlib import Path
from copy import deepcopy
from PIL import Image, ImageDraw, ImageFont, ImageFilter
import numpy as np
import cv2

from .scene_graph import normalize_project
from .layout import auto_layout_project
from .timing import sync_project_timing
from .camera import frame_transform
from .qa import qa_report
from .stroke_assets import strokes as asset_strokes
from .doodle_assets import resolve as resolve_doodle

ROOT = Path(__file__).resolve().parents[1]
HAND_PATH = ROOT / "assets" / "drawing-hand.png"

_FONT_CANDIDATES = {
    "hand_reg": [
        ROOT / "assets" / "fonts" / "ComicNeue-Regular.otf",
        Path(os.environ.get("WINDIR", r"C:\Windows")) / "Fonts" / "segoepr.ttf",
        Path(os.environ.get("WINDIR", r"C:\Windows")) / "Fonts" / "comic.ttf",
        Path("/usr/share/fonts/opentype/comic-neue/ComicNeue-Regular.otf"),
        Path("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"),
    ],
    "hand_bold": [
        ROOT / "assets" / "fonts" / "ComicNeue-Bold.otf",
        Path(os.environ.get("WINDIR", r"C:\Windows")) / "Fonts" / "segoeprb.ttf",
        Path(os.environ.get("WINDIR", r"C:\Windows")) / "Fonts" / "comicbd.ttf",
        Path("/usr/share/fonts/opentype/comic-neue/ComicNeue-Bold.otf"),
        Path("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"),
    ],
    "ui_reg": [
        ROOT / "assets" / "fonts" / "NotoSans-Regular.ttf",
        Path(os.environ.get("WINDIR", r"C:\Windows")) / "Fonts" / "segoeui.ttf",
        Path("/usr/share/fonts/truetype/noto/NotoSans-Regular.ttf"),
        Path("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"),
    ],
    "ui_bold": [
        ROOT / "assets" / "fonts" / "NotoSans-Bold.ttf",
        Path(os.environ.get("WINDIR", r"C:\Windows")) / "Fonts" / "segoeuib.ttf",
        Path("/usr/share/fonts/truetype/noto/NotoSans-Bold.ttf"),
        Path("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"),
    ],
}


def _first_existing(candidates):
    for p in candidates:
        if p.exists():
            return str(p)
    return None


@lru_cache(maxsize=128)
def _rupee_font(size: int):
    candidates = [
        ROOT / "assets" / "fonts" / "NotoSans-Regular.ttf",
        Path("/usr/share/fonts/truetype/noto/NotoSans-Regular.ttf"),
    ]
    path = _first_existing(candidates)
    if not path:
        return None
    return ImageFont.truetype(path, max(8, int(size)))


@lru_cache(maxsize=256)
def _font(size: int, bold=False, handwritten=True, text=None, role=None):
    # Keep the handwriting font for ASCII/Latin even when a string contains a
    # Unicode symbol; mixed-font rendering below handles the symbol itself.
    if role in {"display", "technical", "editorial"}: handwritten=False
    elif role in {"handwriting", "annotation"}: handwritten=True
    key = "hand_bold" if bold and handwritten else "hand_reg" if handwritten else "ui_bold" if bold else "ui_reg"
    path = _first_existing(_FONT_CANDIDATES[key])
    if not path:
        raise RuntimeError("No usable TrueType font found. Install Segoe Print/Segoe UI or DejaVu Sans.")
    return ImageFont.truetype(path, max(8, int(size)))


@lru_cache(maxsize=128)
def _unicode_font(size: int, bold=False):
    # Kept only as a last-resort fallback for genuinely unsupported glyphs.
    # Normal SketchVox text never mixes this face into Comic Neue.
    path = _first_existing(_FONT_CANDIDATES["ui_bold" if bold else "ui_reg"])
    if not path:
        return _font(size, bold=False, handwritten=False)
    return ImageFont.truetype(path, max(8, int(size)))


def _rgb(v, fallback="#262626"):
    if isinstance(v, (tuple, list)) and len(v) >= 3:
        try:
            return tuple(max(0, min(255, int(x))) for x in v[:3])
        except Exception:
            return _rgb(fallback)
    s = str(v or "").strip().lstrip('#')
    if len(s) == 3 and all(c in "0123456789abcdefABCDEF" for c in s):
        s = "".join(c * 2 for c in s)
    if len(s) == 6 and all(c in "0123456789abcdefABCDEF" for c in s):
        try:
            return tuple(int(s[i:i+2], 16) for i in (0, 2, 4))
        except Exception:
            pass
    return _rgb(fallback)


def ease(p, kind="smooth"):
    p = max(0.0, min(1.0, p))
    if kind == "linear": return p
    if kind == "ease_out": return 1 - (1-p)**3
    if kind == "ease_in": return p**3
    if kind == "back":
        c1 = 1.70158; c3 = c1 + 1
        return 1 + c3*(p-1)**3 + c1*(p-1)**2
    return p*p*(3-2*p)


def _jitter_points(points, amount=0.8, seed=""):
    if amount <= 0 or len(points) < 2:
        return points
    seed_int = int(hashlib.md5(seed.encode("utf-8")).hexdigest()[:8], 16)
    out=[]
    for i,(x,y) in enumerate(points):
        # deterministic, smooth-ish tiny perturbation; endpoints stay stable
        if i in (0, len(points)-1):
            out.append((x,y)); continue
        v = math.sin(seed_int*0.000001 + i*1.73) * amount
        w = math.cos(seed_int*0.0000013 + i*1.19) * amount
        out.append((x+v,y+w))
    return out


def sketch_polyline(draw, points, p, fill, width=4, seed="", wobble=0.75):
    if len(points) < 2 or p <= 0:
        return points[0] if points else (0,0)
    lengths=[]; total=0.0
    for a,b in zip(points,points[1:]):
        d=math.hypot(b[0]-a[0],b[1]-a[1]); lengths.append(d); total+=d
    if total <= 0: return points[-1]
    target=total*min(1,p); walked=0.0; out=[points[0]]
    for i,d in enumerate(lengths):
        a,b=points[i],points[i+1]
        if walked+d <= target:
            out.append(b); walked+=d; continue
        q=(target-walked)/d if d else 0
        out.append((a[0]+(b[0]-a[0])*q,a[1]+(b[1]-a[1])*q)); break
    out2=_jitter_points(out,wobble,seed)
    draw.line(out2,fill=fill,width=width,joint="curve")
    # A faint second pass creates a natural marker edge without looking fuzzy.
    if len(out2)>2 and width>=3:
        draw.line([(x+0.45,y-0.35) for x,y in out2],fill=fill,width=max(1,width//5),joint="curve")
    return out[-1]


@lru_cache(maxsize=512)
def _char_font(ch, size, bold=False):
    # The renderer intentionally uses one bundled face for normal text.
    # Unsupported special symbols are handled as vector glyphs below instead of
    # silently switching to Noto/DejaVu and producing uneven-looking words.
    return _font(size, bold, True, text=ch)


def _custom_glyph_width(ch, size):
    if ch == "₹":
        f = _rupee_font(size)
        if f is not None:
            d = ImageDraw.Draw(Image.new("L", (4, 4)))
            bb = d.textbbox((0, 0), "₹", font=f)
            return max(size * 0.42, bb[2] - bb[0])
        return size * 0.58
    if ch == "→":
        return size * 0.78
    return None


def _draw_rupee_glyph(d, x, y, size, color, stroke=2):
    """Draw the real ₹ outline from the bundled Noto Sans glyph.

    Comic Neue does not contain U+20B9. Rendering a hand-built approximation
    was producing a visibly broken glyph in the v4 videos. We therefore keep
    the same Latin handwriting face, but use a single authoritative ₹ glyph
    rather than mixing arbitrary fallback fonts or an approximate path.
    """
    f = _rupee_font(size)
    if f is not None:
        # Noto's glyph has stable metrics and the same dark ink treatment.
        d.text((x, y), "₹", font=f, fill=color, anchor="lt")
        bb = d.textbbox((x, y), "₹", font=f, anchor="lt")
        return x + max(size * 0.42, bb[2] - bb[0])
    # Emergency fallback for environments where the bundled symbol font is
    # missing. This is intentionally simple and is covered by a separate test.
    s=float(size)/48.0; w=max(1,int(stroke))
    d.line([(x+7*s,y+9*s),(x+38*s,y+9*s)],fill=color,width=w)
    d.line([(x+8*s,y+18*s),(x+31*s,y+18*s)],fill=color,width=w)
    d.arc((x+9*s,y+14*s,x+34*s,y+40*s), 300, 105, fill=color, width=w)
    d.line([(x+25*s,y+24*s),(x+9*s,y+48*s)],fill=color,width=w)
    return x+39*s

def _draw_arrow_glyph(d, x, y, size, color, stroke=2):
    s=float(size)/48.0; y0=y+size*0.52; x2=x+size*0.72
    d.line((x,y0,x2,y0),fill=color,width=stroke)
    d.line((x2,y0,x2-size*0.18,y0-size*0.16),fill=color,width=stroke)
    d.line((x2,y0,x2-size*0.18,y0+size*0.16),fill=color,width=stroke)
    return x+size*0.78


def _draw_text_prefix(base, text, x, y, size, color, bold=False, role=None):
    """Draw a complete visible prefix with stable font metrics and custom symbols."""
    d=ImageDraw.Draw(base); cursor=float(x); f=_font(size,bold,handwritten=(role not in {"display","technical","editorial"}),role=role)
    run=[]
    for ch in text:
        if ch in ("₹","→"):
            if run:
                segment=''.join(run); d.text((cursor,y),segment,font=f,fill=color,anchor='lt'); cursor += d.textlength(segment,font=f); run=[]
            if ch=="₹": cursor=_draw_rupee_glyph(d,cursor,y,size,color,max(1,int(size*0.055)))
            else: cursor=_draw_arrow_glyph(d,cursor,y,size,color,max(1,int(size*0.055)))
        else:
            run.append(ch)
    if run:
        segment=''.join(run); d.text((cursor,y),segment,font=f,fill=color,anchor='lt'); cursor += d.textlength(segment,font=f)
    return cursor


def _text_prefix_width(text,size,bold=False,role=None):
    # Width calculation mirrors _draw_text_prefix exactly.
    f=_font(size,bold,handwritten=(role not in {"display","technical","editorial"}),role=role); dummy=ImageDraw.Draw(Image.new('L',(4,4)))
    width=0.0
    for ch in str(text):
        custom=_custom_glyph_width(ch,size)
        width += custom if custom is not None else dummy.textlength(ch,font=f)
    return width


def _text_metrics(text, size, bold=False, role=None):
    f=_font(size,bold,handwritten=(role not in {"display","technical","editorial"}),role=role); d=ImageDraw.Draw(Image.new("L",(4,4)))
    width=_text_prefix_width(str(text),size,bold,role)
    bb=f.getbbox("Ag")
    return width,max(1,bb[3]-bb[1])


def draw_handwritten_text(base, obj, p, cfg):
    """Progressively write text using the same measured wrapping as layout.

    The previous world-class renderer measured max_width but then drew the
    entire string as one unbounded line. That made long labels escape the
    canvas even though geometry QA had proved the object safe.
    """
    text=str(obj.get('text',obj.get('value','')))
    x=float(obj.get('x',0)); y=float(obj.get('y',0)); scale=float(obj.get('scale',1))
    size=int(float(obj.get('size',46))*scale)
    bold=bool(obj.get('bold',False)); ink=_rgb(obj.get('color',cfg['ink']))
    p=ease(p,obj.get('easing','ease_out'))
    n=len(text)
    if n==0 or p<=0: return (x,y)
    role=obj.get("font_role")
    max_width=float(obj.get('max_width',900))*scale
    # Leave a conservative right margin even if an authored max_width is too
    # optimistic. Layout and renderer therefore share the same visible bound.
    max_width=min(max_width, max(120.0, float(base.width)-x-72.0))
    lines=_wrap_words(text,max_width,size,bold,role)
    reveal=min(n,max(0,int(math.ceil(n*p))))
    remaining=reveal
    line_h=float(obj.get('line_height',1.2))*size
    last=(x,y)
    # Reveal characters across the already-wrapped lines. Keeping the final
    # line breaks stable prevents text from jumping horizontally as it is drawn.
    for li,line in enumerate(lines):
        take=max(0,min(len(line),remaining))
        if take<=0: break
        visible=line[:take]
        cursor=_draw_text_prefix(base,visible,x,y+li*line_h,size,ink,bold,role=role)
        last=(cursor,y+li*line_h+size*0.52)
        remaining-=take
        if remaining<=0: break
    return last


@lru_cache(maxsize=16)
def _load_hand(scale=0.30):
    if not HAND_PATH.exists(): return None, (0,0)
    src=Image.open(HAND_PATH).convert("RGBA")
    arr=np.array(src)
    white=(arr[:,:,:3]>245).all(axis=2)
    arr[white,3]=0
    src=Image.fromarray(arr)
    src=src.resize((max(1,int(src.width*scale)),max(1,int(src.height*scale))),Image.Resampling.LANCZOS)
    # Marker tip measured from the supplied asset at source coordinates ~36,21.
    return src, (36*scale,21*scale)


def paste_hand(canvas, tip, scale=0.30, angle=0.0):
    src, tip0=_load_hand(scale)
    if src is None: return
    # Default orientation preserves the source artwork's believable hand pose.
    # If explicitly requested, rotate around the original tip and then translate
    # so the transformed tip lands exactly on the active stroke endpoint.
    if abs(angle)>0.1:
        w,h=src.size
        cx,cy=w/2,h/2
        src=src.rotate(angle,resample=Image.Resampling.BICUBIC,expand=True)
        # PIL expand rotation shifts the old centre to the new centre.
        ncx,ncy=src.width/2,src.height/2
        rad=math.radians(-angle)
        tx=tip0[0]-cx; ty=tip0[1]-cy
        rtx=tx*math.cos(rad)-ty*math.sin(rad)
        rty=tx*math.sin(rad)+ty*math.cos(rad)
        tip_rot=(ncx+rtx,ncy+rty)
    else:
        tip_rot=tip0
    px=int(tip[0]-tip_rot[0]); py=int(tip[1]-tip_rot[1])
    canvas.alpha_composite(src,(px,py))


def _money_strokes(x,y,s,with_center_emblem=True):
    strokes=[
        [(x,y),(x+180*s,y),(x+180*s,y+105*s),(x,y+105*s),(x,y)],
        [(x+18*s,y+15*s),(x+162*s,y+15*s)],
        [(x+18*s,y+90*s),(x+162*s,y+90*s)],
    ]
    # A centered emblem overlaps dense financial amounts such as ₹12,100.
    # When an authoritative label is present, omit the emblem entirely. The
    # amount itself is the visual focal point of a money object.
    if with_center_emblem:
        strokes.append([(x+90*s,y+33*s),(x+100*s,y+45*s),(x+90*s,y+62*s),(x+80*s,y+45*s),(x+90*s,y+33*s)])
    return strokes


def _person_strokes(x,y,s):
    r=30*s
    return [
        [(x+r*math.cos(a),y+r*math.sin(a)) for a in np.linspace(0,2*math.pi,28)],
        [(x,y+r),(x,y+110*s)],[(x,y+55*s),(x-48*s,y+90*s)],[(x,y+55*s),(x+48*s,y+90*s)],
        [(x,y+110*s),(x-42*s,y+170*s)],[(x,y+110*s),(x+42*s,y+170*s)],
    ]


def _arrow_strokes(x,y,x2,y2,s):
    ang=math.atan2(y2-y,x2-x); L=24*s
    a1=ang+2.55; a2=ang-2.55
    return [[(x,y),(x2,y2)],[(x2,y2),(x2+L*math.cos(a1),y2+L*math.sin(a1))],[(x2,y2),(x2+L*math.cos(a2),y2+L*math.sin(a2))]]


def _chart_points(obj):
    x=float(obj.get('x',0)); y=float(obj.get('y',0)); w=float(obj.get('width',700)); h=float(obj.get('height',350)); vals=[float(v) for v in obj.get('values',[])]
    if not vals: return []
    lo=min(vals); hi=max(vals); span=max(1e-9,hi-lo)
    return [(x+i*w/(len(vals)-1), y+h-(v-lo)/span*h) for i,v in enumerate(vals)]


def _icon_strokes(typ,x,y,s):
    if typ=='lightbulb':
        r=42*s
        return [[(x+r*math.cos(a),y+r*math.sin(a)) for a in np.linspace(0,2*math.pi,32)],[(x-24*s,y+38*s),(x+24*s,y+38*s)],[(x-18*s,y+53*s),(x+18*s,y+53*s)]]
    if typ=='question':
        return [[(x-24*s,y-22*s),(x-12*s,y-38*s),(x+12*s,y-38*s),(x+25*s,y-22*s),(x+18*s,y-5*s),(x,y+10*s),(x,y+28*s)],[(x,y+48*s),(x+1*s,y+49*s)]]
    if typ=='brain':
        pts=[(x-55*s,y+20*s),(x-65*s,y-10*s),(x-48*s,y-28*s),(x-52*s,y-55*s),(x-20*s,y-65*s),(x+5*s,y-48*s),(x+35*s,y-58*s),(x+58*s,y-35*s),(x+52*s,y-5*s),(x+66*s,y+18*s),(x+48*s,y+45*s),(x+15*s,y+55*s),(x-20*s,y+48*s),(x-55*s,y+20*s)]
        return [pts,[(x-10*s,y-50*s),(x-10*s,y+42*s)],[(x+18*s,y-35*s),(x+18*s,y+35*s)]]
    if typ=='robot':
        return [[(x-55*s,y-40*s),(x+55*s,y-40*s),(x+55*s,y+40*s),(x-55*s,y+40*s),(x-55*s,y-40*s)],[(x-28*s,y-8*s),(x-16*s,y+4*s)],[(x+28*s,y-8*s),(x+16*s,y+4*s)],[(x-28*s,y+18*s),(x+28*s,y+18*s)],[(x,y-40*s),(x,y-62*s)],[(x-8*s,y-62*s),(x+8*s,y-62*s)]]
    if typ=='document':
        return [[(x,y),(x+62*s,y),(x+85*s,y+23*s),(x+85*s,y+110*s),(x,y+110*s),(x,y)],[(x+62*s,y),(x+62*s,y+23*s),(x+85*s,y+23*s)],[(x+15*s,y+48*s),(x+70*s,y+48*s)],[(x+15*s,y+72*s),(x+70*s,y+72*s)],[(x+15*s,y+94*s),(x+55*s,y+94*s)]]
    if typ=='lock':
        return [[(x,y+35*s),(x,y+80*s),(x+75*s,y+80*s),(x+75*s,y+35*s),(x,y+35*s)],[(x+18*s,y+35*s),(x+18*s,y+5*s),(x+57*s,y+5*s),(x+57*s,y+35*s)],[(x+37*s,y+55*s),(x+37*s,y+68*s)]]
    if typ=='folder':
        return [[(x,y+20*s),(x+38*s,y+20*s),(x+50*s,y+8*s),(x+120*s,y+8*s),(x+135*s,y+25*s),(x+125*s,y+90*s),(x,y+90*s),(x,y+20*s)]]
    if typ=='spark':
        return [[(x,y-35*s),(x,y+35*s)],[(x-35*s,y),(x+35*s,y)],[(x-24*s,y-24*s),(x+24*s,y+24*s)],[(x-24*s,y+24*s),(x+24*s,y-24*s)]]
    if typ=='magnifier':
        return [[(x+32*s*math.cos(a),y+32*s*math.sin(a)) for a in np.linspace(0,2*math.pi,32)],[(x+23*s,y+23*s),(x+72*s,y+72*s)]]
    if typ in ('coin','bank','database','cloud','check','cross','server','wallet','spark','shield','target','trend','stack','cpu','filter','link','calendar','book'):
        return asset_strokes(typ,x,y,s)
    return []


def _draw_strokes(base, strokes, p, ink, sw, seed, wobble=0.75):
    d=ImageDraw.Draw(base); n=len(strokes); endpoint=strokes[0][0] if strokes else (0,0); per=1/max(1,n)
    for i,pts in enumerate(strokes):
        local=max(0,min(1,(p-i*per)/per))
        if local>0:
            endpoint=sketch_polyline(d,pts,local,ink,sw,f"{seed}:{i}",wobble)
    return endpoint


def _draw_highlight(d, obj, cfg):
    x=float(obj.get('x',0)); y=float(obj.get('y',0)); w=float(obj.get('width',160)); h=float(obj.get('height',60)); col=_rgb(obj.get('color','#FFF1A8'))
    d.rounded_rectangle((x,y,x+w,y+h),radius=min(18,h/3),fill=col)



def _draw_money_amount(base, text: str, x: float, y: float, size: int, color: str, max_width: float) -> None:
    """Render financial amounts with a crisp UI face inside the hand-drawn note.

    Comic Neue is excellent for hand-written lesson copy, but its comma/glyph
    spacing is not reliable for dense financial amounts. Money labels therefore
    use the bundled Noto Sans Bold face while the surrounding banknote remains a
    hand-drawn vector. This keeps numbers legible and avoids the old malformed
    comma/₹ appearance.
    """
    fpath=_first_existing(_FONT_CANDIDATES['ui_bold'])
    if not fpath:
        _draw_text_prefix(base,text,x,y,size,_rgb(color),True)
        return
    d=ImageDraw.Draw(base)
    fsize=int(size)
    while fsize>18:
        f=ImageFont.truetype(fpath,fsize)
        if d.textlength(str(text),font=f) <= max_width: break
        fsize-=1
    f=ImageFont.truetype(fpath,fsize)
    tw=d.textlength(str(text),font=f)
    # Center within the banknote body.
    d.text((x+max_width/2,y),str(text),font=f,fill=_rgb(color),anchor='mt')
    return

def _coerce_stroke_width(obj, default=4.0):
    """Return a safe numeric stroke width.

    LLM scene graphs occasionally put a color in ``stroke`` (for example
    ``"#000000"``) instead of using ``color``.  Rendering must never crash
    on such model output; the semantic color is handled separately and the
    stroke width falls back to the configured default.
    """
    raw = obj.get('stroke', default)
    if isinstance(raw, (int, float)) and not isinstance(raw, bool):
        return max(0.5, float(raw))
    if isinstance(raw, str):
        value = raw.strip()
        # Common accidental color-in-stroke forms.
        if value.startswith('#') or value.lower().startswith(('rgb(', 'rgba(', 'hsl(', 'hsla(')):
            return float(default)
        try:
            return max(0.5, float(value.replace('px', '').strip()))
        except (TypeError, ValueError):
            return float(default)
    return float(default)

def _token_strip_strokes(x, y, tokens, scale=1.0, gap=12):
    """Return rounded token-chip outlines used for tokenization/sequence lessons."""
    strokes=[]; cursor=x
    for tok in tokens:
        width=max(54, 24 + len(str(tok))*13)*scale
        h=62*scale; r=min(12*scale,width/4,h/4); pts=[]
        for cx,cy,start in [(cursor+r,y+r,math.pi),(cursor+width-r,y+r,-math.pi/2),(cursor+width-r,y+h-r,0),(cursor+r,y+h-r,math.pi/2)]:
            pts += [(cx+r*math.cos(a),cy+r*math.sin(a)) for a in np.linspace(start,start+math.pi/2,7)]
        pts.append(pts[0]); strokes.append(pts); cursor += width+gap*scale
    return strokes


def _ratio_strokes(x,y,w,h,scale=1.0):
    x2=x+w*scale; mid=y+h*0.53*scale
    return [[(x,y),(x2,y)],[(x,y),(x2,y)],[(x,y),(x2,y)]]


def _speech_bubble_strokes(x,y,w,h,scale=1.0):
    x2=x+w*scale; y2=y+h*scale; r=min(22*scale,w*scale/8,h*scale/5)
    pts=[]
    for cx,cy,start in [(x+r,y+r,math.pi),(x2-r,y+r,-math.pi/2),(x2-r,y2-r,0),(x+r,y2-r,math.pi/2)]:
        pts += [(cx+r*math.cos(a),cy+r*math.sin(a)) for a in np.linspace(start,start+math.pi/2,8)]
    pts += [(x+w*0.35*scale,y2),(x+w*0.28*scale,y2+30*scale),(x+w*0.48*scale,y2)]
    pts.append(pts[0]); return [pts]


def _starburst_strokes(x,y,r=54,scale=1.0):
    pts=[]
    for i in range(16):
        a=2*math.pi*i/16; rr=(r if i%2==0 else r*0.62)*scale
        pts.append((x+rr*math.cos(a),y+rr*math.sin(a)))
    pts.append(pts[0]); return [pts]


def _draw_token_labels(base, obj, p, cfg):
    d=ImageDraw.Draw(base); x=float(obj.get('x',0)); y=float(obj.get('y',0)); s=float(obj.get('scale',1)); tokens=list(obj.get('tokens') or [])
    cursor=x; colors=obj.get('token_colors') or [cfg.get('accent','#4F46E5'),cfg.get('positive','#10B981'),cfg.get('accent2','#F59E0B')]
    for i,tok in enumerate(tokens):
        width=max(54,24+len(str(tok))*13)*s; h=62*s
        local=(p*len(tokens))-i
        if local<=0: continue
        cp=min(1,max(0,local)); reveal_w=max(3,int(width*cp))
        d.rounded_rectangle((cursor,y,cursor+reveal_w,y+h),radius=int(12*s),outline=_rgb(colors[i%len(colors)]),width=max(2,int(3*s)))
        if cp>0.78:
            f=_font(int(obj.get('label_size',22)*s),True,False,role='technical')
            d.text((cursor+width/2,y+h/2),str(tok),font=f,fill=_rgb(obj.get('text_color',cfg['ink'])),anchor='mm')
        cursor += width+12*s


def _draw_ratio(base,obj,p,cfg):
    d=ImageDraw.Draw(base); x=float(obj.get('x',0)); y=float(obj.get('y',0)); s=float(obj.get('scale',1));
    top=str(obj.get('top','PRICE')); bottom=str(obj.get('bottom','EARNINGS')); result=str(obj.get('result','10×'))
    width=float(obj.get('width',330))*s; fs=int(obj.get('size',38)*s); f=_font(fs,True,False,role='technical')
    # Progressive reveal: top, fraction bar, denominator, then result.
    if p>0.02: d.text((x+width/2,y),top,font=f,fill=_rgb(obj.get('top_color',cfg['accent'])),anchor='mm')
    if p>0.38: d.line((x,y+48*s,x+width,y+48*s),fill=_rgb(obj.get('color',cfg['ink'])),width=max(3,int(4*s)))
    if p>0.52: d.text((x+width/2,y+82*s),bottom,font=f,fill=_rgb(obj.get('bottom_color',cfg['positive'])),anchor='mm')
    if p>0.78:
        rf=_font(int(obj.get('result_size',56)*s),True,False,role='display')
        d.text((x+width/2,y+160*s),result,font=rf,fill=_rgb(obj.get('result_color',cfg['accent2'])),anchor='mm')
    return (x+width,y+160*s)


def _draw_external_doodle(base, obj, p, cfg):
    """Render a reviewed local doodle asset when available.

    SVG support is optional (cairosvg); PNG is handled by Pillow. If an asset
    is unavailable or not license-approved, return False so the caller can use
    a deterministic vector fallback.
    """
    name=str(obj.get("asset") or obj.get("name") or "").strip()
    info=resolve_doodle(name, obj.get("semantic_tags")) if name else None
    if not info or p <= 0: return False
    path=Path(info["path"])
    try:
        from PIL import Image
        scale=float(obj.get("scale",1))
        requested_w=int(float(obj.get("width",0))*scale) if obj.get("width") else None
        requested_h=int(float(obj.get("height",0))*scale) if obj.get("height") else None
        if path.suffix.lower()==".svg":
            import cairosvg
            kwargs={}
            if requested_w: kwargs["output_width"]=requested_w
            if requested_h: kwargs["output_height"]=requested_h
            png=cairosvg.svg2png(url=str(path), **kwargs)
            import io
            src=Image.open(io.BytesIO(png)).convert("RGBA")
        else:
            src=Image.open(path).convert("RGBA")
        max_w=float(obj.get("width",src.width))*scale; max_h=float(obj.get("height",src.height))*scale
        if obj.get("width") or obj.get("height"):
            src.thumbnail((max(1,int(max_w)),max(1,int(max_h))),Image.Resampling.LANCZOS)
        if p<1:
            src=src.copy(); alpha=src.getchannel("A").point(lambda a:int(a*max(0,min(1,p))))
            src.putalpha(alpha)
        base.alpha_composite(src,(int(float(obj.get("x",0))),int(float(obj.get("y",0)))))
        return True
    except Exception:
        return False


def draw_vector_object(base,obj,p,cfg):
    typ=obj.get('type')
    # If an LLM put a color in `stroke`, preserve that intent as the object
    # color rather than allowing a float conversion to crash the renderer.
    raw_stroke = obj.get('stroke')
    if isinstance(raw_stroke, str) and raw_stroke.strip().startswith('#') and 'color' not in obj:
        obj = dict(obj)
        obj['color'] = raw_stroke.strip()
    ink=_rgb(obj.get('color',cfg['ink'])); accent=_rgb(obj.get('accent',cfg['accent']))
    s=float(obj.get('scale',1)); sw=max(2,int(_coerce_stroke_width(obj)*s)); x=float(obj.get('x',0)); y=float(obj.get('y',0));
    p=ease(p,obj.get('easing','smooth'))
    if p<=0: return (x,y)
    if typ in {'icon', 'doodle_icon'}:
        # `icon` is the semantic, model-facing primitive. `doodle_icon` remains
        # the explicit reviewed-external-asset primitive. Both must be safe to
        # render even when no external asset is installed.
        semantic_name = str(obj.get('icon') or obj.get('name') or obj.get('asset') or '').strip().lower()
        if typ == 'doodle_icon' and _draw_external_doodle(base,obj,p,cfg): return (x,y)
        # If a semantic icon names an approved external asset, try it before the
        # deterministic vector fallback. This keeps icon output visually richer
        # without making external assets a runtime dependency.
        if typ == 'icon' and semantic_name:
            external = dict(obj)
            external['asset'] = semantic_name
            if _draw_external_doodle(base, external, p, cfg): return (x,y)
        # Domain-specific semantic doodles use the bundled vector asset library.
        # This keeps the semantic vocabulary open without silently degrading
        # concrete science/data/finance symbols into a generic sparkle.
        if semantic_name in {
            'tree','leaf','sun','water','oxygen','carbon_dioxide','glucose','dna',
            'cell','atom','molecule','energy','force','gradient','loss','token',
            'query','attention','neuron','probability','generic'
        }:
            from .assets import draw_icon as _draw_semantic_icon
            _draw_semantic_icon(ImageDraw.Draw(base), semantic_name, x, y, s, ink, accent, p, obj.get('label'))
            return (x,y)
        aliases = {
            'idea':'lightbulb','rule':'check','mental':'brain','question':'question',
            'search':'magnifier','compare':'magnifier','growth':'trend','result':'check',
            'augment':'database','generate':'robot','capital':'coin','year1':'coin','year2':'trend',
            'average':'trend','move':'arrow','mechanism':'flow_node','spark':'spark'
        }
        fallback = str(obj.get('fallback_type') or aliases.get(semantic_name, semantic_name) or 'spark')
        # flow_node is a specialised renderer primitive; its default geometry is
        # still safe when an icon request does not supply x2/y2.
        if fallback not in {'question','lightbulb','brain','robot','document','lock','folder','spark','magnifier','coin','bank','database','cloud','check','cross','server','wallet','shield','target','trend','stack','cpu','filter','link','calendar','book','arrow','flow_node'}:
            fallback = 'spark'
        obj=dict(obj); obj['type']=fallback; typ=fallback
    if typ == 'token_strip':
        _draw_token_labels(base,obj,p,cfg); return (x+float(obj.get('width',700))*s,y+32*s)
    if typ == 'ratio':
        return _draw_ratio(base,obj,p,cfg)
    if typ == 'speech_bubble':
        strokes=_speech_bubble_strokes(x,y,float(obj.get('width',420)),float(obj.get('height',170)),s)
        ep=_draw_strokes(base,strokes,p,ink,sw,str(obj.get('id',typ)),float(obj.get('wobble',0.8)))
        if p>0.72 and obj.get('text'):
            f=_font(int(obj.get('size',30)*s),False,False,role=obj.get('font_role'))
            ImageDraw.Draw(base).text((x+float(obj.get('width',420))*s/2,y+float(obj.get('height',170))*s/2),str(obj['text']),font=f,fill=ink,anchor='mm')
        return ep
    if typ == 'flow_node':
        x2=float(obj.get('x2',x+180)); y2=float(obj.get('y2',y+90));
        strokes=[[(x,y),(x2,y),(x2,y2),(x,y2),(x,y)]]
        ep=_draw_strokes(base,strokes,p,ink,sw,str(obj.get('id',typ)),float(obj.get('wobble',0.8)))
        if p>0.78 and obj.get('label'):
            f=_font(int(obj.get('label_size',26)*s),True,False,role=obj.get('font_role'))
            ImageDraw.Draw(base).text(((x+x2)/2,(y+y2)/2),str(obj['label']),font=f,fill=ink,anchor='mm')
        return ep
    if typ == 'starburst':
        strokes=_starburst_strokes(x,y,float(obj.get('r',54)),s); return _draw_strokes(base,strokes,p,ink,sw,str(obj.get('id',typ)),float(obj.get('wobble',0.8)))
    if typ == 'highlight_ring':
        d=ImageDraw.Draw(base); rr=float(obj.get('r',70))*s; d.ellipse((x-rr,y-rr,x+rr,y+rr),outline=_rgb(obj.get('color',cfg['accent2'])),width=max(3,int(5*s))) if p>0.2 else None; return (x+rr,y)
    if typ == 'summary_board':
        # Build the recap quickly, then leave the complete board on screen while
        # narration explains the cards. `reveal_seconds` is absolute scene time
        # expressed through the object's normalized progress.
        reveal_seconds=float(obj.get('reveal_seconds',7.0))
        object_duration=max(0.1,float(obj.get('duration',7.0)))
        # The scene may be retimed after TTS. Never allow a recap reveal budget
        # longer than the actual object duration; the final frame must contain
        # the complete summary or the video fails visual QA.
        effective_reveal=min(max(0.55,reveal_seconds), max(0.55,object_duration*0.82))
        p_summary=min(1.0,p*object_duration/effective_reveal)
        return _draw_summary_board(base,obj,p_summary,cfg)
    if typ in ('text','equation','number'):
        ep=draw_handwritten_text(base,obj,p,cfg)
        if obj.get('underline') and p>=0.92:
            d=ImageDraw.Draw(base); d.line((x,ep[1]+float(obj.get('size',46))*0.35,ep[0],ep[1]+float(obj.get('size',46))*0.35),fill=accent,width=max(2,int(3*s)))
        return ep
    if typ=='highlight':
        _draw_highlight(ImageDraw.Draw(base),obj,cfg); return (x+float(obj.get('width',160)),y+float(obj.get('height',60))/2)
    if typ=='person': strokes=_person_strokes(x,y,s)
    elif typ=='money':
        strokes=_money_strokes(x,y,s,with_center_emblem=not bool(obj.get("label")))
        if p>0.72:
            label=str(obj.get('label','₹')); size=int(46*s)
            _draw_money_amount(base,label,x+18*s,y+28*s,size,ink,144*s)
    elif typ=='arrow': strokes=_arrow_strokes(x,y,float(obj.get('x2',x+200)),float(obj.get('y2',y)),s)
    elif typ=='line': strokes=[[(x,y),(float(obj.get('x2',x)),float(obj.get('y2',y)))]]
    elif typ in ('rect','round_rect'):
        x2=float(obj.get('x2',x+100)); y2=float(obj.get('y2',y+60));
        if typ=='rect': strokes=[[(x,y),(x2,y),(x2,y2),(x,y2),(x,y)]]
        else:
            r=min(18*s,abs(x2-x)/4,abs(y2-y)/4); pts=[]
            for cx,cy,start in [(x+r,y+r,math.pi),(x2-r,y+r,-math.pi/2),(x2-r,y2-r,0),(x+r,y2-r,math.pi/2)]:
                pts += [(cx+r*math.cos(a),cy+r*math.sin(a)) for a in np.linspace(start,start+math.pi/2,9)]
            pts.append(pts[0]); strokes=[pts]
    elif typ in ('circle','ellipse'):
        rx=float(obj.get('rx',obj.get('r',50)))*s; ry=float(obj.get('ry',obj.get('r',50)))*s
        strokes=[[(x+rx*math.cos(a),y+ry*math.sin(a)) for a in np.linspace(0,2*math.pi,44)]]
    elif typ in ('chart','line_chart'):
        vals=obj.get('values') or [1,2,3]; pts=_chart_points({**obj,'values':vals}); xx=x; yy=y; w=float(obj.get('width',700)); h=float(obj.get('height',350))
        strokes=[[(xx,yy+h),(xx,yy)],[(xx,yy+h),(xx+w,yy+h)]]
        if pts: strokes.append(pts)
    elif typ in ('question','lightbulb','brain','robot','document','lock','folder','spark','magnifier','coin','bank','database','cloud','check','cross','server','wallet','shield','target','trend','stack','cpu','filter','link','calendar','book'):
        strokes=_icon_strokes(typ,x,y,s)
    else:
        return (x,y)
    ep=_draw_strokes(base,strokes,p,ink,sw,str(obj.get('id',typ)),float(obj.get('wobble',0.8)))
    d=ImageDraw.Draw(base)
    if typ in ('chart','line_chart') and p>0.78:
        pts=_chart_points(obj); count=max(1,int(len(pts)*min(1,(p-0.72)/0.28)))
        for px,py in pts[:count]: d.ellipse((px-4*s,py-4*s,px+4*s,py+4*s),fill=accent)
        if obj.get('y_ticks'):
            vals=[float(v) for v in obj['y_ticks']]; lo=min(float(v) for v in (obj.get('values') or vals)); hi=max(float(v) for v in (obj.get('values') or vals)); span=max(1e-9,hi-lo)
            for v in vals:
                gy=y+float(obj.get('height',350))-(v-lo)/span*float(obj.get('height',350)); d.line((x,gy,x+float(obj.get('width',700)),gy),fill=_rgb('#E5E5E5'),width=1)
                lab=f"{int(v):,}" if float(v).is_integer() else f"{v:g}"; f=_font(19,False,False,role="technical"); d.text((x-72,gy-12),lab,font=f,fill=ink)
        if obj.get('x_labels'):
            labels=list(obj['x_labels']);
            for i,lab in enumerate(labels):
                gx=x+(i/max(1,len(labels)-1))*float(obj.get('width',700)); f=_font(19,False,False,role="technical"); d.text((gx-6,y+float(obj.get('height',350))+12),str(lab),font=f,fill=ink)
    # Money objects already render their authoritative amount inside the banknote
    # glyph. A second generic `label` pass would duplicate the amount above the
    # note and is a classic source of visual gibberish. Other drawable objects may
    # still use the generic label (e.g. charts).
    if obj.get('label') and p>0.9 and typ != 'money':
        f=_font(int(obj.get('label_size',24)),False,True,text=str(obj['label']),role=obj.get("font_role")); d.text((x, max(8, y-34)), str(obj['label']), font=f, fill=ink)
    return ep



def _rounded_rect_strokes(x1,y1,x2,y2,r=18,segments=8):
    pts=[]
    for cx,cy,start in [
        (x1+r,y1+r,math.pi), (x2-r,y1+r,-math.pi/2),
        (x2-r,y2-r,0), (x1+r,y2-r,math.pi/2)
    ]:
        pts += [(cx+r*math.cos(a),cy+r*math.sin(a)) for a in np.linspace(start,start+math.pi/2,segments)]
    pts.append(pts[0])
    return pts


def _fit_text(text, max_width, size, bold=False, min_size=16, role=None):
    size=int(size)
    while size>min_size:
        w,_=_text_metrics(text,size,bold,role)
        if w <= max_width: break
        size-=1
    return size


def _wrap_words(text, max_width, size, bold=False, role=None):
    words=str(text).split()
    lines=[]; cur=""
    for word in words:
        trial=word if not cur else cur+" "+word
        if _text_metrics(trial,size,bold,role)[0] <= max_width or not cur:
            cur=trial
        else:
            lines.append(cur); cur=word
    if cur: lines.append(cur)
    return lines


def _draw_text_static(base, text, x, y, size, color, bold=False, max_width=None, line_gap=5):
    d=ImageDraw.Draw(base); ink=_rgb(color)
    if max_width:
        size=_fit_text(text,max_width,size,bold)
        lines=_wrap_words(text,max_width,size,bold)
    else:
        lines=[str(text)]
    yy=y
    for line in lines:
        draw_handwritten_text(base,{"text":line,"x":x,"y":yy,"size":size,"color":color,"bold":bold},1.0,{
            "ink":"#262626","accent":"#2563D8"
        })
        yy += size*1.02+line_gap
    return yy


def _fit_ui_text(text, max_width, size, bold=False, min_size=14):
    d=ImageDraw.Draw(Image.new("L",(4,4))); size=int(size); f=_font(size,bold,False)
    while size>min_size and d.textlength(str(text),font=f)>max_width:
        size-=1; f=_font(size,bold,False)
    return size


def _draw_ui_text(base, text, x, y, size, color, bold=False, max_width=None, line_gap=5):
    """Modern UI typography used for editorial chrome/cards.

    SketchVox keeps Comic Neue for the actual hand-drawn lesson marks and uses
    bundled Noto Sans for compact UI-style labels. This hybrid is closer to
    modern explainer/editorial products while preserving the doodle character.
    """
    d=ImageDraw.Draw(base); ink=_rgb(color); size=int(size)
    f=_font(size,bold,False)
    if max_width:
        words=str(text).split(); lines=[]; cur=""
        for word in words:
            trial=word if not cur else cur+" "+word
            if d.textlength(trial,font=f)<=max_width or not cur: cur=trial
            else: lines.append(cur); cur=word
        if cur: lines.append(cur)
    else: lines=[str(text)]
    yy=float(y)
    for line in lines:
        d.text((x,yy),line,font=f,fill=ink,anchor='lt')
        yy += size*1.12+line_gap
    return yy


def _soft_shadow_card(base, rect, radius=22, shadow=(0,5), fill="#FFFFFF", outline="#E5E7EB"):
    d=ImageDraw.Draw(base)
    x1,y1,x2,y2=rect
    sx,sy=shadow
    d.rounded_rectangle((x1+sx,y1+sy,x2+sx,y2+sy),radius=radius,fill=_rgb("#E9E7E2"))
    d.rounded_rectangle(rect,radius=radius,fill=_rgb(fill),outline=_rgb(outline),width=2)


def _summary_icon(base, card, x, y, w, h, cfg):
    """Draw a compact semantic recap glyph inside a hard 50px badge.

    Summary icons are UI/editorial marks, not miniature scene diagrams.  Earlier
    versions reused full-size stroke assets (trend/filter/etc.), whose native
    extents could escape the badge and collide with the takeaway copy.  v4.1
    draws every recap glyph directly inside a fixed 44x38 safe box.
    """
    icon=str(card.get("icon") or "spark").lower().strip()
    aliases={
        "capital":"base", "year1":"return", "year2":"return_growth", "curve":"curve",
        "retrieve":"retrieve", "augment":"context", "generate":"generate", "grounded":"grounded",
        "mental":"mental", "average":"average", "result":"result", "coin":"share", "window":"window",
        "move":"move", "rule":"rule", "spark":"idea",
        "leaf":"idea", "sun":"idea", "water":"context", "oxygen":"result",
        "carbon_dioxide":"retrieve", "glucose":"base", "energy":"return_growth",
        "cell":"context", "brain":"mental"
    }
    icon=aliases.get(icon,icon)
    title=str(card.get("title","")).lower()
    if icon in {"idea","rule","spark"}:
        if any(k in title for k in ("base","capital","principal","money")): icon="base"
        elif any(k in title for k in ("return","gain","interest","growth")): icon="return_growth"
        elif any(k in title for k in ("curve","trend")): icon="curve"
        elif any(k in title for k in ("result","signal")): icon="result"
        elif any(k in title for k in ("retrieve","search","find")): icon="retrieve"
        elif any(k in title for k in ("augment","context","evidence")): icon="context"
        elif any(k in title for k in ("generate","answer","model")): icon="generate"
        elif any(k in title for k in ("share","basket","holdings")): icon="share"
        elif "window" in title: icon="window"
        elif any(k in title for k in ("average","move")): icon="average"
        else: icon="idea"
    col=_rgb(cfg.get('accent','#4F46E5')); green=_rgb(cfg.get('positive',cfg.get('accent','#4F46E5'))); amber=_rgb(cfg.get('accent2',cfg.get('accent','#4F46E5')))
    ink=_rgb(cfg.get('ink','#20242B'))
    # Fixed local coordinate system.  All marks stay inside x..x+w/y..y+h.
    pad=3; x0=x+pad; y0=y+pad; x1=x+w-pad; y1=y+h-pad
    d=ImageDraw.Draw(base)
    if icon=='base':
        c=col; d.rounded_rectangle((x0+5,y0+8,x0+35,y0+29),radius=4,outline=c,width=2)
        d.line((x0+9,y0+13,x0+31,y0+13),fill=c,width=2); d.line((x0+10,y0+25,x0+30,y0+25),fill=c,width=2)
    elif icon=='return_growth':
        c=green; d.ellipse((x0+1,y0+10,x0+13,y0+22),outline=c,width=2); d.ellipse((x0+31,y0+10,x0+43,y0+22),outline=c,width=2)
        d.line((x0+13,y0+16,x0+31,y0+16),fill=c,width=2); d.line((x0+26,y0+12,x0+31,y0+16),fill=c,width=2); d.line((x0+26,y0+20,x0+31,y0+16),fill=c,width=2)
    elif icon=='curve' or icon=='result':
        c=col if icon=='curve' else green
        pts=[(x0+2,y0+29),(x0+12,y0+25),(x0+22,y0+27),(x0+32,y0+15),(x0+42,y0+7)]
        d.line(pts,fill=c,width=2,joint='curve'); d.line((x0+35,y0+10,x0+42,y0+7),fill=c,width=2); d.line((x0+39,y0+13,x0+42,y0+7),fill=c,width=2)
    elif icon=='retrieve':
        c=col; d.ellipse((x0+8,y0+6,x0+27,y0+25),outline=c,width=2); d.line((x0+24,y0+22,x0+38,y0+35),fill=c,width=2)
    elif icon=='context':
        c=green; d.rounded_rectangle((x0+2,y0+10,x0+19,y0+25),radius=3,outline=c,width=2); d.rounded_rectangle((x0+25,y0+10,x0+42,y0+25),radius=3,outline=c,width=2); d.arc((x0+14,y0+14,x0+30,y0+31),180,360,fill=c,width=2); d.arc((x0+14,y0+5,x0+30,y0+22),0,180,fill=c,width=2)
    elif icon=='generate':
        c=col; d.rounded_rectangle((x0+7,y0+7,x0+36,y0+28),radius=5,outline=c,width=2); d.ellipse((x0+14,y0+14,x0+17,y0+17),fill=c); d.ellipse((x0+27,y0+14,x0+30,y0+17),fill=c); d.line((x0+16,y0+22,x0+28,y0+22),fill=c,width=2); d.line((x0+21,y0+7,x0+21,y0+2),fill=c,width=2)
    elif icon in {'basket','share'}:
        c=col if icon=='basket' else amber
        if icon=='basket':
            for yy in (8,16,24): d.rounded_rectangle((x0+6, y0+yy, x0+38, y0+yy+6),radius=2,outline=c,width=2)
        else:
            d.ellipse((x0+8,y0+7,x0+27,y0+26),outline=c,width=2); d.line((x0+27,y0+17,x0+41,y0+17),fill=c,width=2); d.line((x0+35,y0+11,x0+41,y0+17),fill=c,width=2); d.line((x0+35,y0+23,x0+41,y0+17),fill=c,width=2)
    elif icon=='trade':
        c=green; d.line((x0+4,y0+12,x0+40,y0+12),fill=c,width=2); d.line((x0+33,y0+7,x0+40,y0+12),fill=c,width=2); d.line((x0+33,y0+17,x0+40,y0+12),fill=c,width=2); d.line((x0+40,y0+28,x0+4,y0+28),fill=c,width=2); d.line((x0+11,y0+23,x0+4,y0+28),fill=c,width=2); d.line((x0+11,y0+33,x0+4,y0+28),fill=c,width=2)
    elif icon=='raw_data':
        c=col; d.line([(x0+2,y0+28),(x0+11,y0+15),(x0+20,y0+24),(x0+29,y0+9),(x0+42,y0+19)],fill=c,width=2,joint='curve')
    elif icon=='window':
        c=col; d.line((x0+5,y0+7,x0+40,y0+7),fill=c,width=2); d.line((x0+12,y0+7,x0+18,y0+19,x0+18,y0+31,x0+27,y0+31,x0+27,y0+19,x0+33,y0+7),fill=c,width=2)
    elif icon=='average':
        c=green; 
        for px in (x0+7,x0+18,x0+29): d.ellipse((px-3,y0+16,px+3,y0+22),outline=c,width=2)
        d.line((x0+32,y0+19,x0+41,y0+19),fill=c,width=2); d.line((x0+37,y0+14,x0+41,y0+19),fill=c,width=2); d.line((x0+37,y0+24,x0+41,y0+19),fill=c,width=2)
    elif icon=='mental':
        c=col; d.ellipse((x0+8,y0+7,x0+34,y0+33),outline=c,width=2); d.ellipse((x0+15,y0+14,x0+27,y0+26),outline=c,width=2); d.ellipse((x0+19,y0+18,x0+23,y0+22),fill=c)
    elif icon=='question':
        c=col; f=_font(25,True,False); d.text((x0+14,y0+2),'?',font=f,fill=c)
    elif icon=='mechanism':
        c=col; d.rounded_rectangle((x0+1,y0+12,x0+14,y0+25),radius=2,outline=c,width=2); d.line((x0+15,y0+19,x0+29,y0+19),fill=c,width=2); d.line((x0+24,y0+14,x0+29,y0+19),fill=c,width=2); d.line((x0+24,y0+24,x0+29,y0+19),fill=c,width=2); d.rounded_rectangle((x0+30,y0+12,x0+43,y0+25),radius=2,outline=c,width=2)
    else:
        c=amber; d.ellipse((x0+13,y0+5,x0+31,y0+23),outline=c,width=2); d.line((x0+18,y0+23,x0+26,y0+23),fill=c,width=2); d.line((x0+19,y0+28,x0+25,y0+28),fill=c,width=2)
    return (x+w/2,y+h/2)


_SUMMARY_CACHE={}


def _summary_key(obj,cfg):
    import json
    raw=json.dumps({"obj":obj,"ink":cfg.get("ink"),"accent":cfg.get("accent"),"positive":cfg.get("positive"),"accent2":cfg.get("accent2")},sort_keys=True,ensure_ascii=False)
    return hashlib.sha1(raw.encode("utf-8")).hexdigest()


def _summary_layout(card_count:int, w:int, h:int):
    """Responsive recap layouts with explicit safe zones for title/icon/copy.

    The recap is a product surface, not a miniature storyboard. Card geometry is
    chosen first, then typography and glyphs are fitted into those bounds.
    """
    n=max(1,min(8,int(card_count)))
    if n == 1:
        return [((w-900)//2,188)],900,350
    if n == 2:
        card_w,card_h=555,350; gap=34; x0=(w-2*card_w-gap)//2
        return [(x0,188),(x0+card_w+gap,188)],card_w,card_h
    if n == 3:
        card_w,card_h=380,330; gap=22; x0=(w-3*card_w-2*gap)//2
        return [(x0+i*(card_w+gap),188) for i in range(3)],card_w,card_h
    if n == 4:
        card_w,card_h=548,248; gap_x,gap_y=24,20; x0=(w-2*card_w-gap_x)//2
        return [(x0,184),(x0+card_w+gap_x,184),(x0,452),(x0+card_w+gap_x,452)],card_w,card_h
    if n == 5:
        card_w,card_h=366,235; gap=22; x0=(w-3*card_w-2*gap)//2
        return [(x0+i*(card_w+gap),184) for i in range(3)]+[(x0+(card_w+gap)//2,449),(x0+(card_w+gap)//2+card_w+gap,449)],card_w,card_h
    if n == 6:
        card_w,card_h=374,238; gap_x,gap_y=20,18; x0=(w-3*card_w-2*gap_x)//2; y0=182
        return [(x0+(i%3)*(card_w+gap_x),y0+(i//3)*(card_h+gap_y)) for i in range(6)],card_w,card_h
    if n == 7:
        card_w,card_h=302,226; gap=18; x0=(w-4*card_w-3*gap)//2
        pos=[(x0+i*(card_w+gap),180) for i in range(4)]
        x1=(w-3*card_w-2*gap)//2; pos += [(x1+i*(card_w+gap),434) for i in range(3)]
        return pos,card_w,card_h
    card_w,card_h=302,226; gap=18; x0=(w-4*card_w-3*gap)//2
    return [(x0+(i%4)*(card_w+gap),180+(i//4)*(card_h+gap)) for i in range(8)],card_w,card_h


def _draw_summary_card(base, card, cx, cy, card_w, card_h, i, cfg, bg, accent):
    """Render a recap card with non-overlapping title, glyph and takeaway zones."""
    d=ImageDraw.Draw(base)
    _soft_shadow_card(base,(cx,cy,cx+card_w,cy+card_h),radius=24,fill=bg,outline="#E5E7EB")
    # Number badge.
    d.ellipse((cx+18,cy+16,cx+54,cy+52),fill=_rgb(accent))
    _draw_ui_text(base,str(i+1),cx+29,cy+21,16,'#FFFFFF',bold=True,max_width=18)
    # Semantic icon badge. The glyph itself is unique; the container is deliberately
    # consistent so the board feels like one product surface.
    badge=(cx+card_w-68,cy+14,cx+card_w-18,cy+64)
    d.rounded_rectangle(badge,radius=15,fill=_rgb('#FFFFFF'),outline=_rgb(accent),width=2)
    _summary_icon(base,card,badge[0]+4,badge[1]+4,badge[2]-badge[0]-8,badge[3]-badge[1]-8,{**cfg,'accent':accent,'positive':accent,'accent2':accent})

    title=str(card.get('title','')).strip()
    title_max_w=max(110,card_w-150)
    title_size=_fit_ui_text(title,title_max_w,21 if card_w>=360 else 18,bold=True,min_size=15)
    # Explicitly cap the title to two lines. The compiler should keep titles short;
    # this is a final renderer safety net.
    title_lines=_wrap_words(title,title_max_w,title_size,True)[:2]
    yy=cy+17
    for line in title_lines:
        _draw_ui_text(base,line,cx+68,yy,title_size,cfg['ink'],bold=True,max_width=title_max_w)
        yy += title_size*1.10+1

    divider_y=cy+78
    d.line((cx+22,divider_y,cx+card_w-22,divider_y),fill=_rgb('#D8DDE5'),width=1)

    # The icon occupies a hard 52px band. Nothing below this y-coordinate is
    # allowed to be drawn by the summary glyph renderer.
    icon_top=cy+86; icon_bottom=cy+140
    # Prefer a short visual phrase over a full sentence. The narration carries
    # nuance; the recap carries the mental model. This is intentionally large so
    # the summary remains useful when paused or viewed on a phone.
    phrase=str(card.get('phrase', '')).strip()
    support=str(card.get('support', card.get('takeaway',''))).strip()
    tx=cx+22; ty=cy+154; max_w=card_w-44
    if phrase:
        phrase_size=_fit_ui_text(phrase,max_w,31 if card_w>=360 else 27,bold=True,min_size=18)
        phrase_lines=_wrap_words(phrase,max_w,phrase_size,True)[:3]
        yy=ty
        for line in phrase_lines:
            _draw_ui_text(base,line,tx,yy,phrase_size,card.get('color',cfg['ink']),bold=True,max_width=max_w,line_gap=1)
            yy += phrase_size*1.05+2
        # Deliberately omit the explanatory support copy. Narration is the
        # explanation channel; the recap is a visual memory aid and should not
        # turn into five mini paragraphs.
    else:
        takeaway=support
        avail_h=max(48,card_h-(ty-cy)-20)
        size=_fit_ui_text(takeaway,max_w,17 if card_w>=360 else 15,bold=False,min_size=12)
        lines=_wrap_words(takeaway,max_w,size,False)
        while len(lines)*size*1.18 + max(0,len(lines)-1)*2 > avail_h and size>11:
            size-=1; lines=_wrap_words(takeaway,max_w,size,False)
        yy=ty
        for line in lines:
            _draw_ui_text(base,line,tx,yy,size,card.get('color',cfg['ink']),bold=False,max_width=max_w,line_gap=1)
            yy += size*1.18+1

    d.line((cx+22,cy+card_h-14,cx+72,cy+card_h-14),fill=_rgb(accent),width=3)


def _render_summary_full(obj,cfg):
    w=int(obj.get('width',1280)); h=int(obj.get('height',720)); layer=Image.new('RGBA',(w,h),(0,0,0,0)); d=ImageDraw.Draw(layer)
    cards=obj.get('cards',[])[:8]; count=len(cards)
    title=str(obj.get('title',f'{count} KEY TAKEAWAYS')).strip(); subtitle=str(obj.get('subtitle','What to remember')).strip()
    # Editorial canvas: larger header, strong hierarchy, soft color orbs and a
    # deliberately generous card grid. Nothing is allowed to be cropped.
    d.rounded_rectangle((34,16,w-34,h-24),radius=30,fill=_rgb('#FFFDFC'),outline=_rgb('#E8E5DE'),width=2)
    d.ellipse((w-150,28,w-72,106),fill=_rgb('#EEF2FF'))
    d.ellipse((w-112,62,w-48,126),fill=_rgb('#ECFDF5'))
    _draw_ui_text(layer,"SKETCHVOX • VISUAL RECAP",64,38,15,cfg['accent'],bold=True,max_width=320)
    # The title is a single-line headline whenever possible. This prevents the
    # previous title/subtitle collision that made the recap look clipped.
    title_size=_fit_ui_text(title,1010,34,bold=True,min_size=24)
    _draw_ui_text(layer,title,64,68,title_size,cfg['ink'],bold=True,max_width=1010)
    _draw_ui_text(layer,subtitle,66,119,17,cfg['muted'],bold=False,max_width=900)
    d.line((64,153,w-64,153),fill=_rgb('#E3E0D8'),width=2)
    # Three tiny progress dots communicate that this is the end-of-story recap.
    for i,col in enumerate((cfg['accent'],cfg['positive'],cfg['accent2'])):
        d.ellipse((66+i*18,162,74+i*18,170),fill=_rgb(col))
    positions,card_w,card_h=_summary_layout(count,w,h)
    palette=[('#EEF2FF','#4F46E5'),('#ECFDF5','#059669'),('#FFF7ED','#D97706'),('#FDF2F8','#DB2777'),('#EFF6FF','#2563EB'),('#F5F3FF','#7C3AED')]
    for i,card in enumerate(cards):
        cx,cy=positions[i]
        bg,accent=palette[i%len(palette)]
        _draw_summary_card(layer,card,cx,cy,card_w,card_h,i,cfg,bg,accent)
    return layer


def _draw_summary_board(base, obj, p, cfg):
    x=float(obj.get('x',0)); y=float(obj.get('y',0)); w=float(obj.get('width',1280)); h=float(obj.get('height',720))
    p=ease(p,'ease_out'); key=_summary_key(obj,cfg)
    if key not in _SUMMARY_CACHE:
        _SUMMARY_CACHE[key]=_render_summary_full(obj,cfg)
    layer=_SUMMARY_CACHE[key]
    # Header is intentionally kept intact; the old 120px crop clipped subtitles
    # and was exactly the bug found by rendered-frame QA in v3.8.
    header_h=178
    base.alpha_composite(layer.crop((0,0,int(w),header_h)),(int(x),int(y)))
    cards=obj.get('cards',[])[:8]
    positions,card_w,card_h=_summary_layout(len(cards),int(w),int(h))
    active_endpoint=(x+w-70,y+155)
    count=max(1,len(cards))
    reveal_total=max(0.80,min(2.8,0.62+0.42*count))
    gap=0.12 if count<=4 else 0.08
    step=max(0.18,(reveal_total-gap*count)/max(1,count))
    # `p` is normalized to the full summary reveal. Convert the timeline below
    # into the same 0..1 domain so p=1 always means every card is complete.
    reveal_progress=p*reveal_total
    for i in range(count):
        cstart=i*(step+gap); reveal_d=max(0.18,step)
        cp=max(0,min(1,(reveal_progress-cstart)/reveal_d))
        if cp<=0: continue
        cx,cy=positions[i]
        # Rounded clipping mask reveals the whole card from left to right. Unlike
        # a raw rectangular crop, it never cuts the card's text at the edge once
        # the reveal completes.
        reveal_w=max(2,int(card_w*min(1,cp*1.10)))
        crop=layer.crop((cx,cy,cx+card_w,cy+card_h))
        mask=Image.new('L',(card_w,card_h),0); md=ImageDraw.Draw(mask)
        md.rounded_rectangle((0,0,reveal_w,card_h),radius=24,fill=255)
        crop.putalpha(Image.composite(crop.getchannel('A'),Image.new('L',(card_w,card_h),0),mask))
        base.alpha_composite(crop,(int(x+cx),int(y+cy)))
        if cp<1:
            active_endpoint=(x+cx+reveal_w,y+cy+card_h*0.08)
        else:
            active_endpoint=(x+cx+card_w,y+cy+card_h*0.08)
    return active_endpoint


def _draw_visual_pulse(frame, scene, elapsed, cfg):
    """Very small motion cue used only when rendered QA detects a dead hold.

    It is deliberately a vector accent rather than a camera transform, so QA
    repair remains cheap and does not blur the educational artwork.
    """
    if not scene.get("visual_accent_pulse"):
        return
    d=ImageDraw.Draw(frame)
    phase=(float(elapsed)*1.8)%1.0
    pulse=0.5+0.5*math.sin(phase*2*math.pi)
    cx,cy=1170,78
    r=int(4+4*pulse)
    col=_rgb(cfg.get('accent','#4F46E5'))
    for i,dx in enumerate((-18,0,18)):
        rr=max(2,r-(i%2)*2)
        d.ellipse((cx+dx-rr,cy-rr,cx+dx+rr,cy+rr),fill=col+(int(80+100*pulse),))


def _draw_scene_chrome(frame, scene, scene_index, total_scenes, cfg):
    """Subtle editorial framing that makes otherwise sparse scenes feel authored."""
    if scene.get('no_chrome') or any(o.get('type')=='summary_board' for o in scene.get('objects',[])):
        return
    w,h=frame.size
    accent=_rgb(scene.get('accent',cfg.get('accent','#4F46E5')))
    # Soft corner accents stay behind the teaching marks. Draw them on an overlay
    # so their alpha is composited rather than accidentally making the base frame transparent.
    overlay=Image.new('RGBA',(w,h),(0,0,0,0)); od=ImageDraw.Draw(overlay)
    od.ellipse((w-132,-28,w+18,122),fill=accent+(20,))
    od.ellipse((-42,h-116,84,h+10),fill=_rgb(cfg.get('positive','#10B981'))+(16,))
    frame.alpha_composite(overlay)
    d=ImageDraw.Draw(frame)
    # Chapter pill in the quiet top-right area.
    label=f"{scene_index:02d} / {max(1,total_scenes)}"
    f=_font(15,True,False)
    tw=int(d.textlength(label,font=f))+28
    x=w-tw-52; y=30
    d.rounded_rectangle((x,y,x+tw,y+34),radius=17,fill=_rgb('#FFFFFF'),outline=accent,width=2)
    d.text((x+14,y+8),label,font=f,fill=accent)
    # Progress rail near the bottom gives the viewer a sense of movement without
    # turning the video into a slideshow UI.
    rail_x1,rail_x2=62,w-62; rail_y=h-26
    d.rounded_rectangle((rail_x1,rail_y-2,rail_x2,rail_y+2),radius=2,fill=_rgb('#E7E5E4'))
    active_x=rail_x1+(rail_x2-rail_x1)*(scene_index/max(1,total_scenes))
    d.rounded_rectangle((rail_x1,rail_y-3,active_x,rail_y+3),radius=3,fill=accent)
    # A small hand-drawn accent mark, deliberately not a standard rectangle.
    d.line((w-115,h-50,w-82,h-62),fill=accent,width=2)
    d.line((w-82,h-62,w-68,h-48),fill=accent,width=2)


def _transition(base,mode,p,cfg):
    if mode=='none': return base
    if mode=='fade':
        overlay=Image.new('RGBA',base.size,_rgb(cfg['background'])+(int(255*(1-p)),)); return Image.alpha_composite(base,overlay)
    if mode=='wipe':
        out=Image.new('RGBA',base.size,_rgb(cfg['background'])+(255,)); x=int(base.width*p); out.alpha_composite(base.crop((0,0,x,base.height)),(0,0)); return out
    return base


def _paper_background(width, height, cfg):
    base=Image.new("RGBA",(width,height),_rgb(cfg["background"])+(255,))
    if not cfg.get("texture",True):
        return base
    arr=np.array(base.convert("RGB")).astype(np.int16)
    rng=np.random.default_rng(12345)
    noise=rng.normal(0,0.55,(height,width,1))
    arr=np.clip(arr+noise,0,255).astype(np.uint8)
    return Image.fromarray(arr).convert("RGBA")


def _render_worldclass_once(project, out_path, cfg):
    """Render one deterministic pass. The caller may wrap this with visual QA."""
    W,H,fps=cfg['width'],cfg['height'],cfg['fps']
    scenes=project.get('scenes',[])
    Path(out_path).parent.mkdir(parents=True,exist_ok=True)
    writer=cv2.VideoWriter(str(out_path),cv2.VideoWriter_fourcc(*'mp4v'),fps,(W,H))
    if not writer.isOpened():
        raise RuntimeError(f"Could not open video writer for {out_path}")
    paper_bg=_paper_background(W,H,cfg); canvas=paper_bg.copy(); previous_endpoint=(W*0.5,H*0.5)
    for si,scene in enumerate(scenes):
        dur=float(scene.get('duration',5)); n=max(1,int(round(dur*fps))); transition=scene.get('transition','wipe' if si else 'none'); clear=bool(scene.get('clear_board',False))
        if clear: canvas=paper_bg.copy()
        # IMPORTANT: every animation frame must start from the same clean scene
        # base.  Reusing the previous raster frame causes progressive text to be
        # painted on top of itself (e.g. "₹10,000" becoming visual gibberish).
        # Completed objects are redrawn from their deterministic final state on
        # every frame; only the final clean composition is carried to the next
        # scene.
        scene_base=canvas.copy()
        objects=sorted(scene.get('objects',[]),key=lambda o:(float(o.get('z',0)),float(o.get('start',0))))
        last_frame=scene_base.copy(); last_endpoint=previous_endpoint
        for fi in range(n):
            t=fi/max(1,n-1); elapsed=t*dur; frame=scene_base.copy(); endpoint=previous_endpoint; active=None; active_p=0
            _draw_scene_chrome(frame, scene, si+1, len(scenes), cfg)
            for obj in objects:
                start=float(obj.get('start',0)); od=float(obj.get('duration',max(0.45,dur-start-0.2))); p=(elapsed-start)/max(0.001,od)
                if p<=0: continue
                cp=min(1,p); endpoint=draw_vector_object(frame,obj,cp,cfg)
                if 0<=p<=1.05:
                    active=obj; active_p=min(1,max(0,p))
            if clear and transition!='none' and t<0.22:
                frame=_transition(frame,transition,min(1,t/0.22),cfg)
            _draw_visual_pulse(frame,scene,elapsed,cfg)
            if cfg.get('hand') and active and active_p<0.98 and active.get('hand_follow',True):
                dx=endpoint[0]-last_endpoint[0]; dy=endpoint[1]-last_endpoint[1]
                angle=float(cfg.get('hand_angle',0.0))
                if active.get('hand_angle') is not None: angle=float(active['hand_angle'])
                elif abs(dx)+abs(dy)>30 and active.get('rotate_hand'):
                    angle=max(-16,min(16,math.degrees(math.atan2(dy,dx))-35))
                paste_hand(frame,endpoint,cfg.get('hand_scale',0.27),angle)
            frame=frame_transform(frame,scene,t,W,H)
            writer.write(cv2.cvtColor(np.array(frame.convert('RGB')),cv2.COLOR_RGB2BGR)); last_frame=frame; last_endpoint=endpoint
        # Carry forward a clean, fully revealed composition — never a frame that
        # contains the transient hand, transition mask, or partially revealed text.
        final_canvas=scene_base.copy(); final_endpoint=previous_endpoint
        for obj in objects:
            final_endpoint=draw_vector_object(final_canvas,obj,1.0,cfg)
        canvas=final_canvas.copy(); previous_endpoint=final_endpoint
    writer.release()
    return str(out_path)


def _inspect_rendered_video_isolated(video_path, project, width, height, fps, hand, per_scene=4):
    """Run raster QA in a child process so OpenCV writer/reader resources are isolated."""
    with tempfile.TemporaryDirectory(prefix='sketchvox_qa_') as td:
        td=Path(td); project_file=td/'project.json'; report_file=td/'report.json'
        project_file.write_text(json.dumps(project,ensure_ascii=False),encoding='utf-8')
        cmd=[sys.executable,'-m','whiteboard_engine.qa_worker',str(Path(video_path).resolve()),str(project_file),str(report_file)]
        root=Path(__file__).resolve().parents[1]
        proc=subprocess.run(cmd,cwd=str(root),capture_output=True,text=True)
        if proc.returncode!=0:
            raise RuntimeError('Isolated rendered-frame QA failed: '+(proc.stderr or proc.stdout or 'unknown error'))
        return json.loads(report_file.read_text(encoding='utf-8'))


def render_worldclass(project,out_path,config=None):
    """Render with transactional rendered-frame QA and rollback-safe repair.

    Every repair is a candidate until its actual MP4 is rendered and inspected.
    The previous validated state is retained as the best-known-good artifact.
    """
    cfg={
        'width':1280,'height':720,'fps':30,'background':'#FCFBF7','ink':'#20242B','accent':'#4F46E5',
        'accent2':'#F59E0B','positive':'#10B981','danger':'#EF4444','muted':'#64748B',
        'hand':True,'hand_scale':0.22,'hand_angle':0.0,'style':'modern_doodle','texture':True,
        'qa_strict':False,'qa_standard_strict':True,'visual_qa':True,'visual_qa_repair':True,
        'visual_qa_passes':12,'visual_qa_samples':4,'return_details':False,'ocr_required':True,
    }
    if config: cfg.update(config)
    W,H,fps=cfg['width'],cfg['height'],cfg['fps']
    from .visual_qa import inspect_rendered_video, repair_project_for_visual_qa
    from .repair_governor import project_repair_score, provenance_stamp, is_better, is_blocking_issue

    working=normalize_project(deepcopy(project)); working=sync_project_timing(working); working=auto_layout_project(working,W,H)
    visual_report={"ok":True,"issues":[],"samples":0}; actions=[]; pass_history=[]; issue_signatures=[]; seen_signatures=set()
    passes=max(1,int(cfg.get('visual_qa_passes',12))) if cfg.get('visual_qa',True) else 1
    best_score=(999,999,999); best_project=deepcopy(working); best_report=None
    out_path=Path(out_path); out_path.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='sketchvox_repair_governor_') as td:
        candidate_path=Path(td)/'candidate.mp4'
        for attempt in range(passes):
            qa=qa_report(working,W,H)
            if cfg.get('qa_strict') and not qa['ok'] and not cfg.get('visual_qa_repair',True):
                raise ValueError('Visual preflight QA failed: '+str(qa['issues']))
            _render_worldclass_once(working,out_path,cfg)
            visual_report=_inspect_rendered_video_isolated(out_path,working,W,H,fps,hand=bool(cfg.get('hand')),per_scene=int(cfg.get('visual_qa_samples',4))) if cfg.get('visual_qa',True) else {'ok':True,'issues':[],'samples':0}
            score=project_repair_score(qa,visual_report)
            if score < best_score:
                best_score=score; best_project=deepcopy(working); best_report=deepcopy(visual_report)
            current_issues=qa.get('issues',[])+visual_report.get('issues',[])
            signature=tuple(sorted((str(i.get('code')),int(i.get('scene') or 0),str(i.get('object_id') or '')) for i in current_issues if i.get('severity') in {'error','warning'}))
            repeated=bool(signature) and signature in seen_signatures
            if signature: seen_signatures.add(signature); issue_signatures.append({'pass':attempt+1,'signature':[list(x) for x in signature],'repeated':repeated})
            pass_history.append({'pass':attempt+1,'preflight_issues':len(qa.get('issues',[])),'rendered_issues':len(visual_report.get('issues',[])),'rendered_errors':sum(1 for i in visual_report.get('issues',[]) if i.get('severity')=='error'),'score':score,'issue_signature':[list(x) for x in signature],'repeated_signature':repeated,'committed':True})
            blocking_preflight=any(is_blocking_issue(i, bool(cfg.get('qa_standard_strict'))) for i in qa.get('issues',[]))
            blocking_rendered=any(is_blocking_issue(i, bool(cfg.get('qa_standard_strict'))) for i in visual_report.get('issues',[]))
            if not blocking_preflight and not blocking_rendered:
                break
            if not cfg.get('visual_qa_repair',True) or attempt >= passes-1 or repeated:
                if repeated: actions.append('stopped: repeated diagnostic signature; retained best validated state')
                break

            candidate,new_actions=repair_project_for_visual_qa(working,visual_report if visual_report.get('issues') else qa,W,H)
            repair_id=f'v44-r{attempt+1}'
            candidate=provenance_stamp(candidate,repair_id)
            candidate=normalize_project(candidate)
            if json_fingerprint(candidate)==json_fingerprint(working):
                actions.append('stopped: repair produced no deterministic change')
                break
            _render_worldclass_once(candidate,candidate_path,cfg)
            candidate_visual=_inspect_rendered_video_isolated(candidate_path,candidate,W,H,fps,hand=bool(cfg.get('hand')),per_scene=int(cfg.get('visual_qa_samples',4)))
            candidate_preflight=qa_report(candidate,W,H)
            candidate_score=project_repair_score(candidate_preflight,candidate_visual)
            if is_better(candidate_score,best_score):
                # Candidate is strictly better than the best state seen so far.
                import shutil
                shutil.copy2(candidate_path,out_path)
                working=candidate; actions.extend(new_actions); best_score=candidate_score; best_project=deepcopy(candidate); best_report=deepcopy(candidate_visual)
                pass_history[-1]['candidate_score']=candidate_score; pass_history[-1]['candidate_committed']=True
            else:
                actions.append(f'rejected repair candidate {repair_id}: score {candidate_score} was not better than best {best_score}')
                pass_history[-1]['candidate_score']=candidate_score; pass_history[-1]['candidate_committed']=False
                break

    working=best_project
    final_preflight=qa_report(working,W,H)
    if best_report is not None: visual_report=best_report
    final_report={'preflight':final_preflight,'rendered_frame_qa':visual_report,'repair_actions':actions,'pass_history':pass_history,'passes_attempted':len(pass_history),'issue_signatures':issue_signatures,'standard':'strict_no_known_visual_defects','best_score':best_score,'rollback_safe':True}
    blocking_errors=any(i.get('severity')=='error' for i in final_preflight.get('issues',[])+visual_report.get('issues',[]))
    blocking_warnings=any(is_blocking_issue(i, bool(cfg.get('qa_standard_strict'))) and i.get('severity')=='warning' for i in final_preflight.get('issues',[])+visual_report.get('issues',[]))
    final_report['ok']=not blocking_errors and not blocking_warnings
    report_path=out_path.with_suffix('.visual-qa.json')
    report_path.write_text(json.dumps(final_report,indent=2,ensure_ascii=False),encoding='utf-8')
    if cfg.get('qa_strict') and not final_report['ok']:
        raise ValueError('Rendered-frame visual QA failed:\n'+json.dumps(final_report,indent=2))
    return (str(out_path),working,final_report) if cfg.get('return_details') else str(out_path)


def json_fingerprint(value):
    import json as _json, hashlib as _hashlib
    return _hashlib.sha1(_json.dumps(value,sort_keys=True,ensure_ascii=False,default=str).encode('utf-8')).hexdigest()

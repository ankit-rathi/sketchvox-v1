"""Transactional rendered-QA repair governor.

A repair is a candidate until its actual MP4 has been rendered and inspected.
The governor never replaces a known-better state with a worse state.
"""
from __future__ import annotations
from copy import deepcopy
from typing import Any

ADVISORY={"STATIC_HOLD","VISUAL_REPETITION","SEMANTIC_FLOW_WEAK","SUMMARY_QA_INTERNAL","TEXT_OVERDENSE","FRAME_EDGE_INK","HAND_STROKE_MISMATCH","NEAR_EDGE"}


def is_blocking_issue(issue: dict[str, Any], strict: bool = True) -> bool:
    """Return whether an issue should prevent a strict production render."""
    sev=str(issue.get("severity", "")).lower()
    if sev == "error":
        return True
    if sev == "warning" and strict and issue.get("code") not in ADVISORY:
        return True
    return False

def issue_score(report: dict[str,Any]) -> tuple[int,int,int]:
    issues=report.get("issues",[]) or []
    errors=sum(1 for i in issues if i.get("severity")=="error")
    warnings=sum(1 for i in issues if i.get("severity")=="warning" and i.get("code") not in ADVISORY)
    advisory=sum(1 for i in issues if i.get("severity")=="warning" and i.get("code") in ADVISORY)
    # Lexicographic ordering gives blocking errors absolute priority.
    return (errors,warnings,advisory)

def project_repair_score(preflight: dict[str,Any], rendered: dict[str,Any]) -> tuple[int,int,int]:
    merged={"issues":list(preflight.get("issues",[]))+list(rendered.get("issues",[]))}
    return issue_score(merged)

def provenance_stamp(project: dict[str,Any], repair_id: str) -> dict[str,Any]:
    out=deepcopy(project)
    for scene in out.get("scenes",[]):
        for obj in scene.get("objects",[]):
            if obj.get("generated_by") and obj.get("generated_by") != "director":
                obj.setdefault("authored",False)
                obj.setdefault("repair_id",repair_id)
                obj.setdefault("repair_priority","generated")
    return out

def is_better(candidate: tuple[int,int,int], current: tuple[int,int,int]) -> bool:
    return candidate < current

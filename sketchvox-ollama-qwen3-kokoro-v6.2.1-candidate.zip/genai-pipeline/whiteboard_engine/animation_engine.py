"""SketchVox animation grammar.

The animation engine is deliberately semantic. Directors request actions such as
DRAW, REVEAL, TRANSFORM, CONNECT, COMPARE, GROW and PAN rather than hard-coding
frame-by-frame animation. The deterministic renderer turns these tracks into
progressive vector reveals, hand choreography and camera cues.
"""
from __future__ import annotations
from copy import deepcopy
from typing import Any

PRIMITIVES = {
    "DRAW", "WRITE", "REVEAL", "GROW", "MORPH", "CONNECT", "TRACE", "HIGHLIGHT",
    "ZOOM", "PAN", "STACK", "SORT", "COMPARE", "COUNT", "TRANSFORM", "FLOW",
    "PULSE", "CIRCLE", "UNDERLINE", "MAGNIFY", "SPLIT", "MERGE", "BUILD", "ERASE",
}

# Conservative defaults keep the engine deterministic and render-friendly.
DEFAULTS = {
    "DRAW": 0.70, "WRITE": 0.75, "REVEAL": 0.60, "GROW": 0.85,
    "MORPH": 0.80, "CONNECT": 0.55, "TRACE": 0.70, "HIGHLIGHT": 0.45,
    "ZOOM": 1.10, "PAN": 1.00, "STACK": 0.75, "SORT": 0.80,
    "COMPARE": 0.70, "COUNT": 0.70, "TRANSFORM": 0.90, "FLOW": 0.80,
    "PULSE": 0.50, "CIRCLE": 0.55, "UNDERLINE": 0.40, "MAGNIFY": 0.80,
    "SPLIT": 0.75, "MERGE": 0.75, "BUILD": 0.85, "ERASE": 0.60,
}


def track(action: str, target: str | None = None, start: float = 0.0,
          duration: float | None = None, **kwargs: Any) -> dict[str, Any]:
    action = str(action).upper()
    if action not in PRIMITIVES:
        raise ValueError(f"Unsupported SketchVox animation primitive: {action}")
    return {
        "action": action,
        "target": target,
        "start": round(float(start), 3),
        "duration": round(float(duration if duration is not None else DEFAULTS[action]), 3),
        **kwargs,
    }


def add_track(scene: dict[str, Any], action: str, target: str | None = None,
              start: float = 0.0, duration: float | None = None, **kwargs: Any) -> None:
    scene.setdefault("animation", {}).setdefault("tracks", []).append(
        track(action, target, start, duration, **kwargs)
    )


def compile_animation(scene: dict[str, Any]) -> dict[str, Any]:
    """Compile object motion metadata into a deterministic animation contract.

    Existing authored start/duration values remain authoritative. The compiler
    only fills missing semantic animation metadata and derives a compact track
    list for QA, hand choreography and future motion backends.
    """
    out = deepcopy(scene)
    tracks = list(out.get("animation", {}).get("tracks", []))
    if not tracks:
        for obj in out.get("objects", []):
            oid = obj.get("id")
            motion = str(obj.get("motion", "DRAW")).upper()
            if motion not in PRIMITIVES:
                motion = "DRAW"
            tracks.append(track(motion, oid, float(obj.get("start", 0)), float(obj.get("duration", 0.7)),
                                semantic_role=obj.get("semantic_role")))
    out.setdefault("animation", {})["tracks"] = tracks
    out["animation"]["contract"] = "semantic_animation_v1"
    out["animation"]["primitive_set"] = sorted(PRIMITIVES)
    out["animation"]["hand_actor"] = bool(out.get("hand_actor", True))
    return out


def choreograph_scene(scene: dict[str, Any]) -> dict[str, Any]:
    """Make progressive drawing order explicit without changing authored geometry."""
    out = compile_animation(scene)
    objs = out.get("objects", [])
    for idx, obj in enumerate(objs):
        obj.setdefault("draw_order", idx)
        if obj.get("type") in {"arrow", "line"}:
            obj.setdefault("animation_role", "connector")
        elif obj.get("type") in {"person", "money", "coin", "chart", "token_strip", "ratio"}:
            obj.setdefault("animation_role", "illustration")
        elif obj.get("type") in {"text", "equation", "number"}:
            obj.setdefault("animation_role", "label")
    out["animation"]["draw_order"] = [o.get("id") for o in sorted(objs, key=lambda x: (float(x.get("z", 0)), int(x.get("draw_order", 0))))]
    return out

"""End-to-end deterministic verification for SketchVox visual storytelling pass."""
from __future__ import annotations
import json, subprocess, sys, time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from whiteboard_engine.deterministic_director import build_plan
from whiteboard_engine.scene_graph import normalize_project, validate_v2
from whiteboard_engine.qa import qa_report
from whiteboard_engine.renderer_worldclass import render_worldclass

OUT=ROOT/'output'/'verification'; OUT.mkdir(parents=True,exist_ok=True)
TOPICS=[
    "What is RAG in AI?",
    "What is compound interest?",
    "What is an ETF?",
    "What is a moving average?",
]

def probe(path:Path):
    import cv2
    cap=cv2.VideoCapture(str(path)); frames=int(cap.get(cv2.CAP_PROP_FRAME_COUNT)); fps=float(cap.get(cv2.CAP_PROP_FPS)); w=int(cap.get(cv2.CAP_PROP_FRAME_WIDTH)); h=int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT)); cap.release()
    return {"frames":frames,"fps":fps,"width":w,"height":h,"duration":frames/fps if fps else 0}

def main():
    import argparse
    ap=argparse.ArgumentParser()
    ap.add_argument("--render",action="store_true",help="force rerender instead of reusing existing MP4s")
    args=ap.parse_args()
    results=[]
    for idx,topic in enumerate(TOPICS,1):
        project=normalize_project(build_plan(topic))
        errors=validate_v2(project); qa=qa_report(project)
        if errors: raise AssertionError(f"{topic}: {errors}")
        if not qa["ok"]: raise AssertionError(f"{topic}: blocking QA errors {qa['issues']}")
        out=OUT/f"topic_{idx}.mp4"
        if args.render or not out.exists() or out.stat().st_size < 10000:
            t=time.time(); render_worldclass(project,out,{"hand":True,"texture":True}); elapsed=time.time()-t
        else:
            elapsed=0.0
        meta=probe(out)
        assert meta["width"]==1280 and meta["height"]==720 and meta["fps"]==30, meta
        assert meta["frames"]>0 and meta["duration"]<=60, meta
        results.append({"topic":topic,"render_seconds":round(elapsed,2),**meta})
    (OUT/'report.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
    print(json.dumps(results,indent=2))

if __name__=='__main__': main()

"""Narration-aware timing without requiring a TTS provider."""
from __future__ import annotations
import re

def estimate_speech_seconds(text:str, wpm:float=145.0, min_seconds:float=2.0, max_seconds:float=90.0)->float:
    words=len(re.findall(r"\b[\w₹%]+(?:[-'][\w₹%]+)*\b",text or ""))
    seconds=(words/max(wpm,1))*60
    # Add a little breathing room around punctuation.
    seconds += len(re.findall(r"[,.!?;:]",text or ""))*0.08
    return max(min_seconds,min(max_seconds,seconds))

def sync_scene_timing(scene:dict, pad:float=0.35)->dict:
    out=dict(scene)
    if str(scene.get("timing_mode","manual"))=="auto":
        out["duration"]=round(estimate_speech_seconds(scene.get("narration",""))+pad,2)
    dur=float(out.get("duration",5))
    objs=[]
    for obj in out.get("objects",[]):
        o=dict(obj)
        if o.get("timing") == "auto":
            o["start"]=round(float(o.get("start",0)),2)
            remaining=max(0.4,dur-float(o["start"])-0.2)
            o["duration"]=round(min(float(o.get("duration",remaining)),remaining),2)
        objs.append(o)
    out["objects"]=objs
    return out

def sync_project_timing(project:dict)->dict:
    out=dict(project); out["scenes"]=[sync_scene_timing(s) for s in project.get("scenes",[])]; return out


def fit_project_duration(project: dict, target_seconds: float, min_scene: float = 2.8) -> dict:
    """Fit a storyboard to a production budget without changing its story order."""
    out=__import__('copy').deepcopy(project)
    scenes=out.get("scenes",[])
    if not scenes: return out
    target=max(float(min_scene)*len(scenes),float(target_seconds)) if float(target_seconds) < float(min_scene)*len(scenes) else float(target_seconds)
    total=sum(max(0.1,float(s.get("duration",0))) for s in scenes)
    if total <= 0: return out
    scale=target/total
    for scene in scenes:
        old=max(0.1,float(scene.get("duration",1)))
        new=max(float(min_scene),old*scale)
        scene["duration"]=round(new,3)
        for obj in scene.get("objects",[]):
            st=float(obj.get("start",0))*new/old
            od=float(obj.get("duration",max(0.35,old-st-0.2)))*new/old
            obj["start"]=round(min(max(0.05,st),max(0.05,new-0.45)),3)
            obj["duration"]=round(max(0.18,min(od,new-obj["start"]-0.03)),3)

    # A memory board is a recap surface, not a second lesson. When a global
    # duration budget is larger than the authored story, do not let proportional
    # scaling turn the recap into a long static hold. Cap summary scenes at 10s
    # and redistribute the saved time across substantive scenes.
    summary_indices=[i for i,sc in enumerate(scenes) if any(o.get("type")=="summary_board" for o in sc.get("objects",[]))]
    if summary_indices:
        saved=0.0
        for i in summary_indices:
            sc=scenes[i]; old=float(sc["duration"]); new=min(10.0,old)
            if new < old:
                saved += old-new
                ratio=new/max(old,0.001); sc["duration"]=round(new,3)
                for obj in sc.get("objects",[]):
                    obj["start"]=round(min(float(obj.get("start",0))*ratio,max(0.05,new-0.45)),3)
                    obj["duration"]=round(max(0.18,min(float(obj.get("duration",0.5))*ratio,new-float(obj.get("start",0))-0.03)),3)
        recipients=[i for i in range(len(scenes)) if i not in summary_indices]
        if saved>0 and recipients:
            base=sum(float(scenes[i]["duration"]) for i in recipients)
            for i in recipients:
                sc=scenes[i]; old=float(sc["duration"]); new=old+saved*(old/max(base,0.001)); ratio=new/max(old,0.001); sc["duration"]=round(new,3)
                for obj in sc.get("objects",[]):
                    obj["start"]=round(min(float(obj.get("start",0))*ratio,max(0.05,new-0.45)),3)
                    obj["duration"]=round(max(0.18,min(float(obj.get("duration",0.5))*ratio,new-float(obj.get("start",0))-0.03)),3)
    out.setdefault("meta",{})["target_duration"]=round(sum(float(s["duration"]) for s in scenes),3)
    return out

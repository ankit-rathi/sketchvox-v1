"""Voiceover + narration-aware timing for SketchVox.

The renderer remains deterministic. Voiceover is a separate pass:
1. synthesize one audio file per scene from the scene narration;
2. measure the *actual* audio duration;
3. retime the scene and all of its visual beats to that duration;
4. render video; and
5. concatenate the scene audio and mux it into the MP4.

Providers are optional. `espeak` is included as an offline QA provider so the
entire synchronization pipeline can be tested without an API key.
"""
from __future__ import annotations

import json
import os
import re
import subprocess
import math
from copy import deepcopy
from pathlib import Path
from typing import Iterable


def audio_duration(path: str | Path) -> float:
    out = subprocess.check_output(
        ["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "default=nw=1:nk=1", str(path)],
        text=True,
    ).strip()
    return float(out)


def _run(cmd: list[str]) -> None:
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode:
        raise RuntimeError(result.stderr[-4000:])


def synthesize_espeak(text: str, out_path: str | Path, voice: str = "en", speed: int = 155) -> str:
    """Offline deterministic QA voice. Not intended as the production voice."""
    Path(out_path).parent.mkdir(parents=True, exist_ok=True)
    _run(["espeak", "-v", voice, "-s", str(speed), "-w", str(out_path), text])
    return str(out_path)


def _normalize_for_local_tts(text: str) -> str:
    """Make financial/technical notation easier for the offline voice engine."""
    t = str(text)
    replacements = {
        "₹": " rupees ",
        "%": " percent ",
        "×": " times ",
        "÷": " divided by ",
        "→": " leads to ",
        "—": ", ",
        "–": ", ",
        "…": "...",
    }
    for a, b in replacements.items():
        t = t.replace(a, b)
    # Keep the cadence readable instead of letting long punctuation runs become
    # unnatural pauses.
    t = re.sub(r"\s+", " ", t).strip()
    t = re.sub(r",\s*,+", ", ", t)
    return t


def synthesize_local_studio(text: str, out_path: str | Path, voice: str | None = None,
                            speed: int = 160, pitch: int = 48, amplitude: int = 102,
                            word_gap: int = 1) -> str:
    """Higher-quality offline voice using the system eSpeak engine + mastering.

    This remains fully local: no API, cloud call, or external AI service. The
    speech engine is deterministic, while FFmpeg adds gentle EQ/compression and
    loudness normalization so narration is less thin and less variable than the
    raw QA eSpeak track.
    """
    Path(out_path).parent.mkdir(parents=True, exist_ok=True)
    raw = Path(out_path).with_suffix('.raw.wav')
    voice = voice or os.getenv('SKETCHVOX_LOCAL_VOICE', 'en-us')
    speed = int(os.getenv('SKETCHVOX_LOCAL_SPEED', speed))
    pitch = int(os.getenv('SKETCHVOX_LOCAL_PITCH', pitch))
    amplitude = int(os.getenv('SKETCHVOX_LOCAL_AMPLITUDE', amplitude))
    word_gap = int(os.getenv('SKETCHVOX_LOCAL_WORD_GAP', word_gap))
    script = _normalize_for_local_tts(text)
    _run([
        'espeak', '-v', voice, '-s', str(int(speed)), '-p', str(int(pitch)),
        '-a', str(int(amplitude)), '-g', str(int(word_gap)), '-z', '-w', str(raw), script
    ])
    # Voice chain: remove rumble, soften harsh upper mids, control peaks, then
    # normalize to a podcast/voiceover-friendly loudness target.
    _run([
        'ffmpeg','-y','-i',str(raw),
        '-af',
        'highpass=f=70,lowpass=f=11000,'
        'acompressor=threshold=-19dB:ratio=2.2:attack=5:release=80:makeup=2,'
        'loudnorm=I=-16:TP=-1.5:LRA=7',
        '-ar','44100','-ac','1','-c:a','pcm_s16le',str(out_path)
    ])
    try:
        raw.unlink()
    except OSError:
        pass
    return str(out_path)


def synthesize_elevenlabs(text: str, out_path: str | Path, voice_id: str | None = None,
                          model_id: str = "eleven_multilingual_v2") -> str:
    # Lazy import keeps the offline renderer usable without requests/API keys.
    import requests
    api_key = os.getenv("ELEVENLABS_API_KEY")
    voice_id = voice_id or os.getenv("ELEVENLABS_VOICE_ID")
    if not api_key or not voice_id:
        raise RuntimeError("Set ELEVENLABS_API_KEY and ELEVENLABS_VOICE_ID for ElevenLabs voiceover.")
    url = f"https://api.elevenlabs.io/v1/text-to-speech/{voice_id}"
    r = requests.post(
        url,
        headers={"xi-api-key": api_key, "Content-Type": "application/json"},
        json={"text": text, "model_id": model_id},
        timeout=180,
    )
    r.raise_for_status()
    Path(out_path).write_bytes(r.content)
    return str(out_path)


def synthesize_gemini(text: str, out_path: str | Path, voice_name: str | None = None,
                      language: str = "English", style: str | None = None) -> str:
    """Gemini 3.8 TTS adapter using the current Interactions API.

    The same scene-timing interface is preserved: the returned WAV is measured
    after synthesis and drives visual retiming. A prebuilt, voice-design, or
    voice-replication ID can be supplied through SKETCHVOX_GEMINI_VOICE.
    """
    import base64
    from google import genai

    api_key = os.getenv("GEMINI_API_KEY") or os.getenv("GOOGLE_API_KEY")
    if not api_key:
        raise RuntimeError("Set GEMINI_API_KEY (or GOOGLE_API_KEY) for Gemini TTS.")
    client = genai.Client(api_key=api_key)
    model = os.getenv("SKETCHVOX_TTS_MODEL", "gemini-3.8-flash-tts")
    voice = voice_name or os.getenv("SKETCHVOX_GEMINI_VOICE", "Kore")
    style = style or os.getenv(
        "SKETCHVOX_GEMINI_STYLE",
        "warm, clear, confident educational narration; natural pacing; conversational but concise"
    )
    interaction = client.interactions.create(
        model=model,
        input=[{
            "type": "user_input",
            "content": [{
                "type": "text",
                "text": str(text),
                "annotations": [{"type": "speech_metadata", "style": style}],
            }],
        }],
        response_format={"type": "audio", "mime_type": "audio/wav", "sample_rate": 24000},
        generation_config={"speech_config": [{"voice": voice}]},
    )
    data = getattr(getattr(interaction, "output_audio", None), "data", None)
    if not data:
        raise RuntimeError("Gemini TTS returned no audio data.")
    Path(out_path).parent.mkdir(parents=True, exist_ok=True)
    Path(out_path).write_bytes(base64.b64decode(data))
    return str(out_path)


def synthesize_kokoro(text: str, out_path: str | Path, voice: str | None = None,
                      language: str = "english", speed: float | None = None) -> str:
    """Local Kokoro-82M TTS. No API key or cloud request is required.

    Kokoro outputs 24 kHz audio. The model/voice files are downloaded by the
    Kokoro library on first use and then cached locally.
    """
    try:
        import numpy as np
        import soundfile as sf
        from kokoro import KPipeline
    except ImportError as exc:
        raise RuntimeError(
            "Kokoro voiceover is unavailable in this Python environment. "
            "Use Python 3.10-3.12 (recommended: 3.12), create a dedicated venv, "
            "run `pip install -r requirements-kokoro.txt`, and install eSpeak-NG on Windows. "
            "For a video without TTS, rerun with `--no-voice`."
        ) from exc

    lang = {
        "english": "a", "en": "a", "american": "a",
        "british": "b", "en-gb": "b",
        "spanish": "e", "es": "e", "french": "f", "fr": "f",
        "hindi": "h", "hi": "h", "italian": "i", "it": "i",
        "japanese": "j", "ja": "j", "portuguese": "p", "pt": "p",
        "mandarin": "z", "zh": "z", "chinese": "z",
    }.get(str(language).lower(), os.getenv("SKETCHVOX_KOKORO_LANGUAGE", "a"))
    voice = voice or os.getenv("SKETCHVOX_KOKORO_VOICE", "am_michael")
    speed = float(speed if speed is not None else os.getenv("SKETCHVOX_KOKORO_SPEED", "1.0"))
    device = os.getenv("SKETCHVOX_KOKORO_DEVICE") or None

    Path(out_path).parent.mkdir(parents=True, exist_ok=True)
    pipeline = KPipeline(lang_code=lang, device=device) if device else KPipeline(lang_code=lang)
    script = _normalize_for_local_tts(text)
    chunks = []
    for result in pipeline(script, voice=voice, speed=speed, split_pattern=r"\n+"):
        audio = getattr(result, "audio", None)
        if audio is None:
            continue
        if hasattr(audio, "detach"):
            audio = audio.detach().cpu().numpy()
        else:
            audio = np.asarray(audio)
        if audio.size:
            chunks.append(audio.astype(np.float32, copy=False))
    if not chunks:
        raise RuntimeError("Kokoro produced no audio.")
    audio = np.concatenate(chunks, axis=0)
    # Avoid clipping after chunk concatenation.
    peak = float(np.max(np.abs(audio))) if audio.size else 0.0
    if peak > 0.98:
        audio = audio * (0.98 / peak)
    sf.write(str(out_path), audio, 24000, subtype="PCM_16")
    return str(out_path)

def synthesize(text: str, out_path: str | Path, provider: str = "espeak", **kwargs) -> str:
    provider = provider.lower()
    if provider == "espeak":
        return synthesize_espeak(text, out_path, **kwargs)
    if provider in ("local", "studio", "local-studio"):
        return synthesize_local_studio(text, out_path, **kwargs)
    if provider == "elevenlabs":
        return synthesize_elevenlabs(text, out_path, **kwargs)
    if provider == "gemini":
        return synthesize_gemini(text, out_path, **kwargs)
    if provider == "kokoro":
        return synthesize_kokoro(text, out_path, **kwargs)
    if provider in {"clone", "voice_clone", "personal"}:
        from .voice_cloning import synthesize_reference
        reference=kwargs.pop("reference_audio", None)
        if not reference:
            raise ValueError("A reference_audio path is required for the personal voice provider.")
        return synthesize_reference(text, out_path, reference_audio=reference, **kwargs)
    raise ValueError(f"Unknown voiceover provider: {provider}")


def retime_project_to_audio(project: dict, scene_audio_durations: Iterable[float],
                            tail_pad: float = 0.0, fps: int = 30) -> dict:
    """Scale existing visual choreography to each scene's actual speech duration.

    Existing semantic ordering is preserved. This is deliberately proportional
    rather than destructive: a director can still hand-author where an object
    appears, while the complete scene stretches/compresses to the real narration.
    """
    out = deepcopy(project)
    durations = list(scene_audio_durations)
    if len(durations) != len(out.get("scenes", [])):
        raise ValueError("One audio duration is required for every scene.")
    for scene, actual in zip(out["scenes"], durations):
        old = max(0.01, float(scene.get("duration", actual)))
        raw_new = max(0.35, float(actual) + tail_pad)
        # Video is frame-quantized. Ceil rather than round so speech is never
        # clipped; the audio concatenation pass pads each segment to this exact
        # frame duration.
        new = math.ceil(raw_new * fps) / float(fps)
        scale = new / old
        scene["duration"] = round(new, 3)
        for obj in scene.get("objects", []):
            st = float(obj.get("start", 0.0))
            od = float(obj.get("duration", max(0.35, old - st - 0.2)))
            # Preserve authored proportions. Keep a tiny end hold so the final
            # visual state is visible during the last spoken syllables.
            obj["start"] = round(max(0.0, st * scale), 3)
            obj["duration"] = round(max(0.18, od * scale), 3)
            if obj["start"] + obj["duration"] > new:
                obj["duration"] = round(max(0.18, new - obj["start"] - 0.03), 3)
    out.setdefault("meta", {})["voiceover_sync"] = "actual_scene_audio"
    return out


def concatenate_audio(paths: list[str | Path], out_path: str | Path,
                      target_durations: list[float] | None = None) -> str:
    if not paths:
        raise ValueError("No audio files supplied")
    if target_durations is not None and len(target_durations) != len(paths):
        raise ValueError("target_durations must match paths")
    Path(out_path).parent.mkdir(parents=True,exist_ok=True)
    inputs=[]; filters=[]
    for i,p in enumerate(paths):
        inputs += ["-i", str(p)]
        if target_durations is None:
            filters.append(f"[{i}:a]aresample=44100,aformat=sample_fmts=fltp:channel_layouts=mono[a{i}]")
        else:
            target=max(0.05,float(target_durations[i]))
            # Pad if TTS ended before the frame boundary, trim if a provider
            # returned a tiny excess. This makes scene boundaries exact.
            filters.append(
                f"[{i}:a]aresample=44100,aformat=sample_fmts=fltp:channel_layouts=mono,apad=whole_dur={target:.6f},atrim=duration={target:.6f}[a{i}]"
            )
    concat_inputs="".join(f"[a{i}]" for i in range(len(paths)))
    filters.append(f"{concat_inputs}concat=n={len(paths)}:v=0:a=1[outa]")
    _run(["ffmpeg","-y",*inputs,"-filter_complex",";".join(filters),"-map","[outa]","-c:a","aac","-b:a","128k",str(out_path)])
    return str(out_path)


def mux_audio(video_path: str | Path, audio_path: str | Path, out_path: str | Path) -> str:
    Path(out_path).parent.mkdir(parents=True, exist_ok=True)
    _run([
        "ffmpeg","-y","-i",str(video_path),"-i",str(audio_path),
        "-map","0:v:0","-map","1:a:0","-c:v","libx264","-preset","medium",
        "-crf","18","-c:a","aac","-b:a","128k","-shortest","-pix_fmt","yuv420p",str(out_path)
    ])
    return str(out_path)


def build_scene_voiceover(project: dict, out_dir: str | Path, provider: str = "kokoro", **provider_kwargs):
    out_dir=Path(out_dir); out_dir.mkdir(parents=True,exist_ok=True)
    paths=[]; durations=[]
    for i,scene in enumerate(project.get("scenes",[]),1):
        text=str(scene.get("narration","")).strip()
        if not text:
            raise ValueError(f"Scene {i} has no narration")
        path=out_dir/f"scene_{i:02d}.{ 'wav' if provider in ('local','studio','local-studio','espeak','gemini','kokoro') else 'mp3' }"
        synthesize(text,path,provider=provider,**provider_kwargs)
        paths.append(str(path)); durations.append(audio_duration(path))
    return paths,durations
